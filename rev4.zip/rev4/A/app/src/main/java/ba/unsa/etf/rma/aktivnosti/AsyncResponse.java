package ba.unsa.etf.rma.aktivnosti;

interface AsyncResponse {
    void processFinish(String output);
}
