package ba.unsa.etf.rma.klase;

public class Ranglista {
    public String kviz;
    public String igrac;
    public double rezultat;



    public Ranglista(String kviz, String igrac, double rezultat) {
        this.kviz = kviz;
        this.igrac = igrac;
        this.rezultat = rezultat;
    }
}
