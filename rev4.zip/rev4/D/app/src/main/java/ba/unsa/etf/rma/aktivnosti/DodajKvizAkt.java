package ba.unsa.etf.rma.aktivnosti;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.Toast;


import com.google.api.client.googleapis.auth.oauth2.GoogleCredential;
import com.google.common.collect.Lists;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;

import ba.unsa.etf.rma.utility.IBaza;
import ba.unsa.etf.rma.utility.IzgledListView;
import ba.unsa.etf.rma.R;
import ba.unsa.etf.rma.adapteri.kategorija.KategorijaAdapterSpinner;
import ba.unsa.etf.rma.adapteri.pitanje.DodanaPitanjaAdapter;
import ba.unsa.etf.rma.adapteri.pitanje.MogucaPitanjaAdapter;
import ba.unsa.etf.rma.klase.Kategorija;
import ba.unsa.etf.rma.klase.Kviz;
import ba.unsa.etf.rma.klase.Pitanje;
import ba.unsa.etf.rma.utility.Mreza;

public class DodajKvizAkt extends AppCompatActivity {
    private static final int READ_REQUEST_CODE = 42;
    private EditText nazivKviza;

    private Spinner spinnerKategorije;
    private KategorijaAdapterSpinner kategorijaAdapter;
    private ArrayList<Kategorija> kategorije = new ArrayList<>();

    private ListView listaDodanihPitanja;
    private DodanaPitanjaAdapter dodanaPitanjaAdapter;
    private ArrayList<Pitanje> dodanaPitanja = new ArrayList<>();

    private ListView listaMogucihPitanja;
    private MogucaPitanjaAdapter mogucaPitanjaAdapter;
    private ArrayList<Pitanje> mogucaPitanja = new ArrayList<>();

    private ArrayList<Pitanje> svaPitanja = new ArrayList<>();

    private Button dodajKvizBtn;
    private Button importKvizBtn;
    private Kviz kviz;


    private void poveziPolja() {
        nazivKviza = findViewById(R.id.etNaziv);

        spinnerKategorije = findViewById(R.id.spKategorije);
        kategorijaAdapter = new KategorijaAdapterSpinner(this, R.layout.support_simple_spinner_dropdown_item, kategorije);
        spinnerKategorije.setAdapter(kategorijaAdapter);

        listaDodanihPitanja = findViewById(R.id.lvDodanaPitanja);
        dodanaPitanjaAdapter = new DodanaPitanjaAdapter(this, R.layout.element_liste, dodanaPitanja);
        listaDodanihPitanja.setAdapter(dodanaPitanjaAdapter);

        listaMogucihPitanja = findViewById(R.id.lvMogucaPitanja);
        mogucaPitanjaAdapter = new MogucaPitanjaAdapter(this, R.layout.element_liste, mogucaPitanja);
        listaMogucihPitanja.setAdapter(mogucaPitanjaAdapter);
    }

    private void inicijalizirajPolja() {
        inicijalizirajNazivKviza();
        inicijalizirajKategorije();
        inicijalizirajPitanja();
    }


    private void inicijalizirajPitanja() {
        mogucaPitanja.addAll(svaPitanja);
        if (kviz != null) {
            dodanaPitanja.addAll(kviz.getPitanja());
            for (int i = 0; i < mogucaPitanja.size(); i++) {
                for (Pitanje pitanje : dodanaPitanja) {
                    if (mogucaPitanja.get(i).getId().equals(pitanje.getId())) {
                        mogucaPitanja.remove(i);
                        i--;
                        break;
                    }
                }
            }
        }

        if (getIntent().getSerializableExtra("dodanaPitanja") != null) {
            dodanaPitanja.clear();
            dodanaPitanja.addAll((ArrayList<Pitanje>) getIntent().getSerializableExtra("dodanaPitanja"));
            for (int i = 0; i < mogucaPitanja.size(); i++) {
                for (Pitanje pitanje : dodanaPitanja) {
                    if (mogucaPitanja.get(i).getId().equals(pitanje.getId())) {
                        mogucaPitanja.remove(i);
                        i--;
                        break;
                    }
                }
            }
        }


        for (int i = 0; i < mogucaPitanja.size(); i++) {
            if (mogucaPitanja.get(i).getNaziv().equals(getIntent().getStringExtra("nazivNovogPitanja"))) {
                dodanaPitanja.add(mogucaPitanja.get(i));
                mogucaPitanja.remove(i);
                i--;
                break;
            }
        }


        if (dodanaPitanja.size() == 0 || !dodanaPitanja.get(dodanaPitanja.size() - 1).getNaziv().equals("Dodaj Pitanje"))
            dodanaPitanja.add(new Pitanje("Dodaj Pitanje", null, null, null, null));

        mogucaPitanjaAdapter.notifyDataSetChanged();
        dodanaPitanjaAdapter.notifyDataSetChanged();
        IzgledListView.postaviVisinuNaOsnovuBrojaElemenata(listaDodanihPitanja);
        IzgledListView.postaviVisinuNaOsnovuBrojaElemenata(listaMogucihPitanja);
    }

    private void inicijalizirajNazivKviza() {
        if (getIntent().getStringExtra("kvizId") == null)
            nazivKviza.setText(getIntent().getStringExtra("noviNazivKviza") == null ? "" : getIntent().getStringExtra("noviNazivKviza"));
        else
            nazivKviza.setText(getIntent().getStringExtra("noviNazivKviza") == null ? kviz.getNaziv() : getIntent().getStringExtra("noviNazivKviza"));
    }

    private void inicijalizirajKategorije() {
        kategorije.add(new Kategorija("Dodaj Kategoriju", "Dodaj Kategoriju", null));
        if (kviz == null) spinnerKategorije.setSelection(0);
        else {
            for (int i = 0; i < kategorije.size(); i++)
                if (kviz.getKategorija().getIdBaza().equals(kategorije.get(i).getIdBaza())) {
                    spinnerKategorije.setSelection(i);
                    break;
                }
        }


        if (getIntent().getStringExtra("nazivNoveKategorije") != null) {
            for (int i = 0; i < kategorije.size(); i++)
                if (getIntent().getStringExtra("nazivNoveKategorije").equals(kategorije.get(i).getNaziv())) {
                    spinnerKategorije.setSelection(i);
                    break;
                }
        }
        if (getIntent().getStringExtra("idKategorije") != null) {
            for (int i = 0; i < kategorije.size(); i++)
                if (getIntent().getStringExtra("idKategorije").equals(kategorije.get(i).getIdBaza())) {
                    spinnerKategorije.setSelection(i);
                    break;
                }
        }

        kategorijaAdapter.notifyDataSetChanged();
    }

    private void inicijalizirajDugmad() {
        importKvizBtn = findViewById(R.id.btnImportKviz);

        dodajKvizBtn = findViewById(R.id.btnDodajKviz);
        if (getIntent().getStringExtra("kvizId") == null) dodajKvizBtn.setText("Dodaj Kviz");
        else dodajKvizBtn.setText("Azuriraj Kviz");
    }







    private void detektujPromjenuKategorije() {
        spinnerKategorije.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                if(Mreza.getStatusMreze(view.getContext())) {
                    spinnerKategorije.setBackgroundResource(R.drawable.spinner_dizajn);
                    if (position == spinnerKategorije.getCount() - 1) {
                        dodanaPitanja.remove(dodanaPitanja.size() - 1);

                        Intent dodajKategoriju = new Intent(DodajKvizAkt.this, DodajKategorijuAkt.class);
                        dodajKategoriju.putExtra("kvizId", getIntent().getSerializableExtra("kvizId"));
                        dodajKategoriju.putExtra("noviNazivKviza", nazivKviza.getText().toString());
                        dodajKategoriju.putExtra("dodanaPitanja", dodanaPitanja);

                        DodajKvizAkt.this.startActivity(dodajKategoriju);
                    }
                }
                else{
                    Intent vratiKvizoviAkt = new Intent(DodajKvizAkt.this, KvizoviAkt.class);
                    finishAffinity();
                    DodajKvizAkt.this.startActivity(vratiKvizoviAkt);
                    Toast.makeText(view.getContext(), "Konekcija izgubljena", Toast.LENGTH_SHORT).show();
                }


            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                return;
            }
        });
    }

    private void vratiPozadinuNaziva() {
        nazivKviza.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
                return;
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

                nazivKviza.setBackgroundResource(R.drawable.edit_text_button_dizajn);
            }

            @Override
            public void afterTextChanged(Editable s) {
                return;
            }
        });
    }




    private void vratiGlavnuAktivnost(){
        dodajKvizBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(Mreza.getStatusMreze(v.getContext())) {
                    new UcitajKvizoveZaValidacijuNazivaTask(v.getContext()).execute("Validacija kviza");
                }
                else{
                    Intent vratiKvizoviAkt = new Intent(DodajKvizAkt.this, KvizoviAkt.class);
                    finishAffinity();
                    DodajKvizAkt.this.startActivity(vratiKvizoviAkt);
                    Toast.makeText(v.getContext(), "Konekcija izgubljena", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    private void dodajPitanjeIzMogucih() {
        listaMogucihPitanja.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                if(Mreza.getStatusMreze(view.getContext())) {
                    dodanaPitanja.add(dodanaPitanja.size() - 1, mogucaPitanja.get(position));
                    mogucaPitanja.remove(position);

                    mogucaPitanjaAdapter.notifyDataSetChanged();
                    dodanaPitanjaAdapter.notifyDataSetChanged();

                    IzgledListView.postaviVisinuNaOsnovuBrojaElemenata(listaMogucihPitanja);
                    IzgledListView.postaviVisinuNaOsnovuBrojaElemenata(listaDodanihPitanja);
                }
                else{
                    Intent vratiKvizoviAkt = new Intent(DodajKvizAkt.this, KvizoviAkt.class);
                    finishAffinity();
                    DodajKvizAkt.this.startActivity(vratiKvizoviAkt);
                    Toast.makeText(view.getContext(), "Konekcija izgubljena", Toast.LENGTH_SHORT).show();
                }



            }
        });
    }

    private void detektujKlikNaPitanje() {
        listaDodanihPitanja.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                if(Mreza.getStatusMreze(view.getContext())) {
                    if (position == listaDodanihPitanja.getCount() - 1) {
                        Intent dodajPitanje = new Intent(DodajKvizAkt.this, DodajPitanjeAkt.class);
                        dodanaPitanja.remove(dodanaPitanja.size() - 1);

                        dodajPitanje.putExtra("noviNazivKviza", nazivKviza.getText().toString());
                        dodajPitanje.putExtra("dodanaPitanja", dodanaPitanja);
                        dodajPitanje.putExtra("kvizId", getIntent().getSerializableExtra("kvizId"));
                        dodajPitanje.putExtra("idKategorije", ((Kategorija) spinnerKategorije.getSelectedItem()).getIdBaza());

                        DodajKvizAkt.this.startActivity(dodajPitanje);
                    } else {
                        mogucaPitanja.add(dodanaPitanja.get(position));
                        dodanaPitanja.remove(position);

                        mogucaPitanjaAdapter.notifyDataSetChanged();
                        dodanaPitanjaAdapter.notifyDataSetChanged();

                        IzgledListView.postaviVisinuNaOsnovuBrojaElemenata(listaMogucihPitanja);
                        IzgledListView.postaviVisinuNaOsnovuBrojaElemenata(listaDodanihPitanja);
                    }
                }
                else{
                    Intent vratiKvizoviAkt = new Intent(DodajKvizAkt.this, KvizoviAkt.class);
                    finishAffinity();
                    DodajKvizAkt.this.startActivity(vratiKvizoviAkt);
                    Toast.makeText(view.getContext(), "Konekcija izgubljena", Toast.LENGTH_SHORT).show();
                }


            }
        });
    }




    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if(READ_REQUEST_CODE == requestCode && resultCode == Activity.RESULT_OK){
            Uri uri;
            if (data != null) {
                uri = data.getData();
                String importovaniKviz = null;
                try {
                    InputStream inputStream = getContentResolver().openInputStream(uri);
                    BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream));
                    StringBuilder stringBuilder = new StringBuilder();
                    String line;
                    while ((line = reader.readLine()) != null) {
                        stringBuilder.append(line + "\n");
                    }
                    importovaniKviz = stringBuilder.toString();

                    if(Mreza.getStatusMreze(this)) {
                        new UcitajSveZaValidacijuTask(this, importovaniKviz).execute("Unos importovanog kviza");
                    }
                    else{
                        Intent vratiKvizoviAkt = new Intent(DodajKvizAkt.this, KvizoviAkt.class);
                        finishAffinity();
                        DodajKvizAkt.this.startActivity(vratiKvizoviAkt);
                        Toast.makeText(this, "Konekcija izgubljena", Toast.LENGTH_SHORT).show();
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }


            }
        }

    }

    private void odaberiDatoteku(){
        if(Mreza.getStatusMreze(this)) {
            Intent importDatoteke = new Intent(Intent.ACTION_OPEN_DOCUMENT);
            importDatoteke.addCategory(Intent.CATEGORY_OPENABLE);
            importDatoteke.setType("text/*");
            startActivityForResult(importDatoteke, READ_REQUEST_CODE);
        }
        else {
            Intent vratiKvizoviAkt = new Intent(DodajKvizAkt.this, KvizoviAkt.class);
            finishAffinity();
            DodajKvizAkt.this.startActivity(vratiKvizoviAkt);
            Toast.makeText(this, "Konekcija izgubljena", Toast.LENGTH_SHORT).show();
        }
    }




    private void importujKviz(){
        importKvizBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(getIntent().getStringExtra("kvizId") == null) odaberiDatoteku();
                else Toast.makeText(v.getContext(), "Azurirate kviz, ne mozete importovati novi", Toast.LENGTH_SHORT).show();
            }
        });
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.dodaj_kviz_akt);

        if(Mreza.getStatusMreze(this)) {
            new UcitajSveTask(this).execute("Ucitavanje svega");

            importujKviz();
            dodajPitanjeIzMogucih();
            detektujPromjenuKategorije();
            detektujKlikNaPitanje();
            vratiPozadinuNaziva();

            vratiGlavnuAktivnost();
        }
        else{
            Intent vratiKvizoviAkt = new Intent(DodajKvizAkt.this, KvizoviAkt.class);
            finishAffinity();
            DodajKvizAkt.this.startActivity(vratiKvizoviAkt);
            Toast.makeText(this, "Konekcija izgubljena", Toast.LENGTH_SHORT).show();
        }




    }

    @Override
    public void onBackPressed() {
        Intent vratiKvizoviAkt = new Intent(DodajKvizAkt.this, KvizoviAkt.class);
        finishAffinity();
        DodajKvizAkt.this.startActivity(vratiKvizoviAkt);
    }

    public class UcitajSveTask extends AsyncTask<String, Void, Void> implements IBaza {
        private HttpURLConnection connKvizovi;
        private HttpURLConnection connKategorije;
        private HttpURLConnection connPitanja;
        private Context context;
        private ProgressDialog progressDialog = null;


        public UcitajSveTask(Context context) {
            super();
            this.context = context;
        }

        @Override
        protected Void doInBackground(String... strings) {
            try {
                konektujNaBazu();
                try {
                    kategorije.clear();
                    JSONArray array;
                    JSONObject dokumenti = new JSONObject(KvizoviAkt.prebaciUString(connKategorije.getInputStream()));
                    if(dokumenti.has("documents")){
                        array = dokumenti.getJSONArray("documents");
                        for (int i = 0; i < array.length(); i++) {
                            String[] name = array.getJSONObject(i).getString("name").split("/");
                            JSONObject kategorijaNaziv = array.getJSONObject(i).getJSONObject("fields").getJSONObject("naziv");
                            JSONObject kategorijaId = array.getJSONObject(i).getJSONObject("fields").getJSONObject("idIkonice");
                            String naziv = kategorijaNaziv.getString("stringValue");
                            String id = ((Integer) kategorijaId.getInt("integerValue")).toString();
                            kategorije.add(new Kategorija(naziv, id, name[name.length - 1]));
                        }
                    }
                    kategorije.add(0, new Kategorija("Sve", "902", "0"));

                    dokumenti = new JSONObject(KvizoviAkt.prebaciUString(connPitanja.getInputStream()));
                    if(dokumenti.has("documents")) {
                        array = dokumenti.getJSONArray("documents");

                        for (int i = 0; i < array.length(); i++) {
                            String[] name = array.getJSONObject(i).getString("name").split("/");
                            JSONObject pitanjeNaziv = array.getJSONObject(i).getJSONObject("fields").getJSONObject("naziv");
                            JSONObject indexTacnog = array.getJSONObject(i).getJSONObject("fields").getJSONObject("indexTacnog");
                            JSONArray odgovoriJSON = array.getJSONObject(i).getJSONObject("fields").getJSONObject("odgovori").getJSONObject("arrayValue").getJSONArray("values");
                            ArrayList<String> odgovori = new ArrayList<>();
                            for (int j = 0; j < odgovoriJSON.length(); j++)
                                odgovori.add(odgovoriJSON.getJSONObject(j).getString("stringValue"));
                            String naziv = pitanjeNaziv.getString("stringValue");
                            Integer tacan = indexTacnog.getInt("integerValue");
                            svaPitanja.add(new Pitanje(naziv, naziv, odgovori, odgovori.get(tacan), name[name.length - 1]));
                        }
                    }

                    if (getIntent().getStringExtra("kvizId") != null) {
                        JSONObject kvizJSON = new JSONObject(KvizoviAkt.prebaciUString(connKvizovi.getInputStream()));
                        String kvizNaziv = kvizJSON.getJSONObject("fields").getJSONObject("naziv").getString("stringValue");
                        String kvizKategorijaId = kvizJSON.getJSONObject("fields").getJSONObject("idKategorije").getString("stringValue");


                        Kategorija kategorija = null;
                        for (Kategorija temp : kategorije) {
                            if (temp.getIdBaza().equals(kvizKategorijaId)) {
                                kategorija = temp;
                                break;
                            }
                        }

                        ArrayList<Pitanje> pitanjaUKvizu = new ArrayList<>();
                        JSONObject pitanjaKvizNiz = kvizJSON.getJSONObject("fields").getJSONObject("pitanja").getJSONObject("arrayValue");
                        if (pitanjaKvizNiz.has("values")) {
                            JSONArray pitanjaKvizId = pitanjaKvizNiz.getJSONArray("values");
                            for (int j = 0; j < pitanjaKvizId.length(); j++) {
                                String pitanjeId = pitanjaKvizId.getJSONObject(j).getString("stringValue");
                                for (Pitanje pitanje : svaPitanja)
                                    if (pitanje.getId().equals(pitanjeId)) {
                                        pitanjaUKvizu.add(pitanje);
                                        break;
                                    }
                            }
                        }
                        kviz = new Kviz(kvizNaziv, pitanjaUKvizu, kategorija, getIntent().getStringExtra("kvizId"));
                    }


                } catch (JSONException e) {
                    e.printStackTrace();
                }

            } catch (IOException e) {
                e.printStackTrace();
            }

            zatvoriKonekciju();
            return null;
        }

        @Override
        protected void onPreExecute() {
            progressDialog = ProgressDialog.show(context, "", "Ucitavam potrebne podatke", true);
            poveziPolja();
            inicijalizirajDugmad();
        }

        @Override
        protected void onPostExecute(Void aVoid) {
            progressDialog.cancel();
            inicijalizirajPolja();
        }

        @Override
        public void konektujNaBazu() throws IOException {
            InputStream is = getResources().openRawResource(R.raw.secret);
            GoogleCredential credentials = GoogleCredential.fromStream(is).createScoped(Lists.newArrayList("https://www.googleapis.com/auth/datastore"));
            credentials.refreshToken();
            String token = credentials.getAccessToken();
            String urlString = "https://firestore.googleapis.com/v1/projects/projekatrma/databases/(default)/documents/Kategorije?access_token=";
            URL url = new URL(urlString + URLEncoder.encode(token, "UTF-8"));
            connKategorije = (HttpURLConnection) url.openConnection();
            System.out.print(urlString + token);

            connKategorije.setRequestMethod("GET");
            connKategorije.setRequestProperty("Content-Type", "application/json");
            connKategorije.setRequestProperty("Accept", "application/json");

            is = getResources().openRawResource(R.raw.secret);
            credentials = GoogleCredential.fromStream(is).createScoped(Lists.newArrayList("https://www.googleapis.com/auth/datastore"));
            credentials.refreshToken();
            token = credentials.getAccessToken();
            urlString = "https://firestore.googleapis.com/v1/projects/projekatrma/databases/(default)/documents/Pitanja?access_token=";
            url = new URL(urlString + URLEncoder.encode(token, "UTF-8"));
            connPitanja = (HttpURLConnection) url.openConnection();
            System.out.print(urlString + token);

            connPitanja.setRequestMethod("GET");
            connPitanja.setRequestProperty("Content-Type", "application/json");
            connPitanja.setRequestProperty("Accept", "application/json");

            if (getIntent().getStringExtra("kvizId") != null) {
                is = context.getResources().openRawResource(R.raw.secret);
                credentials = GoogleCredential.fromStream(is).createScoped(Lists.newArrayList("https://www.googleapis.com/auth/datastore"));
                credentials.refreshToken();
                token = credentials.getAccessToken();
                urlString = "https://firestore.googleapis.com/v1/projects/projekatrma/databases/(default)/documents/Kvizovi/" + getIntent().getStringExtra("kvizId") + "?access_token=";
                url = new URL(urlString + URLEncoder.encode(token, "UTF-8"));
                connKvizovi = (HttpURLConnection) url.openConnection();
                System.out.print(urlString + token);

                connKvizovi.setRequestMethod("GET");
                connKvizovi.setRequestProperty("Content-Type", "application/json");
                connKvizovi.setRequestProperty("Accept", "application/json");
            }

        }

        @Override
        public void zatvoriKonekciju() {
            connKategorije.disconnect();
            connPitanja.disconnect();
            if (connKvizovi != null) connKvizovi.disconnect();
        }
    }

    public class UcitajSveZaValidacijuTask extends AsyncTask<String, Void, Void> implements IBaza {
        private HttpURLConnection connKvizovi;
        private HttpURLConnection connKategorije;
        private HttpURLConnection connPitanja;
        private Context context;
        private String kvizTekst;
        private ProgressDialog progressDialog = null;

        private ArrayList<Kategorija> kategorijeIzBaze = new ArrayList<>();
        private ArrayList<Pitanje> pitanjaIzBaze = new ArrayList<>();
        private ArrayList<Kviz> kvizoviIzBaze = new ArrayList<>();

        private void prikaziAlertDialog(String poruka){
            AlertDialog alertDialog = new AlertDialog.Builder(DodajKvizAkt.this).create();
            alertDialog.setTitle("Greska");
            alertDialog.setMessage(poruka);
            alertDialog.setButton(AlertDialog.BUTTON_NEUTRAL, "OK",
                    new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog, int which) {
                            dialog.dismiss();
                        }
                    });
            alertDialog.show();
        }

        private boolean validirajNazivImportovanogKviza(String nazivImportovanogKviza){

            for(Kviz kvizBaza : kvizoviIzBaze){
                if(kvizBaza.getNaziv().equals(nazivImportovanogKviza)){
                    prikaziAlertDialog("Kviz kojeg importujete vec postoji!");
                    return false;
                }
            }
            return true;
        }

        private void importujKategoriju(String importovanaKategorija){

            for(int i = 0; i < kategorijeIzBaze.size(); i++){
                if(importovanaKategorija.equals(kategorijeIzBaze.get(i).getNaziv())){
                    spinnerKategorije.setSelection(i);
                    return;
                }
            }
            new DodajKategorijuTask(context, new Kategorija(importovanaKategorija, "902", null)).execute("Dodaj kategoriju");

        }

        private boolean validirajPrviRed(String[] red, int brojRedova){
            if(red.length != 3){
                prikaziAlertDialog("Datoteka kviza kojeg importujete nema ispravan format!");
                return false;
            }

            if(!validirajNazivImportovanogKviza(red[0])) return false;
            importujKategoriju(red[1]);
            try{
                Integer brojPitanja = Integer.parseInt(red[2]);
                if(brojRedova - 1 != brojPitanja){
                    prikaziAlertDialog("Kviz kojeg imporujete ima neispravan broj pitanja!");
                    return false;
                }
            }
            catch (Exception e){
                prikaziAlertDialog("Kviz kojeg imporujete ima neispravan broj pitanja!");
                return false;
            }

            return true;
        }

        private boolean validirajNazivPitanja(String naziv, ArrayList<Pitanje> importovanaPitanja){
            for(Pitanje pitanje : importovanaPitanja){
                if(pitanje.getNaziv().equals(naziv)){
                    prikaziAlertDialog("Kviz nije ispravan postoje dva pitanja sa istim nazivom!");
                    return false;
                }
                for(Pitanje pitanjeIzBaze : pitanjaIzBaze){
                    if(pitanje.getNaziv().equals(pitanjeIzBaze.getNaziv())){
                        prikaziAlertDialog("Kviz sadrzi pitanje koje je vec u bazi podataka!");
                        return false;
                    }
                }
            }

            return true;
        }

        private boolean validirajBrojOdgovora(String broj, Integer stvarniBroj){
            try{
                Integer brojOdgovora = Integer.parseInt(broj);
                if(brojOdgovora != stvarniBroj){
                    prikaziAlertDialog("Kviz kojeg importujete ima neispravan broj odgovora!");
                    return false;
                }
            }
            catch (Exception e){
                prikaziAlertDialog("Kviz kojeg importujete ima neispravan broj odgovora!");
                return false;
            }
            return true;
        }

        private boolean validirajTacanOdgovor(String indexTacnog, Integer velicina){
            try{
                Integer index = Integer.parseInt(indexTacnog);
                if(index < 0 || index > velicina - 1){
                    prikaziAlertDialog("Kviz kojeg importujete ima neispravan index tacnog odgovora!");
                    return false;
                }

            }
            catch (Exception e){
                prikaziAlertDialog("Kviz kojeg importujete ima neispravan index tacnog odgovora!");
                return false;
            }
            return true;
        }

        private ArrayList<String> importujOdgovore(String[] odgovori){
            ArrayList<String> dodaniOdgovori = new ArrayList<>();
            for(int i = 3; i < odgovori.length; i++){
                if(dodaniOdgovori.contains(odgovori[i])){
                    prikaziAlertDialog("Kviz kojeg importujete nije ispravan postoji ponavljanje odgovora!");
                    return null;
                }
                dodaniOdgovori.add(odgovori[i]);
            }

            return dodaniOdgovori;
        }

        private ArrayList<String> validirajImportovanaPitanja(String[] red, ArrayList<Pitanje> importovanaPitanja){
            if(red.length < 4){
                prikaziAlertDialog("Datoteka kviza kojeg importujete nema ispravan format!");
                return null;
            }

            if(!validirajNazivPitanja(red[0], importovanaPitanja)) return null;
            if(!validirajBrojOdgovora(red[1], red.length - 3)) return null;
            if(!validirajTacanOdgovor(red[2], red.length - 3)) return null;
            ArrayList<String> odgovori = importujOdgovore(red);
            return odgovori;
        }

        private void unesiImportovaniKviz(String kviz){
            if(kviz != null){
                String[] redovi = kviz.split("\n");
                boolean postojiGreska = false;
                ArrayList<Pitanje> pitanja = new ArrayList<>();
                String nazivImportovanogKviza = "";

                for(int i = 0; i < redovi.length; i++){
                    String[] red = redovi[i].split(",");
                    if(i == 0) {
                        if(!validirajPrviRed(red, redovi.length)) postojiGreska = true;
                        else nazivImportovanogKviza = red[0];
                    }
                    else{
                        ArrayList<String> importovaniOdgovori = validirajImportovanaPitanja(red, pitanja);
                        if(importovaniOdgovori == null) postojiGreska = true;
                        else pitanja.add(new Pitanje(red[0], red[0], importovaniOdgovori, importovaniOdgovori.get(Integer.parseInt(red[2])), null));
                    }

                    if(postojiGreska) return;
                }

                new DodajListuPitanjaTask(context, pitanja).execute("Dodavanje pitanja");

                nazivKviza.setText(nazivImportovanogKviza);
            }
        }



        public UcitajSveZaValidacijuTask(Context context, String kvizTekst) {
            super();
            this.context = context;
            this.kvizTekst = kvizTekst;
        }

        @Override
        protected Void doInBackground(String... strings) {
            try {
                konektujNaBazu();
                try {
                    kategorijeIzBaze.clear();
                    JSONArray array;
                    JSONObject dokumenti = new JSONObject(KvizoviAkt.prebaciUString(connKategorije.getInputStream()));
                    if(dokumenti.has("documents")) {
                        array = dokumenti.getJSONArray("documents");
                        for (int i = 0; i < array.length(); i++) {
                            String[] name = array.getJSONObject(i).getString("name").split("/");
                            JSONObject kategorijaNaziv = array.getJSONObject(i).getJSONObject("fields").getJSONObject("naziv");
                            JSONObject kategorijaId = array.getJSONObject(i).getJSONObject("fields").getJSONObject("idIkonice");
                            String naziv = kategorijaNaziv.getString("stringValue");
                            String id = ((Integer) kategorijaId.getInt("integerValue")).toString();
                            kategorijeIzBaze.add(new Kategorija(naziv, id, name[name.length - 1]));
                        }
                    }
                    kategorijeIzBaze.add(0, new Kategorija("Sve", "902", "0"));

                    dokumenti = new JSONObject(KvizoviAkt.prebaciUString(connPitanja.getInputStream()));
                    if(dokumenti.has("documents")) {
                        array = dokumenti.getJSONArray("documents");

                        for (int i = 0; i < array.length(); i++) {
                            String[] name = array.getJSONObject(i).getString("name").split("/");
                            JSONObject pitanjeNaziv = array.getJSONObject(i).getJSONObject("fields").getJSONObject("naziv");
                            JSONObject indexTacnog = array.getJSONObject(i).getJSONObject("fields").getJSONObject("indexTacnog");
                            JSONArray odgovoriJSON = array.getJSONObject(i).getJSONObject("fields").getJSONObject("odgovori").getJSONObject("arrayValue").getJSONArray("values");
                            ArrayList<String> odgovori = new ArrayList<>();
                            for (int j = 0; j < odgovoriJSON.length(); j++)
                                odgovori.add(odgovoriJSON.getJSONObject(j).getString("stringValue"));
                            String naziv = pitanjeNaziv.getString("stringValue");
                            Integer tacan = indexTacnog.getInt("integerValue");
                            pitanjaIzBaze.add(new Pitanje(naziv, naziv, odgovori, odgovori.get(tacan), name[name.length - 1]));
                        }
                    }

                    dokumenti = new JSONObject(KvizoviAkt.prebaciUString(connKvizovi.getInputStream()));
                    if(dokumenti.has("documents")) {
                        array = dokumenti.getJSONArray("documents");
                        for (int i = 0; i < array.length(); i++) {
                            String[] name = array.getJSONObject(i).getString("name").split("/");
                            String kvizNaziv = array.getJSONObject(i).getJSONObject("fields").getJSONObject("naziv").getString("stringValue");
                            String kvizKategorijaId = array.getJSONObject(i).getJSONObject("fields").getJSONObject("idKategorije").getString("stringValue");

                            Kategorija kategorija = null;
                            for (Kategorija temp : kategorijeIzBaze) {
                                if (temp.getIdBaza().equals(kvizKategorijaId)) {
                                    kategorija = temp;
                                    break;
                                }
                            }


                            ArrayList<Pitanje> pitanjaUKvizu = new ArrayList<>();
                            JSONObject pitanjaKvizNiz = array.getJSONObject(i).getJSONObject("fields").getJSONObject("pitanja").getJSONObject("arrayValue");
                            if (pitanjaKvizNiz.has("values")) {
                                JSONArray pitanjaKvizId = pitanjaKvizNiz.getJSONArray("values");
                                for (int j = 0; j < pitanjaKvizId.length(); j++) {
                                    String pitanjeId = pitanjaKvizId.getJSONObject(j).getString("stringValue");
                                    for (Pitanje pitanje : pitanjaIzBaze)
                                        if (pitanje.getId().equals(pitanjeId)) {
                                            pitanjaUKvizu.add(pitanje);
                                            break;
                                        }
                                }
                            }
                            kvizoviIzBaze.add(new Kviz(kvizNaziv, pitanjaUKvizu, kategorija, name[name.length - 1]));
                        }
                    }

                } catch (JSONException e) {
                    e.printStackTrace();
                }

            } catch (IOException e) {
                e.printStackTrace();
            }

            zatvoriKonekciju();
            return null;
        }

        @Override
        protected void onPreExecute() {
            progressDialog = ProgressDialog.show(context, "", "Validacija importovanog kviza u toku", true);
        }

        @Override
        protected void onPostExecute(Void aVoid) {
            progressDialog.cancel();
            unesiImportovaniKviz(kvizTekst);
        }

        @Override
        public void konektujNaBazu() throws IOException {
            InputStream is = getResources().openRawResource(R.raw.secret);
            GoogleCredential credentials = GoogleCredential.fromStream(is).createScoped(Lists.newArrayList("https://www.googleapis.com/auth/datastore"));
            credentials.refreshToken();
            String token = credentials.getAccessToken();
            String urlString = "https://firestore.googleapis.com/v1/projects/projekatrma/databases/(default)/documents/Kategorije?access_token=";
            URL url = new URL(urlString + URLEncoder.encode(token, "UTF-8"));
            connKategorije = (HttpURLConnection) url.openConnection();
            System.out.print(urlString + token);

            connKategorije.setRequestMethod("GET");
            connKategorije.setRequestProperty("Content-Type", "application/json");
            connKategorije.setRequestProperty("Accept", "application/json");

            is = getResources().openRawResource(R.raw.secret);
            credentials = GoogleCredential.fromStream(is).createScoped(Lists.newArrayList("https://www.googleapis.com/auth/datastore"));
            credentials.refreshToken();
            token = credentials.getAccessToken();
            urlString = "https://firestore.googleapis.com/v1/projects/projekatrma/databases/(default)/documents/Pitanja?access_token=";
            url = new URL(urlString + URLEncoder.encode(token, "UTF-8"));
            connPitanja = (HttpURLConnection) url.openConnection();
            System.out.print(urlString + token);

            connPitanja.setRequestMethod("GET");
            connPitanja.setRequestProperty("Content-Type", "application/json");
            connPitanja.setRequestProperty("Accept", "application/json");

            is = context.getResources().openRawResource(R.raw.secret);
            credentials = GoogleCredential.fromStream(is).createScoped(Lists.newArrayList("https://www.googleapis.com/auth/datastore"));
            credentials.refreshToken();
            token = credentials.getAccessToken();
            urlString = "https://firestore.googleapis.com/v1/projects/projekatrma/databases/(default)/documents/Kvizovi?access_token=";
            url = new URL(urlString + URLEncoder.encode(token, "UTF-8"));
            connKvizovi = (HttpURLConnection) url.openConnection();
            System.out.print(urlString + token);

            connKvizovi.setRequestMethod("GET");
            connKvizovi.setRequestProperty("Content-Type", "application/json");
            connKvizovi.setRequestProperty("Accept", "application/json");
        }

        @Override
        public void zatvoriKonekciju() {
            connKategorije.disconnect();
            connPitanja.disconnect();
            connKvizovi.disconnect();
        }
    }


    public class DodajKategorijuTask extends AsyncTask<String, Void, Void> implements IBaza {
        private Kategorija kategorija;
        private HttpURLConnection conn;
        private Context context;

        public DodajKategorijuTask(Context context, Kategorija kategorija) {
            super();
            this.kategorija = kategorija;
            this.context = context;
        }

        @Override
        protected Void doInBackground(String... strings) {
            try {
                konektujNaBazu();

                String dokument = "{ \"fields\": { \"naziv\": {\"stringValue\":\"" + kategorija.getNaziv() + "\"}, \"idIkonice\": {\"integerValue\":\"" + kategorija.getId().trim() + "\"}}}";
                OutputStream os = conn.getOutputStream();
                byte[] input = dokument.getBytes("utf-8");
                os.write(input, 0, input.length);


                int code = conn.getResponseCode();
                InputStream odgovor = conn.getInputStream();
                BufferedReader br = new BufferedReader(new InputStreamReader(odgovor, "utf-8"));
                StringBuilder response = new StringBuilder();
                String responseLine = null;
                while ((responseLine = br.readLine()) !=null ) {
                    response.append(responseLine.trim());
                }



            } catch (IOException e) {
                e.printStackTrace();
            }

            zatvoriKonekciju();
            return null;
        }

        @Override
        protected void onPostExecute(Void aVoid) {
            Toast.makeText(context, "Kategorija \"" + kategorija.getNaziv() + "\" dodana u bazu", Toast.LENGTH_SHORT).show();
            new UcitajNoveKategorijeTask(context, kategorija.getNaziv()).execute("Ucitavanje kategorija");
        }

        @Override
        public void konektujNaBazu() throws IOException {
            InputStream is = context.getResources().openRawResource(R.raw.secret);
            GoogleCredential credentials = GoogleCredential.fromStream(is).createScoped(Lists.newArrayList("https://www.googleapis.com/auth/datastore"));
            credentials.refreshToken();
            String token = credentials.getAccessToken();
            String urlString = "https://firestore.googleapis.com/v1/projects/projekatrma/databases/(default)/documents/Kategorije?access_token=";
            URL url = new URL(urlString + URLEncoder.encode(token, "UTF-8"));
            conn = (HttpURLConnection) url.openConnection();

            conn.setDoOutput(true);
            conn.setRequestMethod("POST");
            conn.setRequestProperty("Content-Type", "application/json");
            conn.setRequestProperty("Accept", "application/json");
        }

        @Override
        public void zatvoriKonekciju(){
            conn.disconnect();
        }
    }

    public class UcitajNoveKategorijeTask extends AsyncTask<String, Void, Void> implements IBaza {
        private HttpURLConnection conn;
        private Context context;
        private String naziv;
        private ProgressDialog progressDialog;

        public UcitajNoveKategorijeTask(Context context, String naziv) {
            super();
            this.context = context;
            this.naziv = naziv;
        }

        @Override
        protected Void doInBackground(String... strings) {
            try {
                konektujNaBazu();

                kategorije.clear();
                JSONObject dokumenti = new JSONObject(KvizoviAkt.prebaciUString(conn.getInputStream()));
                if(dokumenti.has("documents")) {
                    JSONArray array = dokumenti.getJSONArray("documents");
                    for (int i = 0; i < array.length(); i++) {
                        String[] name = array.getJSONObject(i).getString("name").split("/");
                        JSONObject kategorijaNaziv = array.getJSONObject(i).getJSONObject("fields").getJSONObject("naziv");
                        JSONObject kategorijaId = array.getJSONObject(i).getJSONObject("fields").getJSONObject("idIkonice");
                        String naziv = kategorijaNaziv.getString("stringValue");
                        String id = ((Integer) kategorijaId.getInt("integerValue")).toString();
                        kategorije.add(new Kategorija(naziv, id, name[name.length - 1]));
                    }
                }
                kategorije.add(0, new Kategorija("Sve", "902", "0"));
            } catch (IOException e) {
                e.printStackTrace();
            } catch (JSONException e) {
                e.printStackTrace();
            }

            zatvoriKonekciju();
            return null;
        }

        @Override
        protected void onPreExecute() {
            progressDialog = ProgressDialog.show(context, "", "Ucitavanje azurirane liste kategorija iz baze", true);
        }

        @Override
        protected void onPostExecute(Void aVoid) {
            kategorije.add(new Kategorija("Dodaj kategoriju", null, null));
            kategorijaAdapter.notifyDataSetChanged();
            for(int i = 0; i < kategorije.size(); i++){
                if(kategorije.get(i).getNaziv().equals(naziv)){
                    spinnerKategorije.setSelection(i);
                    break;
                }
            }
            progressDialog.cancel();
        }

        @Override
        public void konektujNaBazu() throws IOException {
            InputStream is = getResources().openRawResource(R.raw.secret);
            GoogleCredential credentials = GoogleCredential.fromStream(is).createScoped(Lists.newArrayList("https://www.googleapis.com/auth/datastore"));
            credentials.refreshToken();
            String token = credentials.getAccessToken();
            String urlString = "https://firestore.googleapis.com/v1/projects/projekatrma/databases/(default)/documents/Kategorije?access_token=";
            URL url = new URL(urlString + URLEncoder.encode(token, "UTF-8"));
            conn = (HttpURLConnection) url.openConnection();
            System.out.print(urlString + token);

            conn.setRequestMethod("GET");
            conn.setRequestProperty("Content-Type", "application/json");
            conn.setRequestProperty("Accept", "application/json");
        }

        @Override
        public void zatvoriKonekciju(){
            conn.disconnect();
        }
    }

    public class DodajListuPitanjaTask extends AsyncTask<String, Void, Void> implements IBaza {
        private Context context;
        private ArrayList<Pitanje> pitanja;
        private HttpURLConnection conn;

        public DodajListuPitanjaTask(Context context, ArrayList<Pitanje> pitanja) {
            super();
            this.context = context;
            this.pitanja = pitanja;
        }

        @Override
        protected Void doInBackground(String... strings) {
            try {

                for(Pitanje pitanje : pitanja){
                    konektujNaBazu();
                    String dokument;
                    int pozicija = 0;

                    dokument = "{ \"fields\": { \"naziv\": {\"stringValue\":\"" + pitanje.getNaziv() + "\"}, \"odgovori\": {\"arrayValue\": {\"values\": [";
                    for(int i = 0; i < pitanje.getOdgovori().size(); i++){
                        if(pitanje.getOdgovori().get(i).equals(pitanje.getTacan())) pozicija = i;
                        dokument += "{\"stringValue\": \"" + pitanje.getOdgovori().get(i) + "\"}";
                        if(i != pitanje.getOdgovori().size() - 1) dokument += ", ";
                    }
                    dokument += "]}}, \"indexTacnog\": {\"integerValue\":\"" + pozicija + "\"}}}";

                    OutputStream os = conn.getOutputStream();
                    byte[] input = dokument.getBytes("utf-8");
                    os.write(input, 0, input.length);

                    int code = conn.getResponseCode();
                    InputStream odgovor = conn.getInputStream();
                    BufferedReader br = new BufferedReader(new InputStreamReader(odgovor, "utf-8"));
                    StringBuilder response = new StringBuilder();
                    String responseLine = null;
                    while ((responseLine = br.readLine()) !=null ) {
                        response.append(responseLine.trim());
                    }
                    zatvoriKonekciju();
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
            zatvoriKonekciju();
            return null;
        }

        @Override
        protected void onPostExecute(Void aVoid) {
            Toast.makeText(context, "Broj pitanja dodanih u bazu: " + pitanja.size(), Toast.LENGTH_SHORT).show();
            new UcitajNovaPitanjaTask(context, pitanja).execute("Ucitavanje pitanja");
        }

        @Override
        public void konektujNaBazu() throws IOException {
            InputStream is = context.getResources().openRawResource(R.raw.secret);
            GoogleCredential credentials = GoogleCredential.fromStream(is).createScoped(Lists.newArrayList("https://www.googleapis.com/auth/datastore"));
            credentials.refreshToken();
            String token = credentials.getAccessToken();
            String urlString = "https://firestore.googleapis.com/v1/projects/projekatrma/databases/(default)/documents/Pitanja?access_token=";
            URL url = new URL(urlString + URLEncoder.encode(token, "UTF-8"));
            conn = (HttpURLConnection) url.openConnection();

            conn.setDoOutput(true);
            conn.setRequestMethod("POST");
            conn.setRequestProperty("Content-Type", "application/json");
            conn.setRequestProperty("Accept", "application/json");
        }

        @Override
        public void zatvoriKonekciju() {
            conn.disconnect();
        }
    }

    public class UcitajNovaPitanjaTask extends AsyncTask<String, Void, Void> implements IBaza {
        private Context context;
        private ArrayList<Pitanje> pitanjaUKvizu;
        private HttpURLConnection conn;
        private ProgressDialog progressDialog;

        public UcitajNovaPitanjaTask(Context context, ArrayList<Pitanje> pitanjaUKvizu) {
            super();
            this.context = context;
            this.pitanjaUKvizu = pitanjaUKvizu;
        }

        @Override
        protected Void doInBackground(String... strings) {
            try {
                konektujNaBazu();

                svaPitanja.clear();
                JSONObject dokumenti = new JSONObject(KvizoviAkt.prebaciUString(conn.getInputStream()));
                if(dokumenti.has("documents")){
                    JSONArray array = dokumenti.getJSONArray("documents");

                    for (int i = 0; i < array.length(); i++) {
                        String[] name = array.getJSONObject(i).getString("name").split("/");
                        JSONObject pitanjeNaziv = array.getJSONObject(i).getJSONObject("fields").getJSONObject("naziv");
                        JSONObject indexTacnog = array.getJSONObject(i).getJSONObject("fields").getJSONObject("indexTacnog");
                        JSONArray odgovoriJSON = array.getJSONObject(i).getJSONObject("fields").getJSONObject("odgovori").getJSONObject("arrayValue").getJSONArray("values");
                        ArrayList<String> odgovori = new ArrayList<>();
                        for (int j = 0; j < odgovoriJSON.length(); j++)
                            odgovori.add(odgovoriJSON.getJSONObject(j).getString("stringValue"));
                        String naziv = pitanjeNaziv.getString("stringValue");
                        Integer tacan = indexTacnog.getInt("integerValue");
                        svaPitanja.add(new Pitanje(naziv, naziv, odgovori, odgovori.get(tacan), name[name.length - 1]));
                    }
                }

            } catch (IOException e) {
                zatvoriKonekciju();
                e.printStackTrace();
            } catch (JSONException e) {
                e.printStackTrace();
            }
            zatvoriKonekciju();
            return null;
        }

        @Override
        protected void onPreExecute() {
            progressDialog = ProgressDialog.show(context, "", "Azuriranje liste pitanja", true);
        }

        @Override
        protected void onPostExecute(Void aVoid) {
            progressDialog.cancel();
            mogucaPitanja.clear();
            dodanaPitanja.clear();
            mogucaPitanja.addAll(svaPitanja);
            for(int i = 0; i < mogucaPitanja.size(); i++){
                for(Pitanje pitanje : pitanjaUKvizu){
                    if(i < mogucaPitanja.size() && i > -1 && pitanje.getNaziv().equals(mogucaPitanja.get(i).getNaziv())){
                        dodanaPitanja.add(mogucaPitanja.get(i));
                        mogucaPitanja.remove(i);
                        i--;
                    }
                }
            }
            dodanaPitanja.add(new Pitanje("Dodaj pitanje", null, null, null, null));
            dodanaPitanjaAdapter.notifyDataSetChanged();
            mogucaPitanjaAdapter.notifyDataSetChanged();
            IzgledListView.postaviVisinuNaOsnovuBrojaElemenata(listaDodanihPitanja);
            IzgledListView.postaviVisinuNaOsnovuBrojaElemenata(listaMogucihPitanja);
        }

        @Override
        public void konektujNaBazu() throws IOException {
            InputStream is = getResources().openRawResource(R.raw.secret);
            GoogleCredential credentials = GoogleCredential.fromStream(is).createScoped(Lists.newArrayList("https://www.googleapis.com/auth/datastore"));
            credentials.refreshToken();
            String token = credentials.getAccessToken();
            String urlString = "https://firestore.googleapis.com/v1/projects/projekatrma/databases/(default)/documents/Pitanja?access_token=";
            URL url = new URL(urlString + URLEncoder.encode(token, "UTF-8"));
            conn = (HttpURLConnection) url.openConnection();
            System.out.print(urlString + token);

            conn.setRequestMethod("GET");
            conn.setRequestProperty("Content-Type", "application/json");
            conn.setRequestProperty("Accept", "application/json");
        }

        @Override
        public void zatvoriKonekciju() {
            conn.disconnect();
        }
    }

    public class UcitajKvizoveZaValidacijuNazivaTask extends AsyncTask<String, Void, Void> implements IBaza {
        private HttpURLConnection conn;
        private Context context;
        private ProgressDialog progressDialog = null;

        private ArrayList<String> naziviKvizovaIzBaze = new ArrayList<>();

        private boolean validirajNaziv(){
            if(nazivKviza.length() == 0){
                nazivKviza.setBackgroundResource(R.drawable.edit_text_button_dizajn_boja);
                return false;
            }

            if(kviz == null || !kviz.getNaziv().equals(nazivKviza.getText().toString())) {
                for (String naziv : naziviKvizovaIzBaze) {
                    if (naziv.equals(nazivKviza.getText().toString())) {
                        nazivKviza.setBackgroundResource(R.drawable.edit_text_button_dizajn_boja);
                        return false;
                    }
                }
            }
            return true;
        }

        private void unesiKviz() {
            dodanaPitanja.remove(dodanaPitanja.size() - 1);
            if (kviz == null) {
                kviz = new Kviz(nazivKviza.getText().toString(), dodanaPitanja, ((Kategorija) spinnerKategorije.getSelectedItem()), "");
            }
            else {
                kviz.setNaziv(nazivKviza.getText().toString());
                kviz.setPitanja(dodanaPitanja);
                kviz.setKategorija((Kategorija) spinnerKategorije.getSelectedItem());
            }
            new UnesiKvizUBazuTask(context, getIntent().getStringExtra("kvizId") == null).execute("Unos kviza");
        }

        public UcitajKvizoveZaValidacijuNazivaTask(Context context) {
            super();
            this.context = context;
        }

        @Override
        protected Void doInBackground(String... strings) {
            try {
                konektujNaBazu();
                try {
                    JSONObject dokumenti = new JSONObject(KvizoviAkt.prebaciUString(conn.getInputStream()));
                    if(dokumenti.has("documents")) {
                        JSONArray array = dokumenti.getJSONArray("documents");

                        for (int i = 0; i < array.length(); i++)
                            naziviKvizovaIzBaze.add(array.getJSONObject(i).getJSONObject("fields").getJSONObject("naziv").getString("stringValue"));
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }

            } catch (IOException e) {
                e.printStackTrace();
            }

            zatvoriKonekciju();
            return null;
        }

        @Override
        protected void onPreExecute() {
            progressDialog = ProgressDialog.show(context, "", "Validacija u naziva kviza", true);
        }

        @Override
        protected void onPostExecute(Void aVoid) {
            progressDialog.cancel();
            if(validirajNaziv()) unesiKviz();
        }

        @Override
        public void konektujNaBazu() throws IOException {

            InputStream is = getResources().openRawResource(R.raw.secret);
            GoogleCredential credentials = GoogleCredential.fromStream(is).createScoped(Lists.newArrayList("https://www.googleapis.com/auth/datastore"));
            credentials.refreshToken();
            String token = credentials.getAccessToken();
            String urlString = "https://firestore.googleapis.com/v1/projects/projekatrma/databases/(default)/documents/Kvizovi?access_token=";
            URL url = new URL(urlString + URLEncoder.encode(token, "UTF-8"));
            conn = (HttpURLConnection) url.openConnection();
            System.out.print(urlString + token);

            conn.setRequestMethod("GET");
            conn.setRequestProperty("Content-Type", "application/json");
            conn.setRequestProperty("Accept", "application/json");
        }

        @Override
        public void zatvoriKonekciju() {
            conn.disconnect();
        }
    }

    public class UnesiKvizUBazuTask extends AsyncTask<String, Void, Void> implements IBaza {
        private HttpURLConnection conn;
        private Context context;
        private boolean dodavanje;
        private ProgressDialog progressDialog;

        public UnesiKvizUBazuTask(Context context, boolean dodavanje) {
            super();
            this.context = context;
            this.dodavanje = dodavanje;
        }

        @Override
        protected Void doInBackground(String... strings) {
            try {
                konektujNaBazu();

                String dokument = "{ \"fields\": { \"naziv\": {\"stringValue\":\"" + kviz.getNaziv() + "\"}, \"idKategorije\": { \"stringValue\": \"" + kviz.getKategorija().getIdBaza() + "\"}, \"pitanja\": {\"arrayValue\": {";
                if(kviz.getPitanja().size() > 0){
                    dokument += "\"values\": [";
                    for(int i = 0; i < kviz.getPitanja().size(); i++){
                        dokument += "{\"stringValue\": \"" + kviz.getPitanja().get(i).getId() + "\"}";
                        if(i != kviz.getPitanja().size() - 1) dokument += ", ";
                    }
                    dokument += "]";
                }

                dokument += "}}}}";
                OutputStream os = conn.getOutputStream();
                byte[] input = dokument.getBytes("utf-8");
                os.write(input, 0, input.length);


                int code = conn.getResponseCode();
                InputStream odgovor = conn.getInputStream();
                BufferedReader br = new BufferedReader(new InputStreamReader(odgovor, "utf-8"));
                StringBuilder response = new StringBuilder();
                String responseLine = null;
                while ((responseLine = br.readLine()) !=null ) {
                    response.append(responseLine.trim());
                }

                zatvoriKonekciju();

            } catch (IOException e) {
                e.printStackTrace();
            }


            return null;
        }

        @Override
        protected void onPreExecute() {
            String msg;
            if(dodavanje) msg = "Dodajem kviz u bazu";
            else msg = "Azuriram kviz u bazi";
            progressDialog = ProgressDialog.show(context, "", msg, true);
        }

        @Override
        protected void onPostExecute(Void aVoid) {
            progressDialog.cancel();
            String msg;
            if(dodavanje) msg = "Kviz je dodan u bazu";
            else msg = "Kviz je azuriran u bazi";
            Toast.makeText(context, msg,  Toast.LENGTH_SHORT).show();
            Intent vratiKvizoviAkt = new Intent(DodajKvizAkt.this, KvizoviAkt.class);
            DodajKvizAkt.this.startActivity(vratiKvizoviAkt);

        }

        @Override
        public void konektujNaBazu() throws IOException {
            InputStream is = context.getResources().openRawResource(R.raw.secret);
            GoogleCredential credentials = GoogleCredential.fromStream(is).createScoped(Lists.newArrayList("https://www.googleapis.com/auth/datastore"));
            credentials.refreshToken();
            String token = credentials.getAccessToken();
            String urlString;
            if(dodavanje)
                urlString = "https://firestore.googleapis.com/v1/projects/projekatrma/databases/(default)/documents/Kvizovi?access_token=";
            else
                urlString = "https://firestore.googleapis.com/v1/projects/projekatrma/databases/(default)/documents/Kvizovi/" + kviz.getId() + "?access_token=";
            URL url = new URL(urlString + URLEncoder.encode(token, "UTF-8"));
            conn = (HttpURLConnection) url.openConnection();

            conn.setDoOutput(true);
            if(dodavanje) conn.setRequestMethod("POST");
            else conn.setRequestMethod("PATCH");
            conn.setRequestProperty("Content-Type", "application/json");
            conn.setRequestProperty("Accept", "application/json");

        }

        @Override
        public void zatvoriKonekciju(){
            conn.disconnect();
        }
    }

}
