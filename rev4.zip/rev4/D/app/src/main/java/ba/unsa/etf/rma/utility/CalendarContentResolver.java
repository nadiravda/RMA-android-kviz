package ba.unsa.etf.rma.utility;

import android.content.ContentResolver;
import android.content.Context;
import android.database.Cursor;
import android.net.Uri;
import android.provider.CalendarContract;

import java.util.Calendar;

public class CalendarContentResolver {
    private ContentResolver contentResolver;

    private static final String[] FIELDS = {
        CalendarContract.Events.DTSTART,
        CalendarContract.Events.DTEND
    };

    private static final Uri CALENDAR_URI = Uri.parse("content://com.android.calendar/events");

    public CalendarContentResolver(Context context) {
        contentResolver = context.getContentResolver();
    }

    public boolean daLiPostojiDogadjaj(int trajanje) {
        Calendar calendar = Calendar.getInstance();

        String where = "(( " + CalendarContract.Events.DTSTART + " >= " + calendar.getTimeInMillis() + " ) AND ( " +
                CalendarContract.Events.DTSTART + " <= " + (calendar.getTimeInMillis() + trajanje) + " )) OR ((" +
                CalendarContract.Events.DTEND + " >= " + calendar.getTimeInMillis() + " ) AND ( " +
                CalendarContract.Events.DTEND + " <= " + (calendar.getTimeInMillis() + trajanje) + " )) OR ((" +
                CalendarContract.Events.DTSTART + " <= " + calendar.getTimeInMillis() + " ) AND ( " +
                CalendarContract.Events.DTEND + " >= " + (calendar.getTimeInMillis() + trajanje) + " ))";

        Cursor cursor = contentResolver.query(CALENDAR_URI, FIELDS, where, null, "DTSTART ASC");

        if(cursor.moveToFirst()) return false;

        return true;

    }
}