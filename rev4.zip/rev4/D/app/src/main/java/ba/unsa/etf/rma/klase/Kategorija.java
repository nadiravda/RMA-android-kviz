package ba.unsa.etf.rma.klase;

import java.io.Serializable;

public class Kategorija implements Serializable {
    private String naziv;
    private String id;
    private String idBaza;

    public Kategorija(String naziv, String id, String idBaza) {
        this.naziv = naziv;
        this.id = id;
        this.idBaza = idBaza;
    }

    public String getNaziv() {
        return naziv;
    }

    public void setNaziv(String naziv) {
        this.naziv = naziv;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getIdBaza() {
        return idBaza;
    }

    public void setIdBaza(String idBaza) {
        this.idBaza = idBaza;
    }
}
