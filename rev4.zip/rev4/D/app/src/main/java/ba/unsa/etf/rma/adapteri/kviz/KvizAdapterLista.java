package ba.unsa.etf.rma.adapteri.kviz;

import android.content.Context;
import android.os.Build;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.maltaisn.icondialog.IconHelper;
import com.maltaisn.icondialog.IconView;

import java.util.ArrayList;

import ba.unsa.etf.rma.R;
import ba.unsa.etf.rma.klase.Kviz;

public class KvizAdapterLista extends ArrayAdapter<Kviz> {
    private ArrayList<Kviz> kvizovi;

    public KvizAdapterLista(Context context, int resource, ArrayList<Kviz> kvizovi) {
        super(context, resource, kvizovi);
        this.kvizovi = kvizovi;
    }

    @Override
    public int getCount() {
        return super.getCount();
    }

    @Override
    public View getView(final int position, View convertView, ViewGroup parent) {
        final View novi;
        final LayoutInflater layoutInflater = (LayoutInflater) getContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE);

        novi = layoutInflater.inflate(R.layout.element_liste, null);
        final ImageView imageView = novi.findViewById(R.id.listaIkona);
        final IconHelper iconHelper = IconHelper.getInstance(novi.getContext());
        iconHelper.addLoadCallback(new IconHelper.LoadCallback() {
            @Override
            public void onDataLoaded() {
                if(kvizovi.get(position).getKategorija() != null) imageView.setImageDrawable(iconHelper.getIcon(Integer.parseInt(kvizovi.get(position).getKategorija().getId())).getDrawable(getContext()));
                else imageView.setImageResource(R.drawable.zelenikrug);
                notifyDataSetChanged();
            }
        });


        TextView textView = novi.findViewById(R.id.listaNaziv);
        textView.setText(kvizovi.get(position).getNaziv());

        return novi;
    }
}
