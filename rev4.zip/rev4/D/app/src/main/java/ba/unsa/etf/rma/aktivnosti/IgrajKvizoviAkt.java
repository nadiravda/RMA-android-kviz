package ba.unsa.etf.rma.aktivnosti;

import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.provider.AlarmClock;
import android.support.v4.app.FragmentManager;
import android.support.v7.app.AppCompatActivity;
import android.text.InputType;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import com.google.api.client.googleapis.auth.oauth2.GoogleCredential;
import com.google.common.collect.Lists;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Comparator;
import java.util.Random;

import ba.unsa.etf.rma.utility.IBaza;
import ba.unsa.etf.rma.R;
import ba.unsa.etf.rma.fragmenti.InformacijeFrag;
import ba.unsa.etf.rma.fragmenti.PitanjeFrag;
import ba.unsa.etf.rma.fragmenti.RangLista;
import ba.unsa.etf.rma.klase.IgraKviza;
import ba.unsa.etf.rma.klase.Kategorija;
import ba.unsa.etf.rma.klase.Kviz;
import ba.unsa.etf.rma.klase.Pitanje;
import ba.unsa.etf.rma.utility.KvizoviDBOpenHelper;
import ba.unsa.etf.rma.utility.Mreza;

public class IgrajKvizoviAkt extends AppCompatActivity implements PitanjeFrag.OnItemClick, InformacijeFrag.OnButtonClick {
    private FragmentManager fragmentManager;
    private InformacijeFrag informacijeFragment;
    private RangLista rangListaFragment;
    private PitanjeFrag pitanjeFragment;
    private ArrayList<Pitanje> pitanja = new ArrayList<>();
    private ArrayList<String> odgovori = new ArrayList<>();
    private ArrayList<String> rangListaString = new ArrayList<>();
    private int trenutnoPitanje = 0;
    private int tacnoOdgovorenaPitanja = 0;
    private Kviz kviz;
    private ArrayList<IgraKviza> rangLista = new ArrayList<>();
    private int sati;
    private int minute;
    private Intent alarm = null;

    private void postaviAlarmClock(){
        alarm = new Intent(AlarmClock.ACTION_SET_ALARM);
        Calendar cal = Calendar.getInstance();
        sati = cal.getTime().getHours();
        minute = cal.getTime().getMinutes();
        if (minute + Math.ceil(pitanja.size() / 2 + 1) > 60)
            sati = (sati + 1) % 24;
        minute = ((int) (minute + Math.ceil(((double) pitanja.size()) / 2)) + 1) % 60;

        alarm.putExtra(AlarmClock.EXTRA_HOUR, sati);
        alarm.putExtra(AlarmClock.EXTRA_MINUTES, minute);
        alarm.putExtra(AlarmClock.EXTRA_MESSAGE, "Isteklo je vrijeme predvidjeno za kviz");
        alarm.putExtra(AlarmClock.EXTRA_SKIP_UI, true);
        if (alarm.resolveActivity(getPackageManager()) != null) {
            startActivity(alarm);
        }
    }

    private void postaviInformacije() {
        Bundle argumentiInformacije = new Bundle();
        argumentiInformacije.putInt("odgovorenaPitanja", trenutnoPitanje);
        argumentiInformacije.putSerializable("kviz", kviz);
        argumentiInformacije.putInt("brojTacnoOdgovorenih", tacnoOdgovorenaPitanja);
        informacijeFragment = (InformacijeFrag) fragmentManager.findFragmentById(R.id.informacijePlace);
        informacijeFragment = new InformacijeFrag();
        informacijeFragment.setArguments(argumentiInformacije);
        fragmentManager.beginTransaction().replace(R.id.informacijePlace, informacijeFragment).commit();
    }

    private void postaviPitanje() {
        pitanja = kviz.getPitanja();
        if (trenutnoPitanje == 0) Collections.shuffle(pitanja, new Random(System.nanoTime()));
        if (pitanja.size() - trenutnoPitanje < 1){
            final AlertDialog.Builder builder = new AlertDialog.Builder(this);
            final EditText etIme = new EditText(this);
            etIme.setInputType(InputType.TYPE_CLASS_TEXT);
            builder.setMessage("Unesite ime za rang listu");
            builder.setView(etIme);
            final Context c = this;
            builder.setPositiveButton("Unesi", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {

                }
            });
            builder.setNegativeButton("Odustani", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    Intent vratiKvizoviAkt = new Intent(IgrajKvizoviAkt.this, KvizoviAkt.class);
                    IgrajKvizoviAkt.this.startActivity(vratiKvizoviAkt);
                }
            });

            final AlertDialog dialog = builder.create();
            dialog.show();

            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if(etIme.getText().toString().length() == 0){
                        Toast.makeText(c, "Morate unijeti ime", Toast.LENGTH_SHORT).show();
                    }
                    else{
                        dialog.dismiss();
                        if(Mreza.getStatusMreze(v.getContext())){
                            new UnesiURangListu(v.getContext(), etIme.getText().toString(), pitanja.size() == 0 ? 0 : ((double) tacnoOdgovorenaPitanja) / pitanja.size() * 100).execute("Ucitaj Rang listu");
                        }
                        else{
                            Bundle argumentiRangLista = new Bundle();
                            argumentiRangLista.putStringArrayList("rangLista", rangListaString);
                            argumentiRangLista.putInt("pozicija", -1);
                            rangListaFragment = new RangLista();
                            rangListaFragment.setArguments(argumentiRangLista);
                            fragmentManager.beginTransaction().replace(R.id.pitanjePlace, rangListaFragment).commit();
                        }
                    }
                }
            });
        }
        else{
            odgovori = pitanja.get(trenutnoPitanje).dajRandomOdgovore();
            Bundle argumentiPitanja = new Bundle();
            argumentiPitanja.putSerializable("pitanje", pitanja.size() - trenutnoPitanje < 1 ? new Pitanje("Kviz je zavrsen!", "Kviz je zavrsen!", new ArrayList<String>(), null, null) : pitanja.get(trenutnoPitanje));
            argumentiPitanja.putStringArrayList("odgovori", odgovori);
            pitanjeFragment = (PitanjeFrag) fragmentManager.findFragmentById(R.id.pitanjePlace);
            pitanjeFragment = new PitanjeFrag();
            pitanjeFragment.setArguments(argumentiPitanja);
            fragmentManager.beginTransaction().replace(R.id.pitanjePlace, pitanjeFragment).commit();
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.igraj_kvizovi_akt);


        fragmentManager = getSupportFragmentManager();
        if(Mreza.getStatusMreze(this))
            new UcitajKvizFirestoreTask(this).execute("Ucitaj kviz");
        else
            new UcitajKvizSQLTask(this).execute("Ucitaj kviz");
    }

    @Override
    public void onBackPressed() {
        Intent vratiKvizoviAkt = new Intent(IgrajKvizoviAkt.this, KvizoviAkt.class);
        IgrajKvizoviAkt.this.startActivity(vratiKvizoviAkt);
    }

    @Override
    public void onItemClicked(int pos) {
        if (pitanja.get(trenutnoPitanje).getTacan().equals(odgovori.get(pos)))
            tacnoOdgovorenaPitanja++;
        trenutnoPitanje++;

        postaviInformacije();
        postaviPitanje();
    }

    @Override
    public void onClicked() {
        Intent vratiKvizoviAkt = new Intent(IgrajKvizoviAkt.this, KvizoviAkt.class);
        IgrajKvizoviAkt.this.startActivity(vratiKvizoviAkt);
    }

    public class UcitajKvizFirestoreTask extends AsyncTask<String, Void, Void> implements IBaza {
        private HttpURLConnection connKvizovi;
        private HttpURLConnection connKategorije;
        private HttpURLConnection connPitanja;
        private Context context;
        private ProgressDialog progressDialog = null;

        private ArrayList<Kategorija> kategorijeIzBaze = new ArrayList<>();
        private ArrayList<Pitanje> pitanjaIzBaze = new ArrayList<>();

        public UcitajKvizFirestoreTask(Context context) {
            super();
            this.context = context;
        }

        @Override
        protected Void doInBackground(String... strings) {
            try {
                konektujNaBazu();
                try {
                    kategorijeIzBaze.clear();
                    JSONArray array;
                    JSONObject dokumenti = new JSONObject(KvizoviAkt.prebaciUString(connKategorije.getInputStream()));
                    if(dokumenti.has("documents")) {
                        array = dokumenti.getJSONArray("documents");
                        for (int i = 0; i < array.length(); i++) {
                            String[] name = array.getJSONObject(i).getString("name").split("/");
                            JSONObject kategorijaNaziv = array.getJSONObject(i).getJSONObject("fields").getJSONObject("naziv");
                            JSONObject kategorijaId = array.getJSONObject(i).getJSONObject("fields").getJSONObject("idIkonice");
                            String naziv = kategorijaNaziv.getString("stringValue");
                            String id = ((Integer) kategorijaId.getInt("integerValue")).toString();
                            kategorijeIzBaze.add(new Kategorija(naziv, id, name[name.length - 1]));
                        }
                    }
                    kategorijeIzBaze.add(0, new Kategorija("Sve", "902", "0"));

                    dokumenti = new JSONObject(KvizoviAkt.prebaciUString(connPitanja.getInputStream()));
                    if(dokumenti.has("documents")){
                        array = dokumenti.getJSONArray("documents");

                        for (int i = 0; i < array.length(); i++) {
                            String[] name = array.getJSONObject(i).getString("name").split("/");
                            JSONObject pitanjeNaziv = array.getJSONObject(i).getJSONObject("fields").getJSONObject("naziv");
                            JSONObject indexTacnog = array.getJSONObject(i).getJSONObject("fields").getJSONObject("indexTacnog");
                            JSONArray odgovoriJSON = array.getJSONObject(i).getJSONObject("fields").getJSONObject("odgovori").getJSONObject("arrayValue").getJSONArray("values");
                            ArrayList<String> odgovori = new ArrayList<>();
                            for (int j = 0; j < odgovoriJSON.length(); j++)
                                odgovori.add(odgovoriJSON.getJSONObject(j).getString("stringValue"));
                            String naziv = pitanjeNaziv.getString("stringValue");
                            Integer tacan = indexTacnog.getInt("integerValue");
                            pitanjaIzBaze.add(new Pitanje(naziv, naziv, odgovori, odgovori.get(tacan), name[name.length - 1]));
                        }
                    }



                    JSONObject kvizJSON = new JSONObject(KvizoviAkt.prebaciUString(connKvizovi.getInputStream()));
                    String kvizNaziv = kvizJSON.getJSONObject("fields").getJSONObject("naziv").getString("stringValue");
                    String kvizKategorijaId = kvizJSON.getJSONObject("fields").getJSONObject("idKategorije").getString("stringValue");


                    Kategorija kategorija = null;
                    for (Kategorija temp : kategorijeIzBaze) {
                        if (temp.getIdBaza().equals(kvizKategorijaId)) {
                            kategorija = temp;
                            break;
                        }
                    }


                    ArrayList<Pitanje> pitanjaUKvizu = new ArrayList<>();
                    JSONObject pitanjaKvizNiz = kvizJSON.getJSONObject("fields").getJSONObject("pitanja").getJSONObject("arrayValue");
                    if (pitanjaKvizNiz.has("values")) {
                        JSONArray pitanjaKvizId = pitanjaKvizNiz.getJSONArray("values");
                        for (int j = 0; j < pitanjaKvizId.length(); j++) {
                            String pitanjeId = pitanjaKvizId.getJSONObject(j).getString("stringValue");
                            for (Pitanje pitanje : pitanjaIzBaze)
                                if (pitanje.getId().equals(pitanjeId)) {
                                    pitanjaUKvizu.add(pitanje);
                                    break;
                                }
                        }
                    }
                    kviz = new Kviz(kvizNaziv, pitanjaUKvizu, kategorija, getIntent().getStringExtra("kvizId"));

                } catch (JSONException e) {
                    e.printStackTrace();
                }

            } catch (IOException e) {
                e.printStackTrace();
            }

            zatvoriKonekciju();
            return null;
        }

        @Override
        protected void onPreExecute() {
            progressDialog = ProgressDialog.show(context, "", "Ucitavam kviz za igru", true);
        }

        @Override
        protected void onPostExecute(Void aVoid) {
            progressDialog.cancel();
            postaviInformacije();
            postaviPitanje();
            if(pitanja.size() != 0) postaviAlarmClock();
        }

        @Override
        public void konektujNaBazu() throws IOException {
            InputStream is = getResources().openRawResource(R.raw.secret);
            GoogleCredential credentials = GoogleCredential.fromStream(is).createScoped(Lists.newArrayList("https://www.googleapis.com/auth/datastore"));
            credentials.refreshToken();
            String token = credentials.getAccessToken();
            String urlString = "https://firestore.googleapis.com/v1/projects/projekatrma/databases/(default)/documents/Kategorije?access_token=";
            URL url = new URL(urlString + URLEncoder.encode(token, "UTF-8"));
            connKategorije = (HttpURLConnection) url.openConnection();
            System.out.print(urlString + token);

            connKategorije.setRequestMethod("GET");
            connKategorije.setRequestProperty("Content-Type", "application/json");
            connKategorije.setRequestProperty("Accept", "application/json");

            is = getResources().openRawResource(R.raw.secret);
            credentials = GoogleCredential.fromStream(is).createScoped(Lists.newArrayList("https://www.googleapis.com/auth/datastore"));
            credentials.refreshToken();
            token = credentials.getAccessToken();
            urlString = "https://firestore.googleapis.com/v1/projects/projekatrma/databases/(default)/documents/Pitanja?access_token=";
            url = new URL(urlString + URLEncoder.encode(token, "UTF-8"));
            connPitanja = (HttpURLConnection) url.openConnection();
            System.out.print(urlString + token);

            connPitanja.setRequestMethod("GET");
            connPitanja.setRequestProperty("Content-Type", "application/json");
            connPitanja.setRequestProperty("Accept", "application/json");

            is = context.getResources().openRawResource(R.raw.secret);
            credentials = GoogleCredential.fromStream(is).createScoped(Lists.newArrayList("https://www.googleapis.com/auth/datastore"));
            credentials.refreshToken();
            token = credentials.getAccessToken();
            urlString = "https://firestore.googleapis.com/v1/projects/projekatrma/databases/(default)/documents/Kvizovi/" + getIntent().getStringExtra("kvizId") + "?access_token=";
            url = new URL(urlString + URLEncoder.encode(token, "UTF-8"));
            connKvizovi = (HttpURLConnection) url.openConnection();
            System.out.print(urlString + token);

            connKvizovi.setRequestMethod("GET");
            connKvizovi.setRequestProperty("Content-Type", "application/json");
            connKvizovi.setRequestProperty("Accept", "application/json");
        }

        @Override
        public void zatvoriKonekciju() {
            connKategorije.disconnect();
            connPitanja.disconnect();
            connKvizovi.disconnect();
        }
    }

    public class UnesiURangListu extends AsyncTask<String, Void, Void> implements IBaza{
        private HttpURLConnection conn;
        private String ime;
        private Context context;
        private double postotak;
        private String id;
        private ProgressDialog progressDialog;

        public UnesiURangListu(Context context, String ime, double postotak) {
            super();
            this.ime = ime;
            this.context = context;
            this.postotak = postotak;
        }

        private void azurirajRangListu() throws IOException {
            zatvoriKonekciju();
            InputStream is = context.getResources().openRawResource(R.raw.secret);
            GoogleCredential credentials = GoogleCredential.fromStream(is).createScoped(Lists.newArrayList("https://www.googleapis.com/auth/datastore"));
            credentials.refreshToken();
            String token = credentials.getAccessToken();
            String urlString;
            if(rangLista.size() == 1)
                urlString = "https://firestore.googleapis.com/v1/projects/projekatrma/databases/(default)/documents/Rangliste?access_token=";
            else
                urlString = "https://firestore.googleapis.com/v1/projects/projekatrma/databases/(default)/documents/Rangliste/" + id + "?access_token=";
            URL url = new URL(urlString + URLEncoder.encode(token, "UTF-8"));
            conn = (HttpURLConnection) url.openConnection();

            conn.setDoOutput(true);
            if(rangLista.size() == 1) conn.setRequestMethod("POST");
            else conn.setRequestMethod("PATCH");
            conn.setRequestProperty("Content-Type", "application/json");
            conn.setRequestProperty("Accept", "application/json");

            String dokument = "{ \"fields\": { \"nazivKviza\": {\"stringValue\":\"" + kviz.getNaziv() + "\"}, \"idKviza\": { \"stringValue\": \"" + kviz.getId() + "\"}, \"lista\": {\"mapValue\": {\"fields\": {";
            for(int i = 0; i < rangLista.size(); i++){
                dokument += "\"" + (i + 1) + "\": {\"mapValue\": {\"fields\": {\"" + rangLista.get(i).getImeIgraca()
                        + "\": {\"doubleValue\": " + rangLista.get(i).getProcenat() + "}}}}";
                if(i != rangLista.size() - 1) dokument += ", ";
            }
            dokument += "}}}}}";

            OutputStream os = conn.getOutputStream();
            byte[] input = dokument.getBytes("utf-8");
            os.write(input, 0, input.length);


            int code = conn.getResponseCode();
            InputStream odgovor = conn.getInputStream();
            BufferedReader br = new BufferedReader(new InputStreamReader(odgovor, "utf-8"));
            StringBuilder response = new StringBuilder();
            String responseLine = null;
            while ((responseLine = br.readLine()) !=null ) {
                response.append(responseLine.trim());
            }
        }

        @Override
        protected Void doInBackground(String... strings) {
            try {
                konektujNaBazu();
                rangLista.clear();
                JSONObject dokumenti = new JSONObject(KvizoviAkt.prebaciUString(conn.getInputStream()));
                if(dokumenti.has("documents")){
                    JSONArray array = dokumenti.getJSONArray("documents");
                    for (int i = 0; i < array.length(); i++) {
                        String idKviza = array.getJSONObject(i).getJSONObject("fields").getJSONObject("idKviza").getString("stringValue");
                        if(idKviza.equals(kviz.getId())){
                            String[] name = array.getJSONObject(i).getString("name").split("/");
                            id = name[name.length - 1];
                            JSONObject mapa = array.getJSONObject(i).getJSONObject("fields").getJSONObject("lista").getJSONObject("mapValue").getJSONObject("fields");
                            Integer pozicija = 1;
                            while(mapa.has(pozicija.toString())){
                                JSONObject igrac = mapa.getJSONObject(pozicija.toString()).getJSONObject("mapValue").getJSONObject("fields");
                                String[] temp = igrac.toString().split(":");
                                String ime = temp[0].split("\"")[1];
                                Double procenat;
                                if(temp[2].contains("\"")) procenat = Double.parseDouble(temp[2].split("\"")[1]);
                                else procenat = Double.parseDouble(temp[2].replace("}}", ""));
                                rangLista.add(new IgraKviza(kviz.getId(), ime, procenat));
                                pozicija++;
                            }
                            break;
                        }
                    }
                }
                rangLista.add(new IgraKviza(kviz.getId(), ime, postotak));
                Collections.sort(rangLista, new Comparator<IgraKviza>() {
                    @Override
                    public int compare(IgraKviza o1, IgraKviza o2) {
                        if(o1.getProcenat() < o2.getProcenat()) return 1;
                        else if(o1.getProcenat() > o2.getProcenat()) return -1;
                        return 0;
                    }
                });

                azurirajRangListu();

            } catch (IOException e) {
                e.printStackTrace();
            } catch (JSONException e) {
                e.printStackTrace();
            }
            zatvoriKonekciju();
            return null;
        }

        @Override
        protected void onPreExecute() {
            progressDialog = ProgressDialog.show(context, "", "Rang lista se ucitava iz baze", true);
        }

        @Override
        protected void onPostExecute(Void aVoid) {
            int pozicija = 0;
            boolean nijeNadjeno = true;
            for(int i = 0; i < rangLista.size(); i++){
                rangListaString.add((i + 1) + ". " + rangLista.get(i).getImeIgraca() + " (" + String.format("%.1f", rangLista.get(i).getProcenat()) + "%) ");
                if(rangLista.get(i).getImeIgraca().equals(ime) && nijeNadjeno){
                    nijeNadjeno = false;
                    pozicija = i + 1;
                }
            }
            progressDialog.cancel();
            Bundle argumentiRangLista = new Bundle();
            argumentiRangLista.putStringArrayList("rangLista", rangListaString);
            argumentiRangLista.putInt("pozicija", pozicija);
            rangListaFragment = new RangLista();
            rangListaFragment.setArguments(argumentiRangLista);
            fragmentManager.beginTransaction().replace(R.id.pitanjePlace, rangListaFragment).commit();
        }

        @Override
        public void konektujNaBazu() throws IOException {
            InputStream is = getResources().openRawResource(R.raw.secret);
            GoogleCredential credentials = GoogleCredential.fromStream(is).createScoped(Lists.newArrayList("https://www.googleapis.com/auth/datastore"));
            credentials.refreshToken();
            String token = credentials.getAccessToken();
            String urlString = "https://firestore.googleapis.com/v1/projects/projekatrma/databases/(default)/documents/Rangliste?access_token=";
            URL url = new URL(urlString + URLEncoder.encode(token, "UTF-8"));
            conn = (HttpURLConnection) url.openConnection();
            System.out.print(urlString + token);

            conn.setRequestMethod("GET");
            conn.setRequestProperty("Content-Type", "application/json");
            conn.setRequestProperty("Accept", "application/json");
        }

        @Override
        public void zatvoriKonekciju() {
            conn.disconnect();
        }
    }

    public class UcitajKvizSQLTask extends AsyncTask<String, Void, Void> {
        private Context context;

        public UcitajKvizSQLTask(Context context) {
            super();
            this.context = context;
        }

        @Override
        protected Void doInBackground(String... strings) {
            KvizoviDBOpenHelper kvizoviDBOpenHelper = new KvizoviDBOpenHelper(context, KvizoviDBOpenHelper.IME_BAZE_PODATAKA, null, KvizoviDBOpenHelper.VERZIJA_BAZE_PODATAKA);
            kviz = kvizoviDBOpenHelper.ucitajKviz(getIntent().getStringExtra("kvizId"));
            return null;
        }


        @Override
        protected void onPostExecute(Void aVoid) {
            postaviInformacije();
            postaviPitanje();
            if(pitanja.size() != 0) postaviAlarmClock();
        }


    }
}
