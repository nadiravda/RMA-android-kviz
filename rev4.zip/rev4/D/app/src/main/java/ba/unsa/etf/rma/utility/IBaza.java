package ba.unsa.etf.rma.utility;

import java.net.HttpURLConnection;

import java.io.IOException;
import java.net.URL;

public interface IBaza {
    void konektujNaBazu() throws IOException;
    void zatvoriKonekciju();
}
