package ba.unsa.etf.rma.baza;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;


public class BazaHelper extends SQLiteOpenHelper {
    public static final String DATABASE_NAME = "baza.db";
    public static final String KVIZ_TABLE = "Kviz";
    public static final String PITANJE_TABLE = "Pitanje";
    public static final String KATEGORIJA_TABLE = "Kategorija";
    public static final String ODGOVOR_TABLE = "Odgovor";
    public static final String RANG_PODACI_TABLE = "RangPodaci";
    public static final String RANG_IGRAC_TABLE = "RangIgrac";
    public static final String PITANJE_KVIZA_TABLE = "PitanjeKviza";
    public static final int DATABASE_VERSION = 1;
    public static final String ID ="_id";
    public static final String KATEGORIJA_ID ="idKategorije";
    public static final String ID_IKONICE ="idIkonice";
    public static final String ID_KVIZA ="idKviza";
    public static final String ID_PITANJA ="idPitanja";
    public static final String TACAN ="tacan";
    public static final String PROCENAT_TACNIH ="procenatTacnih";
    public static final String ODGOVOR_TEKST ="tekstOdgovora";
    public static final String POZICIJA_IGRACA ="pozicijaIgraca";
    public static final String ID_RANG_PODACI ="id_rang";
    public static final String NAZIV ="naziv";
    /*private static final String DATABASE_CREATE_KVIZ=    "CREATE TABLE "+KVIZ_TABLE+" ("+ID+"  TEXT,"+ NAZIV+" TEXT, "+ KATEGORIJA_ID+" INTEGER, PRIMARY KEY("+ID+"), FOREIGN KEY("+KATEGORIJA_ID+") REFERENCES "+KATEGORIJA_TABLE+"("+ID+") );" ;
    private static final String DATABASE_CREATE_PITANJE= "CREATE TABLE "+PITANJE_TABLE+" ( "+ID+" INTEGER PRIMARY KEY AUTOINCREMENT, "+NAZIV+" TEXT not null, "+TACAN+"TEXT not null );";
    private static final String DATABASE_CREATE_ODGOVOR= "CREATE TABLE "+ODGOVOR_TABLE+" ( "+ID+" INTEGER PRIMARY KEY AUTOINCREMENT, "+ODGOVOR_TEKST+" TEXT not null, "+ID_PITANJA+" INTEGER ,  FOREIGN KEY("+ID_PITANJA+") REFERENCES "+PITANJE_TABLE+"("+ID+") );" ;
    private static final String DATABASE_CREATE_PITANJE_KVIZA="CREATE TABLE "+PITANJE_KVIZA_TABLE+" ( "+ID+" INTEGER PRIMARY KEY AUTOINCREMENT, "+ID_KVIZA+" TEXT not null, "+ID_PITANJA+" INTEGER, FOREIGN KEY("+ID_KVIZA+") REFERENCES "+KVIZ_TABLE+"("+ID+"), FOREIGN KEY("+ID_PITANJA+") REFERENCES "+PITANJE_TABLE+"("+ID+") );" ;
    private static final String DATABASE_CREATE_RANG_PODACI= "CREATE TABLE "+RANG_PODACI_TABLE+" ( "+ID+" TEXT, "+NAZIV_KVIZA+" TEXT not  null, PRIMARY KEY("+ID+") );" ;
    private static final String DATABASE_CREATE_RANG_IGRAC= "CREATE TABLE "+RANG_IGRAC_TABLE+" ( "+ID+" INTEGER PRIMARY KEY AUTOINCREMENT, "+NAZIV+" TEXT not null, "+POZICIJA_IGRACA+" INTEGER not null)";*/
   private static final String DATABASE_CREATE_KATEGORIJA="CREATE TABLE "+ KATEGORIJA_TABLE +" ( "+ID+" text PRIMARY KEY, " +
           ""+NAZIV+" TEXT not null," +
           " "+ID_IKONICE+" TEXT not null );";
    private static final String DATABASE_CREATE_KVIZ=    "CREATE TABLE "+KVIZ_TABLE+" ( "+ID+"  TEXT, "+ NAZIV+" TEXT, "+ KATEGORIJA_ID+" text REFERENCES "+KATEGORIJA_TABLE+"("+ID+") on delete cascade, PRIMARY KEY("+ID+") );" ;
    private static final String DATABASE_CREATE_PITANJE= "CREATE TABLE "+PITANJE_TABLE+" ( "+ID+" text PRIMARY KEY , "+NAZIV+" TEXT not null, "+TACAN+" TEXT not null );";
    private static final String DATABASE_CREATE_ODGOVOR= "CREATE TABLE "+ODGOVOR_TABLE+" ( "+ID+" integer PRIMARY KEY autoincrement, "+ODGOVOR_TEKST+" TEXT not null, "+ID_PITANJA+" text REFERENCES "+PITANJE_TABLE+"("+ID+") on delete cascade );" ;
    private static final String DATABASE_CREATE_PITANJE_KVIZA="CREATE TABLE "+PITANJE_KVIZA_TABLE+" ( "+ID+" integer PRIMARY KEY autoincrement ,  "+ID_KVIZA+" TEXT NOT NULL  REFERENCES "+KVIZ_TABLE+"("+ID+") on delete cascade, "+ID_PITANJA+" text not null REFERENCES "+PITANJE_TABLE+"("+ID+") on delete cascade );" ;
    private static final String DATABASE_CREATE_RANG_PODACI= "CREATE TABLE "+RANG_PODACI_TABLE+" ( "+ID+" TEXT, "+ID_KVIZA+" TEXT not  null references "+ KVIZ_TABLE+"("+ID+") on delete cascade, "+"  PRIMARY KEY("+ID+") );" ;
    private static final String DATABASE_CREATE_RANG_IGRAC= "CREATE TABLE "+RANG_IGRAC_TABLE+" ( "+ID+" integer PRIMARY KEY autoincrement , "+NAZIV+" TEXT not null, "+POZICIJA_IGRACA+" INTEGER not null, "+PROCENAT_TACNIH+ " REAL NOT NULL, "+ ID_RANG_PODACI+" text REFERENCES "+RANG_PODACI_TABLE+"("+ID+") on delete cascade )";


    @Override
    public void onCreate(SQLiteDatabase db) {

        if (!db.isReadOnly()) {
            // Enable foreign key constraints
            db.execSQL("PRAGMA foreign_keys=ON;");
        }


        try {
            Log.d("Baza create1", "onCreate: ");
            db.execSQL(DATABASE_CREATE_KATEGORIJA);
           Log.d("Baza create2", "onCreate: ");
            db.execSQL(DATABASE_CREATE_KVIZ);
            Log.d("Baza create3", "onCreate: ");
            db.execSQL(DATABASE_CREATE_PITANJE);
            Log.d("Baza create4", "onCreate: ");
            db.execSQL(DATABASE_CREATE_ODGOVOR);
            db.execSQL(DATABASE_CREATE_PITANJE_KVIZA);
            db.execSQL(DATABASE_CREATE_RANG_PODACI);
            db.execSQL(DATABASE_CREATE_RANG_IGRAC);

        }
        catch (Exception ex) {
            Log.e("nece", "Error when creating table: " + ex.getMessage());
        }



    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

        db.execSQL(" DROP TABLE IF  EXISTS " + PITANJE_KVIZA_TABLE);
        db.execSQL(" DROP TABLE IF  EXISTS " + RANG_IGRAC_TABLE);
        db.execSQL(" DROP TABLE IF  EXISTS " + RANG_PODACI_TABLE);
        db.execSQL(" DROP TABLE IF  EXISTS " + KVIZ_TABLE);
        db.execSQL(" DROP TABLE IF  EXISTS " + PITANJE_TABLE);
        db.execSQL(" DROP TABLE IF  EXISTS " + KATEGORIJA_TABLE);
        onCreate(db);

    }

    public BazaHelper(Context context, String name, SQLiteDatabase.CursorFactory factory, int version) {
        super(context, name, factory, version);
    }



}
