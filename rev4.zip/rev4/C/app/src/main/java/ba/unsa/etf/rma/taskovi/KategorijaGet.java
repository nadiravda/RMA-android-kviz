package ba.unsa.etf.rma.taskovi;

import android.os.AsyncTask;

import com.google.api.client.googleapis.auth.oauth2.GoogleCredential;
import com.google.common.collect.Lists;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;

import ba.unsa.etf.rma.klase.Kategorija;
import ba.unsa.etf.rma.utility.InputStreamReader;

public class KategorijaGet extends AsyncTask<String, Integer, ArrayList<Kategorija>> {
    InputStream stream;
    private GoogleCredential credentials;
    OnKategorijaLoaded pozivatelj;
    public KategorijaGet(InputStream con, OnKategorijaLoaded pozivatelj) {

        this.stream = con;
        this.pozivatelj=pozivatelj;
    }

    public interface OnKategorijaLoaded{
        void onDone(ArrayList<Kategorija> kategorijas);
    }


    @Override
    protected ArrayList<Kategorija> doInBackground(String... strings) {
      ArrayList<Kategorija> kategorijas=new ArrayList<>();
        try {
        credentials= GoogleCredential.fromStream(stream).createScoped(Lists.<String>newArrayList("https://www.googleapis.com/auth/datastore"));
        credentials.refreshToken();
        String TOKEN=credentials.getAccessToken();
        String url="https://firestore.googleapis.com/v1/projects/spirala-a85a9/databases/(default)/documents/Kategorije?access_token=";
        URL urlObj=new  URL(url+ URLEncoder.encode(TOKEN, "UTF-8"));
        HttpURLConnection conn2=(HttpURLConnection)urlObj.openConnection();
        conn2.setRequestMethod("GET");
        conn2.setRequestProperty("Content-Type","application/json");
        conn2.setRequestProperty("Accept", "application/json");
        InputStream ins= new BufferedInputStream(conn2.getInputStream());
        String rezultat= InputStreamReader.convertStreamToString(ins);
        kategorijas=parseKategorije(rezultat);
    } catch (IOException | JSONException e) {
        e.printStackTrace();

    }

        return kategorijas;

    }


    private ArrayList<Kategorija> parseKategorije(String rezultat) throws JSONException {
        String projectName="projects/spirala-a85a9/databases/(default)/documents/Kategorije/";
        JSONObject jsonObject=new JSONObject(rezultat);
        JSONArray dokumenti=jsonObject.getJSONArray("documents");
        ArrayList<Kategorija> kategorije=new ArrayList<>();
        for(int i=0;i<dokumenti.length();i++){
            Kategorija kategorija=new Kategorija();
            JSONObject kategorijaBaza=dokumenti.getJSONObject(i);
            String idBaza=kategorijaBaza.getString("name");
            JSONObject field=kategorijaBaza.getJSONObject("fields");
            kategorija.setIdBaza(idBaza.replace(projectName,""));
            JSONObject objectNaziv=field.getJSONObject("naziv");
            kategorija.setNaziv(objectNaziv.getString("stringValue"));
            JSONObject objectIkonica=field.getJSONObject("idIkonice");
            kategorija.setId(objectIkonica.getString("integerValue")+"");
            kategorije.add(kategorija);
        }

        String rez="";
        for(int i=0;i<kategorije.size();i++){
            rez+=kategorije.get(i).getId()+ " " +kategorije.get(i).getIdBaza()+ " "+ kategorije.get(i).getNaziv()+ "\n";
        }

        return kategorije;
    }

    @Override
    protected void onPostExecute(ArrayList<Kategorija> kategorijas) {
        super.onPostExecute(kategorijas);
       if(pozivatelj!=null) pozivatelj.onDone(kategorijas);
    }
}


