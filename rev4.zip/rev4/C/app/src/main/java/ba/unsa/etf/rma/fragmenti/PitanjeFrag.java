package ba.unsa.etf.rma.fragmenti;

import android.app.AlertDialog;
import android.arch.lifecycle.ViewModelProviders;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.provider.AlarmClock;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;

import java.io.InputStream;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Random;

import ba.unsa.etf.rma.R;
import ba.unsa.etf.rma.klase.Kviz;
import ba.unsa.etf.rma.klase.Pitanje;
import ba.unsa.etf.rma.taskovi.PitanjaAsyncGet;
import ba.unsa.etf.rma.utility.InternetStateReceiver;
import ba.unsa.etf.rma.utility.SharedViewModel;


public class PitanjeFrag extends Fragment implements PitanjaAsyncGet.OnPitanjeLoadDone , Serializable {


    private Kviz kviz = new Kviz();
    private ArrayList<Pitanje> pitanja = new ArrayList<>();
    private TextView tekstPitanja;
    private ListView odgovoriPitanja;
    private ArrayList<String> currOdgovori = new ArrayList<>();
    private Pitanje currPitanje;
    private SharedViewModel model;
    private int clicked=-5;
    private boolean flag=false;
    private int tacni = 0;
    private String imeIgraca="Guest";
    private Context activityContext;
    private ArrayAdapter<String> adapter;
    private OnFragmentInteractionListenerPitanje mListener;


    public PitanjeFrag() {

    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }




    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.fragment_pitanje, container, false);
        model = ViewModelProviders.of(getActivity()).get(SharedViewModel.class);
        return v;
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        if (getArguments() != null) {
            if (getArguments().containsKey("kviz")) kviz = (Kviz) getArguments().get("kviz");
            if (getArguments().containsKey("mlistener")) mListener = (OnFragmentInteractionListenerPitanje) getArguments().getSerializable("mlistener");
            pitanja = kviz.getPitanja();
           /* ArrayList<String> idKvizova=new ArrayList<>();
            for(Pitanje a: pitanja){
                idKvizova.add(a.getIdBaza());

            }*/
            if(InternetStateReceiver.ismConnected()) {
                ArrayList<String> idKvizova=new ArrayList<>();
                for(Pitanje a: pitanja){
                    idKvizova.add(a.getIdBaza());

                }
                new PitanjaAsyncGet(getInputStrm(), this, false).execute(idKvizova);
                flag = false;
            }
//            else setRandom();

            //if(pitanja==null) {pitanja=new ArrayList<>(); flag=false;}

        }


        tekstPitanja = (TextView) getView().findViewById(R.id.tekstPitanja);

        odgovoriPitanja = (ListView) getView().findViewById(R.id.odgovoriPitanja);

        adapter = new ArrayAdapter<String>(activityContext, R.layout.item_list, R.id.textViewList, currOdgovori) {


            @Override
            public View getView(int position, View convertView, ViewGroup parent) {
                View v = super.getView(position, convertView, parent);

                TextView textView = v.findViewById(R.id.textViewList);
                if(clicked<0) {
                    v.setBackgroundColor(getResources().getColor(R.color.background_color));
                }
                else {
                    if(position==currPitanje.getIndexOfTacan()){
                        v.setBackgroundColor(getResources().getColor(R.color.zelena));
                    }
                    else if(clicked==position) {v.setBackgroundColor(getResources().getColor(R.color.crvena));}
                    else {
                        v.setBackgroundColor(getResources().getColor(R.color.background_color));
                    }
                }
                    if (textView != null)
                        textView.setText("" + currOdgovori.get(position));

                return v;
            }
        };

        odgovoriPitanja.setAdapter(adapter);

        odgovoriPitanja.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

                if(clicked>=0) return;
                clicked=position;
                adapter.notifyDataSetChanged();
                if (position == currPitanje.getIndexOfTacan())
                    tacni++;
                model.setInfo(tacni);
                new CountDownTimer(2000, 1000) {

                    public void onTick(long millisUntilFinished) {
                    }

                    public void onFinish() {
                        setRandom();
                        clicked=-1;
                        adapter.notifyDataSetChanged();
                    }
                }.start();
            }
        });

        if(!InternetStateReceiver.ismConnected()){
            if(pitanja!=null) onPitanjaLoaded(pitanja);
        }

    }

    private void setRandom() {
        currOdgovori.clear();
        if (pitanja.size() > 0 && flag) {
            currPitanje = getRandomPitanje();
            tekstPitanja.setText(currPitanje.getNaziv());
            currOdgovori.addAll(currPitanje.getOdgovori());
        } else if(flag) {
            createDialog();
            tekstPitanja.setText("Kviz je završen!");
        }
        adapter.notifyDataSetChanged();

    }

    private Pitanje getRandomPitanje() {
        Random generator = new Random();
        int index = generator.nextInt(pitanja.size());
        Pitanje pit = pitanja.get(index);
        pitanja.remove(index);
        return pit;
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        activityContext = context;
    }

    @Override
    public void onDetach() {
        super.onDetach();
        mListener = null;
    }

    @Override
    public void onPitanjaLoaded(ArrayList<Pitanje> pitanjes) {

        this.pitanja=pitanjes;
        if(pitanja!=null && pitanja.size()>0){

            int minute=(int)Math.ceil(pitanjes.size()/2.);
           // Log.d("alarmAktiviran", "onPitanjaLoaded: "+minute);
            Intent alarmIntent = new Intent(AlarmClock.ACTION_SET_ALARM);
            alarmIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            alarmIntent.putExtra(AlarmClock.EXTRA_MESSAGE, "Vrijeme isteklo");

            Calendar calendar = Calendar.getInstance();
            calendar.add(Calendar.MINUTE, minute);
            alarmIntent.putExtra(AlarmClock.EXTRA_HOUR, calendar.get(Calendar.HOUR_OF_DAY));
            int exactMinut=(int)Math.ceil(calendar.get(Calendar.MINUTE));
            alarmIntent.putExtra(AlarmClock.EXTRA_MINUTES,exactMinut );
            alarmIntent.putExtra(AlarmClock.EXTRA_SKIP_UI, true);
            if(getContext()!=null)  getContext().startActivity(alarmIntent);

        }
        flag=true;
        setRandom();

    }

    public interface OnFragmentInteractionListenerPitanje {
        void onFragmentInteractionPitanje(String ime);
    }

    private void createDialog(){
        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
        LayoutInflater inflater = requireActivity().getLayoutInflater();

        View mView=inflater.inflate(R.layout.dialog_layout,null);
        final TextView name=(EditText)mView.findViewById(R.id.editIme);

        builder.setView(mView)


                .setPositiveButton(R.string.signin, new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int id) {
                         if(name.getText().length()>0) imeIgraca=name.getText().toString();
                            mListener.onFragmentInteractionPitanje(imeIgraca);
                        }
                    })

                .setNegativeButton(R.string.cancel, new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        //samo se prikazuje postojeca rang lista

                    }
                });
        final AlertDialog dialog =builder.create();
        name.setOnKeyListener(new View.OnKeyListener() {
            @Override
            public boolean onKey(View v, int keyCode, KeyEvent event) {

                if( name.getText().length()>0) ((AlertDialog) dialog).getButton(AlertDialog.BUTTON_POSITIVE).setEnabled(true);
                else ((AlertDialog) dialog).getButton(AlertDialog.BUTTON_POSITIVE).setEnabled(false);
                return false;
            }
        });
        dialog.show();

    }

    private InputStream getInputStrm(){

        return getResources().openRawResource(R.raw.secret);
    }



}
