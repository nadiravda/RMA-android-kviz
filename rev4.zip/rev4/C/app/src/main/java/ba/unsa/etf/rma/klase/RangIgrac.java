package ba.unsa.etf.rma.klase;

import java.io.Serializable;
import java.util.Objects;

public class RangIgrac implements Serializable {

    private String ime;
    private double procenatTacnih;
    private int pozicija;


    public RangIgrac(String ime, double procenatTacnih) {
        this.ime = ime;
        this.procenatTacnih = procenatTacnih;
    }

    public RangIgrac() {
    }

    public String getIme() {
        return ime;
    }

    public void setIme(String ime) {
        this.ime = ime;
    }

    public double getProcenatTacnih() {
        return procenatTacnih;
    }

    public void setProcenatTacnih(double procenatTacnih) {
        this.procenatTacnih = procenatTacnih;
    }

    public int getPozicija() {
        return pozicija;
    }

    public void setPozicija(int pozicija) {
        this.pozicija = pozicija;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        RangIgrac rangIgrac = (RangIgrac) o;
        return Double.compare(rangIgrac.procenatTacnih, procenatTacnih) == 0  &&
                Objects.equals(ime, rangIgrac.ime);
    }

    @Override
    public int hashCode() {
        return Objects.hash(ime, procenatTacnih, pozicija);
    }
}
