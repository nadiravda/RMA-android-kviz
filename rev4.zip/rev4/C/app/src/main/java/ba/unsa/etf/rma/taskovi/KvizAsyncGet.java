package ba.unsa.etf.rma.taskovi;

import android.os.AsyncTask;

import com.google.api.client.googleapis.auth.oauth2.GoogleCredential;
import com.google.common.collect.Lists;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;

import ba.unsa.etf.rma.klase.DataAccessLayer;
import ba.unsa.etf.rma.klase.Kategorija;
import ba.unsa.etf.rma.klase.Kviz;
import ba.unsa.etf.rma.klase.Pitanje;
import ba.unsa.etf.rma.utility.InputStreamReader;

public class KvizAsyncGet extends AsyncTask<Kategorija, Integer, ArrayList<Kviz>> {


    private InputStream is;
    private GoogleCredential credentials;
    private OnKvizoviLoaded pozivatelj;


    public interface OnKvizoviLoaded{
        void onDoneKviz(ArrayList<Kviz> kvizovi);
    }

    public KvizAsyncGet(InputStream is, OnKvizoviLoaded pozivatelj) {
        this.is = is;
        this.pozivatelj = pozivatelj;
    }

    @Override
    protected ArrayList<Kviz> doInBackground(Kategorija... strings) {
    ArrayList<Kviz> kvizovi=new ArrayList<>();

    String upit="{\n" +
            " \"structuredQuery\": {\n" +
            "  \"select\": {\n" +
            "   \"fields\": [\n" +
            "    {\n" +
            "     \"fieldPath\": \"naziv\"\n" +
            "    },\n" +
            "    {\n" +
            "     \"fieldPath\": \"idKategorije\"\n" +
            "    },\n"+
            "    {\n" +
            "     \"fieldPath\": \"pitanja\"\n" +
            "    }\n" +
            "   ]\n" +
            "  },\n" +
            "  \"from\": [\n" +
            "   {\n" +
            "    \"collectionId\": \"Kvizovi\"\n" +
            "   }\n" +
            "  ]\n";
         String kat=   "  ,\"where\": {\n" +
            "   \"fieldFilter\": {\n" +
            "    \"field\": {\n" +
            "     \"fieldPath\": \"idKategorije\"\n" +
            "    },\n" +
            "    \"op\": \"EQUAL\",\n" +
            "    \"value\": {\n" +
            "     \"stringValue\": \""+strings[0].getIdBaza()+"\"\n" +
            "    }\n" +
            "   }\n" +
            "  }\n" +
            " }\n" +
            "}";


         String sve = " }\n" +
                 "}";
         if(strings[0].equals(Kategorija.kategorijaSvi())) upit+=sve;
         else upit=upit+kat;

        try {

            credentials= GoogleCredential.fromStream(is).createScoped(Lists.<String>newArrayList("https://www.googleapis.com/auth/datastore"));
            credentials.refreshToken();
            String TOKEN=credentials.getAccessToken();
            String url="https://firestore.googleapis.com/v1/projects/spirala-a85a9/databases/(default)/documents/:runQuery?access_token=";


            URL urlObj=new  URL(url+ URLEncoder.encode(TOKEN, "UTF-8"));
            HttpURLConnection conn2=(HttpURLConnection)urlObj.openConnection();
            conn2.setDoInput(true);
            conn2.setRequestMethod("POST");
            conn2.setRequestProperty("Content-Type","application/json");
            conn2.setRequestProperty("Accept", "application/json");

            try (OutputStream os = conn2.getOutputStream()) {
                byte[] input = upit.getBytes("UTF-8");
                os.write(input, 0, input.length);

            }
            int code=conn2.getResponseCode();
            InputStream ins= new BufferedInputStream(conn2.getInputStream());
            String rezultat= InputStreamReader.convertStreamToString(ins);
            kvizovi=parseKvizovi(rezultat, strings[0]);

        } catch (IOException | JSONException e) {
            e.printStackTrace();
        }

        return kvizovi;

    }

    private ArrayList<Kviz> parseKvizovi(String rezultat, Kategorija kategorija) throws JSONException {
        ArrayList<Kviz> kvizovi=new ArrayList<>();
       String novi="{\"documents\" :  \n"+rezultat+"}";

       String projectName="projects/spirala-a85a9/databases/(default)/documents/Kvizovi/";
        JSONObject jsonObject=new JSONObject(novi);
        JSONArray niz=jsonObject.getJSONArray("documents");
        for(int i=0;i<niz.length();i++){
            JSONObject item=niz.getJSONObject(i);
            Kviz kviz=new Kviz();
            JSONObject doc=item.getJSONObject("document");
            kviz.setId(doc.getString("name").replace(projectName, ""));
            JSONObject object=doc.getJSONObject("fields");
            JSONObject objectNaziv=object.getJSONObject("naziv");
            kviz.setNaziv(objectNaziv.getString("stringValue"));
            String id=object.getJSONObject("idKategorije").getString("stringValue");
            if(kategorija.equals(Kategorija.kategorijaSvi())) kviz.setKategorija(DataAccessLayer.getInstance().dajKategoriju(id));
            else kviz.setKategorija(kategorija);
            if(kviz.getKategorija()==null) kviz.setKategorija(kategorija);
            JSONObject objectIkonica=object.getJSONObject("pitanja");
            kviz.setPitanja(parsePitanja(objectIkonica));

           kvizovi.add(kviz);

        }
        return kvizovi;

    }

    private ArrayList<Pitanje> parsePitanja(JSONObject objectIkonica) throws JSONException {

        JSONObject pitanja=objectIkonica.getJSONObject("arrayValue");
        JSONArray nizPitanja;
        ArrayList<Pitanje> ucitanaPitanja=new ArrayList<>();
        try {
            nizPitanja = pitanja.getJSONArray("values");
            for(int i=0;i<nizPitanja.length();i++){
                JSONObject item=nizPitanja.getJSONObject(i);
                Pitanje pitanje=new Pitanje();
                pitanje.setId(item.getString("stringValue"));
                ucitanaPitanja.add(pitanje);
            }
        }
        catch(JSONException err){

        }
        return ucitanaPitanja;
    }

    @Override
    protected void onPostExecute(ArrayList<Kviz> kvizs) {
        super.onPostExecute(kvizs);
        pozivatelj.onDoneKviz(kvizs);
    }
}
