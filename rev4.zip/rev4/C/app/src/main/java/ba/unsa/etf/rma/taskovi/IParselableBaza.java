package ba.unsa.etf.rma.taskovi;

public interface IParselableBaza {

    String getIdBaza();
    String getNaziv();
}
