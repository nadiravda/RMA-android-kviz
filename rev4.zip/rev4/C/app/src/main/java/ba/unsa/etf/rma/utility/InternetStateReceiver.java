package ba.unsa.etf.rma.utility;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;


public class InternetStateReceiver extends BroadcastReceiver {
    //ovo srediti


    //todo i ovdje bilo false
    private static boolean mConnected=false;


    //ovo srediti

    public void setAction(IReceiverAction action) {
        this.action = action;
    }

    private IReceiverAction action;

    public InternetStateReceiver() {

    }

    @Override
    public void onReceive(Context context, Intent intent) {

        final ConnectivityManager connectivityManager = (ConnectivityManager) context
                .getSystemService(Context.CONNECTIVITY_SERVICE);
        boolean prev = mConnected;
        NetworkInfo activeNetwork = connectivityManager.getActiveNetworkInfo();
        mConnected = activeNetwork != null && activeNetwork.isConnectedOrConnecting();
        if(prev != mConnected && action!=null) {
            if (mConnected) {
                 action.enable();
            } else  {
                action.disable();
            }
        }

    }

    public static boolean ismConnected() {
        return mConnected;
    }
}
