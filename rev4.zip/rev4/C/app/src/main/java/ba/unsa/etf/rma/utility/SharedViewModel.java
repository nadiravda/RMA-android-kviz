package ba.unsa.etf.rma.utility;

import android.arch.lifecycle.MutableLiveData;
import android.arch.lifecycle.ViewModel;

public class SharedViewModel extends ViewModel {
    private final MutableLiveData info=new MutableLiveData();

    public void setInfo(int inf){
        info.setValue(inf);
    }
    public MutableLiveData getInfo(){
        return info;
    }
}
