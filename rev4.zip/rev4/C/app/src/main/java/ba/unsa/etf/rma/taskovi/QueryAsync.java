package ba.unsa.etf.rma.taskovi;

import android.os.AsyncTask;

import com.google.api.client.googleapis.auth.oauth2.GoogleCredential;
import com.google.common.collect.Lists;

import java.io.BufferedInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;

import ba.unsa.etf.rma.utility.InputStreamReader;


public class QueryAsync extends AsyncTask<IParselableBaza, Integer, String> {

    private InputStream stream;
    private GoogleCredential credentials;
    private IParselableBaza object;
    private QueryExecutor pozivatelj;

    public QueryAsync(InputStream stream, QueryExecutor pozivatelj) {
        this.stream = stream;
        this.pozivatelj = pozivatelj;
    }

    public interface  QueryExecutor{
        void onQueryExecuted(String vrijednost);
    }


    @Override
    protected String doInBackground(IParselableBaza... iParselableBazas) {
        String rezultat="";
        try {
            credentials=GoogleCredential.fromStream(stream).createScoped(Lists.<String>newArrayList("https://www.googleapis.com/auth/datastore"));
            object=iParselableBazas[0];
            HttpURLConnection conn = getConnection();

            try (OutputStream os = conn.getOutputStream()) {
                byte[] input = TaskExec.getStringZaQuery(object).getBytes("UTF-8");
                os.write(input, 0, input.length);

            }

            int code = conn.getResponseCode();
            InputStream ins= new BufferedInputStream(conn.getInputStream());
            rezultat= InputStreamReader.convertStreamToString(ins);


        } catch (IOException e) {
            e.printStackTrace();
        }


        return rezultat;
    }

    private HttpURLConnection getConnection() throws IOException {

        credentials.refreshToken();
        String TOKEN=credentials.getAccessToken();
        String url="https://firestore.googleapis.com/v1/projects/spirala-a85a9/databases/(default)/documents:runQuery?access_token=";
        URL urlObj=new  URL(url+ URLEncoder.encode(TOKEN, "UTF-8"));
        HttpURLConnection conn=(HttpURLConnection)urlObj.openConnection();
        conn.setDoInput(true);
        conn.setRequestMethod("POST");
        conn.setRequestProperty("Content-Type", "application/json");
        conn.setRequestProperty("Accept", "application/json");

        return  conn;
    }

    @Override
    protected void onPostExecute(String aBoolean) {
        super.onPostExecute(aBoolean);
        pozivatelj.onQueryExecuted(aBoolean);
    }
}
