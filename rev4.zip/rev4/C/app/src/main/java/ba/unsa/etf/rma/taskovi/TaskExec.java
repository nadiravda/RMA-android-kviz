package ba.unsa.etf.rma.taskovi;


import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.IllegalFormatException;
import java.util.Iterator;

import ba.unsa.etf.rma.klase.Kategorija;
import ba.unsa.etf.rma.klase.Kviz;
import ba.unsa.etf.rma.klase.Pitanje;
import ba.unsa.etf.rma.klase.RangIgrac;
import ba.unsa.etf.rma.klase.RangPodaci;


public class TaskExec {



    //Factory pattern
    public static String getStringZaUnos(IParselableBaza objekat) {
        if (objekat instanceof Kviz) {
            Kviz kviz = (Kviz) objekat;
            return getStringZaKviz(kviz);
        } else if (objekat instanceof Kategorija) {
            Kategorija kategorija=(Kategorija) objekat;
            return getStringZaKategoriju(kategorija);
        }
        else if(objekat instanceof Pitanje){
            Pitanje pitanje=(Pitanje) objekat;
            return getStringZaPitanje(pitanje);
        }
        else if(objekat instanceof  RangPodaci){
            RangPodaci rp=(RangPodaci) objekat;
            return getStringZaRangListu(rp);
        }
       return "";
    }

    public static String getNazivKolekcije(IParselableBaza objekat){
        if (objekat instanceof Kviz) {
            return "Kvizovi";

        } else if (objekat instanceof Kategorija) {
            return "Kategorije?documentId=";

        }
        else if(objekat instanceof Pitanje){
           return "Pitanja?documentId=";
        }
        else if(objekat instanceof RangPodaci)
            return "Rangliste";
        return "Nova";

    }


    private static String getStringZaKviz(Kviz kviz){
        String dok = "{\"fields\": {\"naziv\": {\"stringValue\": \"" + kviz.getNaziv() + "\"}," +
                "\"idKategorije\": {\"stringValue\": \"" + kviz.getKategorija().getIdBaza() + "\"}, \n" +
                stringZaPitanjaKviza(kviz.getPitanja());
        return  dok;

    }

    private static String getStringZaKategoriju(Kategorija kategorija){
        int id=Integer.parseInt(kategorija.getId());

        String dok="{\"fields\": {\"naziv\": {\"stringValue\": \""+kategorija.getNaziv()+"\"}," +
                "\"idIkonice\": {\"integerValue\": \""+id+"\"}}}\n";

        return dok;

    }

    private static String getStringZaPitanje(Pitanje pitanje){
        ArrayList<String> a=pitanje.getOdgovori();

        String unosNiza="";
        for(int i=0;i<a.size();i++){

            unosNiza+="{\n"+
                    " \"stringValue\": \""+a.get(i)+"\"\n" +
                    "}";
            if(i!=(a.size()-1)){
                unosNiza+=',';
            }
            unosNiza+="\n";
        }

        String unos="{\"fields\": {\n" +
                "            \"naziv\": {\n" +
                "              \"stringValue\": \""+pitanje.getNaziv()+"\"\n" +
                "            },\n" +
                "            \"odgovori\": {\n" +
                "              \"arrayValue\": {\n" +
                "                \"values\": [\n" +
                unosNiza+
                "                ]\n" +
                "              }\n" +
                "            },\n" +
                "            \"indexTacnog\": {\n" +
                "              \"integerValue\": \""+pitanje.getIndexOfTacan()+"\"\n" +
                "            }\n" +
                "          }}";


        return unos;

    }

    private static String stringZaPitanjaKviza(ArrayList<Pitanje> pitanja) {


        ArrayList<String> idPitanja=new ArrayList<>();
        for(Pitanje a: pitanja){
            idPitanja.add(a.getIdBaza());
        }

        String unosNiza1,imaP="";
        String imap1="";
        if(idPitanja.size()>0)  {
            imaP="   \"values\": [\n";
            imap1="                ]\n";
        }
        unosNiza1 = "\"pitanja\": {\n" +
                "   \"arrayValue\": {\n" +
                imaP;
        for (int i = 0; i < idPitanja.size(); i++) {

            unosNiza1 += "{\n" +
                    " \"stringValue\": \"" + idPitanja.get(i) + "\"\n" +
                    "}";
            if (i != (idPitanja.size() - 1)) {
                unosNiza1 += ',';
            }
            unosNiza1 += "\n";
        }

        unosNiza1+=imap1+  "              }\n" +
                "            }}}\n";
        return unosNiza1;

    }

    public static String getStringZaQuery(IParselableBaza object) {

        String kolekcija="";
        if(object instanceof Kviz) kolekcija="Kvizovi";
        else if(object instanceof Kategorija) kolekcija="Kategorije";
        else if(object instanceof Pitanje) kolekcija="Pitanja";
        else if(object instanceof RangPodaci) return stringZaRangQuery(object);

        String query="{\n" +
                " \"structuredQuery\": {\n" +
                "  \"select\": {\n" +
                "   \"fields\": [\n" +
                "    {\n" +
                "     \"fieldPath\": \"naziv\"\n" +
                "    }\n" +
                "   ]\n" +
                "  },\n" +
                "  \"from\": [\n" +
                "   {\n" +
                "    \"collectionId\": \""+kolekcija+"\"\n" +
                "   }\n" +
                "  ],\n" +
                "  \"where\": {\n" +
                "   \"fieldFilter\": {\n" +
                "    \"field\": {\n" +
                "     \"fieldPath\": \"naziv\"\n" +
                "    },\n" +
                "    \"op\": \"EQUAL\",\n" +
                "    \"value\": {\n" +
                "     \"stringValue\": \""+object.getNaziv()+"\"\n" +
                "    }\n" +
                "   }\n" +
                "  }\n" +
                " }\n" +
                "}";

        return query;

    }

    private static String stringZaRangQuery(IParselableBaza object) {

        String query="{\n" +
                " \"structuredQuery\": {\n" +
                "  \"select\": {\n" +
                "   \"fields\": [\n" +
                "    {\n" +
                "     \"fieldPath\": \"nazivKviza\"\n" +
                "    },\n" +
                "    {\n" +
                "     \"fieldPath\": \"lista\"\n" +
                "    }\n" +
                "   ]\n" +
                "  },\n" +
                "  \"from\": [\n" +
                "   {\n" +
                "    \"collectionId\": \""+"Rangliste"+"\"\n" +
                "   }\n" +
                "  ],\n" +
                "  \"where\": {\n" +
                "   \"fieldFilter\": {\n" +
                "    \"field\": {\n" +
                "     \"fieldPath\": \"nazivKviza\"\n" +
                "    },\n" +
                "    \"op\": \"EQUAL\",\n" +
                "    \"value\": {\n" +
                "     \"stringValue\": \""+object.getNaziv()+"\"\n" +
                "    }\n" +
                "   }\n" +
                "  }\n" +
                " }\n" +
                "}";

        return query;


    }

    public static String getStringZaRangListu(RangPodaci podaci){


        String dok="{\n" +
                "      \"fields\": {\n" +
                "        \"lista\": {\n" +unosVrijednostiMapa(podaci.getIgraci())+
                            "}\n" +
            "          \n" +
            "        ,\n" +
            "        \"nazivKviza\": {\n" +
            "          \"stringValue\": \""+podaci.getNaziv()+"\"\n" +
            "        }\n" +
            "      }\n" +
            "    }";

             return dok;

    }

    private static String unosVrijednostiMapa(ArrayList<RangIgrac> igraci){

        String unos="\"mapValue\": {\n" +
                "     \"fields\": {\n" ;

        for(int i=0;i<igraci.size();i++){

            unos+="\""+igraci.get(i).getPozicija()+"\": {\n" +
                    " \"mapValue\": {\n" +
                    "   \"fields\": {\n"+
                    "     \""+igraci.get(i).getIme()+"\": {\n"+
                    "      \"doubleValue\": "+"\""+igraci.get(i).getProcenatTacnih()+"\" \n"+
                    "     }\n" +
                    "    }\n" +
                    "  }\n" +
                    "}\n" ;
            if(i!=igraci.size()-1) unos+=',';

        }
        return unos+"}}";

    }

    public static RangPodaci parseRang(String vrijednost) {
        RangPodaci rp=new RangPodaci();
        String novi="{\"documents\" :  \n"+vrijednost+"}";
        JSONObject jsonObject= null;
        if(novi.contains("name")) {
            try {
                jsonObject = new JSONObject(novi);
                JSONArray niz = jsonObject.getJSONArray("documents");
                JSONObject item = niz.getJSONObject(0);
                JSONObject doc = item.getJSONObject("document");
                rp=parseRangItem(doc);

            } catch (JSONException | IllegalFormatException e) {
                e.printStackTrace();
            }
        }
        return rp;
    }

    public static RangPodaci parseRangItem(JSONObject doc) throws JSONException {

        RangPodaci rp=new RangPodaci();
        ArrayList<RangIgrac> parsed=new ArrayList<>();
        String id = doc.getString("name").replace("projects/spirala-a85a9/databases/(default)/documents/Rangliste/", "");
        rp.setId(id);
        JSONObject fields = doc.getJSONObject("fields");

        Iterator<String> keys = fields.keys();

        while (keys.hasNext()) {
            String key = (String) keys.next();
            if (key.equals("lista")) {
                JSONObject value = fields.getJSONObject("lista").getJSONObject("mapValue").getJSONObject("fields");
                Iterator<String> keysLista = value.keys();
                while (keysLista.hasNext()) {
                    RangIgrac rIgrac = new RangIgrac("Guest",0.0);
                    String keyL = keysLista.next();
                    try {
                        rIgrac.setPozicija(Integer.parseInt(keyL.trim()));
                    } catch(NumberFormatException e){

                    }
                    JSONObject outer = value.getJSONObject(keyL.trim());
                    JSONObject obj = outer.getJSONObject("mapValue").getJSONObject("fields");
                    Iterator<String> keyS = obj.keys();
                   if(!keys.hasNext()){
                        outer = value.getJSONObject(keyL.trim());
                        obj = outer.getJSONObject("mapValue").getJSONObject("fields");
                        keyS = obj.keys();


                    }
                    while(keys.hasNext()) {
                        String keyIme = keyS.next();
                        if(keyIme!=null) {
                            rIgrac.setIme(keyIme);
                            double d = obj.getJSONObject(keyIme).getDouble("doubleValue");
                            rIgrac.setProcenatTacnih(d);
                            break;
                        }
                    }
                    parsed.add(rIgrac);
                }
            } else if (key.equals("nazivKviza")) {
                String naziv = fields.getJSONObject(key).getString("stringValue");
                rp.setNaziv(naziv);
            }

        }
        rp.setIgraci(parsed);
        return rp;
    }

}
