package ba.unsa.etf.rma.klase;


import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Scanner;
import java.util.Set;

public class KvizParser {

private DataAccessLayer dao=DataAccessLayer.getInstance();
private Context context;
private Kviz kviz=null;


    public KvizParser(Context context) {
        this.context = context;
    }



    public Kviz importujKviz(InputStream stream){
        try {
            importujKviz(readTextFromInputStream(stream));
        } catch (IOException e) {
            e.printStackTrace();
        }
    return kviz;

    }

    private ArrayList<String> readTextFromInputStream(InputStream inputStream) throws IOException {

        BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream));
        String line = "";
        ArrayList<String> lines = new ArrayList<>();
        while ((line = reader.readLine()) != null) {
            System.out.println(line);
            lines.add(line);
        }
        if (inputStream != null) inputStream.close();
        return lines;
    }

    private void importujKviz(ArrayList<String> input) {

        ArrayList<Pitanje> pitanja = new ArrayList<>();
        String nazivKviza = "", nazivK = "";
        Iterator<String> scanner = input.iterator();
        int brojPitanja = 0;

        if (scanner.hasNext()) {
            ArrayList<String> podaciOKvizu = new ArrayList<>();
            podaciOKvizu.addAll(getRecordFromLine(scanner.next()));
            if (podaciOKvizu.size() ==3) {
                nazivKviza = podaciOKvizu.get(0);
                if (dao.nalaziSeKviz(nazivKviza)) {
                    alertDialog("Kviz kojeg importujete već postoji!");
                    return;
                }
                nazivK = podaciOKvizu.get(1).trim();
                brojPitanja = Integer.parseInt(podaciOKvizu.get(2).trim());
            } else {alertDialog("Datoteka kviza kojeg importujete nema ispravan format!");
                return;
            }

        } else {alertDialog("Datoteka kviza kojeg importujete nema ispravan format!"); return;}

        while (scanner.hasNext()) {
            Pitanje p = dajPitanje(getRecordFromLine(scanner.next()));
            if (p != null) {
                if (pitanja.contains(p)){
                    alertDialog("Kviz nije ispravan postoje dva pitanja sa istim nazivom!");
                    return;
                }
                pitanja.add(p);
            }
            else return;
        }
        if (pitanja.size() != brojPitanja) {
            alertDialog("Kviz kojeg importujete ima neispravan broj pitanja!");
            return;
        }
        kviz=new  Kviz(nazivKviza, pitanja, new Kategorija(nazivK,"938"));

    }

    private ArrayList<String> getRecordFromLine(String line) {
        ArrayList<String> values = new ArrayList<String>();
        try (Scanner rowScanner = new Scanner(line)) {
            rowScanner.useDelimiter(",");
            while (rowScanner.hasNext()) {
                values.add(rowScanner.next().trim());
            }
        }
        return values;
    }

    private Pitanje dajPitanje(ArrayList<String> podaciOPitanju) {
        String nazivPitanja = "";
        int tacan = 0, brojOdgovora = 0;
        if (podaciOPitanju.size() >= 3) {
            nazivPitanja = podaciOPitanju.get(0);
            try {
                brojOdgovora = Integer.parseInt(podaciOPitanju.get(1).trim());
            }
            catch (Exception e){
                alertDialog("Kviz kojeg importujete ima neispravan format!");
                return null;
            }
            tacan = Integer.parseInt(podaciOPitanju.get(2).trim());
        }
        if (podaciOPitanju.size() - 3 != brojOdgovora) {
            alertDialog("Kviz kojeg importujete ima neispravan broj odgovora!");
            return null;
        }

        ArrayList<String> odg = new ArrayList<>();
        odg.addAll(podaciOPitanju.subList(3, podaciOPitanju.size()));
        Set<String> skup= new HashSet<String>();
        skup.addAll(odg);
        if(skup.size()!=odg.size()){
            alertDialog("Kviz kojeg importujete nije ispravan postoji ponavljanje odgovora!");
            return null;
        }
        if (tacan < 0 || tacan >= odg.size()) {
            alertDialog("Kviz kojeg importujete ima neispravan index tačnog odgovora!");
            return null;
        }

        return new Pitanje(nazivPitanja, nazivPitanja, odg.get(tacan), odg);
    }

    private void alertDialog(String text) {
        AlertDialog.Builder dialog = new AlertDialog.Builder(context);
        dialog.setMessage(text);
        dialog.setTitle("Upozorenje");
        dialog.setPositiveButton("OK",
                new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog,
                                        int which) {
                    }
                });
        AlertDialog alertDialog = dialog.create();
        alertDialog.show();
    }











}
