package ba.unsa.etf.rma.aktivnosti;

import android.Manifest;
import android.app.AlertDialog;
import android.content.ContentResolver;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.provider.CalendarContract;
import android.support.v4.app.ActivityCompat;
import android.support.v4.app.FragmentManager;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.AdapterView;
import android.widget.FrameLayout;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.Toast;

import java.io.InputStream;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;

import ba.unsa.etf.rma.R;
import ba.unsa.etf.rma.adapteri.ItemAdapter;
import ba.unsa.etf.rma.adapteri.SpinAdapter;
import ba.unsa.etf.rma.baza.BazaHelper;
import ba.unsa.etf.rma.fragmenti.DetailFrag;
import ba.unsa.etf.rma.fragmenti.ListaFrag;
import ba.unsa.etf.rma.klase.DataAccessLayer;
import ba.unsa.etf.rma.klase.Kategorija;
import ba.unsa.etf.rma.klase.Kviz;
import ba.unsa.etf.rma.klase.RangIgrac;
import ba.unsa.etf.rma.klase.RangPodaci;
import ba.unsa.etf.rma.taskovi.AsyncPostPatch;
import ba.unsa.etf.rma.taskovi.IParselableBaza;
import ba.unsa.etf.rma.taskovi.QueryAsync;
import ba.unsa.etf.rma.taskovi.TaskExec;
import ba.unsa.etf.rma.utility.IReceiverAction;
import ba.unsa.etf.rma.utility.InternetStateReceiver;


public class KvizoviAkt extends AppCompatActivity implements ListaFrag.OnFragmentInteractionListener,DataAccessLayer.DataLoader, AsyncPostPatch.OnUploaded,
        QueryAsync.QueryExecutor, IReceiverAction {
    private static BazaHelper helper;
    private final int CALENDER_REQUEST=13;
    IntentFilter filter = new IntentFilter();
    private DataAccessLayer dao = DataAccessLayer.getInstance();
    private Spinner spinner;
    private SpinAdapter spAdapter;
    private ItemAdapter adapter;
    private Boolean siril = false,prvi_put=false;
    private ListaFrag listaFrag;
    private RangPodaci rp;
    private InternetStateReceiver receiver=new InternetStateReceiver();
    private int pozicija=0, doAlarma=0;

    public static BazaHelper getHelper() {
        return helper;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        filter.addAction(android.net.ConnectivityManager.CONNECTIVITY_ACTION);
        receiver.setAction(this);
        prvi_put=true;
        helper = new BazaHelper(getApplicationContext(),
                BazaHelper.DATABASE_NAME,null,
                BazaHelper.DATABASE_VERSION);
        dao.ucitajIzBaze(helper);

        FragmentManager fm = getSupportFragmentManager();
        FrameLayout listPlace = (FrameLayout) findViewById(R.id.listPlace);
        if (listPlace != null) {
            siril = true;

            listaFrag = (ListaFrag) fm.findFragmentById(R.id.listPlace);
            if (listaFrag == null) {
                listaFrag = new ListaFrag();
                fm.beginTransaction().replace(R.id.listPlace, listaFrag).commit();
            }

            onFragmentInteraction(0);
        }
        dao.setPozivatelj(this);
        if (!siril) {
            ListView quizList = (ListView) findViewById(R.id.lvKvizovi);
            spinner = (Spinner) findViewById(R.id.spPostojeceKategorije);

            spAdapter = new SpinAdapter(getBaseContext(), android.R.layout.simple_spinner_item, dao.getKategorije());
            spAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
            spinner.setAdapter(spAdapter);
            adapter = new ItemAdapter<Kviz>(this, dao.getKvizovi());
            adapter.addData(Kviz.dodajNovi());
            quizList.setAdapter(adapter);
            spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                @Override
                public void onItemSelected(AdapterView<?> parent, View view, final int position, long id) {

                    adapter.setData(promjenaKat());
                    adapter.notifyDataSetChanged();
                }

                @Override
                public void onNothingSelected(AdapterView<?> parent) {

                }
            });
            quizList.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {

                                                    @Override
                                                    public boolean onItemLongClick(AdapterView<?> parent, View view, int position, long id) {
                                                        Intent showDetailActivity = new Intent(getApplicationContext(), DodajKvizAkt.class);
                                                        if (position != dao.getKvizovi().size() - 1) {
                                                        if(InternetStateReceiver.ismConnected()) new QueryAsync(getInputStrm(), getQueryExec()).execute(new RangPodaci(dao.getKvizovi().get(position).getNaziv(), new ArrayList<RangIgrac>()));
                                                            showDetailActivity.putExtra("kviz", dao.getKvizovi().get(position));
                                                            showDetailActivity.putExtra("pos", position);
                                                        }
                                                        startActivityForResult(showDetailActivity, 2);
                                                        return true;
                                                    }
                                                }
            );

            quizList.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                @Override
                public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                    if (position == dao.getKvizovi().size() - 1) return;
                   doAlarma=(int)Math.ceil(dao.getKvizovi().get(position).getPitanja().size()/2.);
                   pozicija=position;
                   checkEvent();
                }
            });
        }
    }

    private void proceedToQuiz(int position){
        Intent in = new Intent(getApplicationContext(), IgrajKvizAkt.class);
        in.putExtra("kviz", dao.getKvizovi().get(position));
        startActivityForResult(in, 5);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (siril) {
            if (listaFrag != null) listaFrag.dataSetChanged();
            return;
        }
        spAdapter.setValues(dao.getKategorijeBaza(getInputStrm()));
        spAdapter.notifyDataSetChanged();

        if (resultCode != 2) adapter.setData(promjenaKat());
        else {
            if(!InternetStateReceiver.ismConnected()) {
                dao.setKvizovi(dao.promjenaKat((Kategorija) spinner.getSelectedItem()));
                adapter.setData(dao.getKvizovi());
            }
        }
        adapter.notifyDataSetChanged();
    }

    private ArrayList<Kviz> promjenaKat() {
        //na osnovu izabrane
        if (!siril)  {
           if(!prvi_put){
               return  dao.getKvizoviBaza(getInputStrm(), (Kategorija) spinner.getSelectedItem());
           }
           prvi_put=false;
        }
        return dao.getKvizovi();
    }

    @Override
    public void onFragmentInteraction(int kategorija) {
        Bundle args = new Bundle();
        args.putInt("position", kategorija);
        DetailFrag details = new DetailFrag();
        details.setArguments(args);
        if (siril) {
            getSupportFragmentManager().beginTransaction().replace(R.id.detailPlace, details).commit();
        }
    }

    @Override
    public void onDataLoaded(String idDokKategorije) {
        if (idDokKategorije.equals("kategorije")) {
            spAdapter.setValues(dao.getKategorije());
            spAdapter.notifyDataSetChanged();
        }
        if (idDokKategorije.equals("kviz")) {
                 //kad je oznacena kat svi, a osvjezavamo
                if(((Kategorija) spinner.getSelectedItem()).equals(Kategorija.kategorijaSvi()))
                {
                    dao.setSviKvizovi(dao.getKvizovi());
                    adapter.setData(dao.getKvizovi());
                    adapter.addData(Kviz.dodajNovi());
                }
                //obicni query za kategoriju
                else if(dao.getKvizovi().size()<dao.getSviKvizovi().size()){
                    adapter.setData(dao.getKvizovi());
                    adapter.addData(Kviz.dodajNovi());
                }
                //kad je neka druga kategorija, ali ucitamo sve kvizove, jer zelimo osvjeziti i lokalno stanje
                else {
                    dao.setKvizovi(dao.promjenaKat((Kategorija) spinner.getSelectedItem()));
                    adapter.setData(dao.getKvizovi());
                }
                adapter.notifyDataSetChanged();
        }
        else if (idDokKategorije.equals("kvizUpload")) {
                promjenaKat();
        }
        else if(idDokKategorije.equals("rang")){
                toast("Gotovo azuriranje!", Toast.LENGTH_SHORT);
                dao.ucitajUBazu(helper);
                new AsyncPostPatch(getInputStrm(), "PATCH",this).execute(dao.getRangPodaciLokalna().toArray(new IParselableBaza[dao.getRangPodaciLokalna().size()]));
        }
        else if (idDokKategorije.contains("Kviz change")) {
                String[] nazivi = idDokKategorije.split(",");
                if (rp != null) {
                    rp.setNaziv(nazivi[1]);
                    new AsyncPostPatch(getInputStrm(), "PATCH", this).execute(rp);
                 }
        }
    }

    private InputStream getInputStrm() {
        return getResources().openRawResource(R.raw.secret);
    }

    @Override
    public void onUploadDone(IParselableBaza object, String id) {

    }

    private QueryAsync.QueryExecutor getQueryExec() {
        return this;
    }

    @Override
    public void onQueryExecuted(String vrijednost) {
        rp = TaskExec.parseRang(vrijednost);
    }

    private void checkEvent() {
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.READ_CALENDAR) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.READ_CALENDAR}, CALENDER_REQUEST);
        }
        else if (!checkCalender()) proceedToQuiz(pozicija);

    }

    private boolean checkCalender() {
        Cursor cur = null;
        Calendar startTime = Calendar.getInstance();
        Calendar endTime= Calendar.getInstance();
        endTime.add(Calendar.DATE, doAlarma);
        ContentResolver cr = getContentResolver();

        String[] mProjection =
                {
                        "_id",
                        CalendarContract.Events.DTSTART,
                        CalendarContract.Events.DTEND,
                };

        Uri uri = CalendarContract.Events.CONTENT_URI;
        String selection = "(( " + CalendarContract.Events.DTSTART + " >= " + startTime.getTimeInMillis() + " ) AND ( " +
                CalendarContract.Events.DTSTART + " <= " + endTime.getTimeInMillis() + " ) AND ( deleted != 1 )" +
                "OR ("+CalendarContract.Events.DTSTART + " < " + startTime.getTimeInMillis() + " ) AND ( " +
                CalendarContract.Events.DTEND + " > " + startTime.getTimeInMillis() + " ))";

        cur = cr.query(uri, mProjection, selection, null, null);

        if (cur.moveToNext()) {

            Date pocetak = new Date(cur.getLong(cur.getColumnIndex(CalendarContract.Events.DTSTART)));
            long diff =  pocetak.getTime() - startTime.getTimeInMillis();
            int minutes = (int) (diff / (1000 * 60));
            String text="";
            if(minutes>0){
                text="Imate dogadjaj za "+ minutes+ " minuta.";
            }
            else text="Imate događaj u toku.";
            alertDialog(text);
            return true;
        }
        return false;
    }

    @Override
    public void onRequestPermissionsResult(int requestCode,
                                           String[] permissions, int[] grantResults) {
        switch (requestCode) {
            case CALENDER_REQUEST: {
                if (grantResults.length > 0
                        && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    if(!checkCalender()) proceedToQuiz(pozicija);
                    } else return;
                return;
            }
        }
    }

    @Override
    public void enable() {
        if(!siril) {

            dao.getKategorijeBaza(getInputStrm());
            dao.getKvizoviBaza(getInputStrm(), Kategorija.kategorijaSvi());
            dao.getPitanjaBaza(getInputStrm());
            dao.getRangPodaciFire(getInputStrm());
            dao.setKvizovi(dao.promjenaKat((Kategorija) spinner.getSelectedItem()));
            adapter.setData(dao.getKvizovi());
            adapter.notifyDataSetChanged();
            toast("Uređaj spojen na internet, ažuriranje u toku, molimo sačekajte obavijest o završetku", Toast.LENGTH_LONG);
        }
    }

    @Override
    public void disable() {
        toast("Uređaj odspojen s interneta",Toast.LENGTH_SHORT);
        dao.predjiNaLokalno();
        if(!siril){
            adapter.setData(promjenaKat());
            adapter.notifyDataSetChanged();
            spAdapter.notifyDataSetChanged();
        }
    }

    private void toast(CharSequence text, int duration){
        Toast toast = Toast.makeText(getBaseContext(), text, duration);
        toast.show();
    }

    @Override
    protected void onResume() {
        super.onResume();
        dao.setPozivatelj(this);

        if(InternetStateReceiver.ismConnected()) enable();
        registerReceiver(receiver,filter);
    }

    @Override
    protected void onPause() {
        super.onPause();
        unregisterReceiver(receiver);
    }

    private void alertDialog(String text) {
        AlertDialog.Builder dialog = new AlertDialog.Builder(this);
        dialog.setMessage(text);
        dialog.setTitle("Upozorenje");
        dialog.setPositiveButton("OK",
                new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                    }
                });
        AlertDialog alertDialog = dialog.create();
        alertDialog.show();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (helper != null) {
            helper.getWritableDatabase().close();
            helper.close();
            helper=null;
        }
    }
}

