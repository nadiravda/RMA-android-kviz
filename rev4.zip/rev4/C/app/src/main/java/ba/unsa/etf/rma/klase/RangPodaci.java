package ba.unsa.etf.rma.klase;


import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Objects;

import ba.unsa.etf.rma.taskovi.IParselableBaza;

public class RangPodaci implements IParselableBaza, Serializable {
    private String  id="", nazivKviza;
    private ArrayList<RangIgrac> igraci=new ArrayList<>();

    public RangPodaci() {
    }

    class Sortbyroll implements Comparator<RangIgrac>
    {
        public int compare(RangIgrac a, RangIgrac b)
        {
            int i=0;
            if(a.getProcenatTacnih() - b.getProcenatTacnih()>0)  i=-1;
            else if(b.getProcenatTacnih() - a.getProcenatTacnih()>0) i=1;
            return i;

        }
    }

    public RangPodaci(String nazivKviza, ArrayList<RangIgrac> igraci) {
        this.nazivKviza = nazivKviza;
        this.igraci = igraci;
        Collections.sort(this.igraci, new Sortbyroll());
    }

    public ArrayList<RangIgrac> getIgraci() {
        return igraci;
    }

    public void setIgraci(ArrayList<RangIgrac> igraci) {
        this.igraci = igraci;
        Collections.sort(this.igraci, new Sortbyroll());
        for(int i=0;i<igraci.size();i++){
            igraci.get(i).setPozicija(i+1);
        }

    }


    public void addIgrac(RangIgrac igr){
       if(igraci==null) igraci=new ArrayList<>();
       igraci.add(igr);
       Collections.sort(this.igraci, new Sortbyroll());
        for(int i=0;i<igraci.size();i++){
            igraci.get(i).setPozicija(i+1);
        }

    }

    public String getIdBaza() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }


    public String getNaziv() {
        return nazivKviza;
    }

    public void setNaziv(String nazivKviza) {
        this.nazivKviza = nazivKviza;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        RangPodaci that = (RangPodaci) o;
        return Objects.equals(nazivKviza, that.nazivKviza);

    }

    @Override
    public int hashCode() {
        return Objects.hash(id, nazivKviza, igraci);
    }
}
