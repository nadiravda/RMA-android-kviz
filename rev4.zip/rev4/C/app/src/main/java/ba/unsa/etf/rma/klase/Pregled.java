package ba.unsa.etf.rma.klase;

public interface Pregled {
    public String getNaziv();
}
