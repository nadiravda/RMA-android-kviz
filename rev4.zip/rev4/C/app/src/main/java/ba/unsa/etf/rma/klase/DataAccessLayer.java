package ba.unsa.etf.rma.klase;


import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashSet;

import ba.unsa.etf.rma.aktivnosti.KvizoviAkt;
import ba.unsa.etf.rma.baza.BazaHelper;
import ba.unsa.etf.rma.baza.QueryExec;
import ba.unsa.etf.rma.taskovi.AsyncPostPatch;
import ba.unsa.etf.rma.taskovi.IParselableBaza;
import ba.unsa.etf.rma.taskovi.KategorijaGet;
import ba.unsa.etf.rma.taskovi.KvizAsyncGet;
import ba.unsa.etf.rma.taskovi.PitanjaAsyncGet;
import ba.unsa.etf.rma.taskovi.RangListaAsyncGet;
import ba.unsa.etf.rma.utility.InternetStateReceiver;

public class DataAccessLayer implements AsyncPostPatch.OnUploaded ,KategorijaGet.OnKategorijaLoaded, KvizAsyncGet.OnKvizoviLoaded, PitanjaAsyncGet.OnPitanjeLoadDone, RangListaAsyncGet.OnRangLoaded {

    private static final DataAccessLayer ourInstance = new DataAccessLayer();
    private ArrayList<Kviz> kvizovi=new ArrayList<>();
    private ArrayList<Kviz> kvizovaLokalni=new ArrayList<>();
    private ArrayList<RangPodaci> rangPodaciFire=new ArrayList<>(), rangPodaciLokalno=new ArrayList<>();
    private ArrayList<Kviz> sviKvizovi=new ArrayList<>();
    private ArrayList<Kategorija> kategorije=new ArrayList<>(),kategorijeLokalne=new ArrayList<>();
    private ArrayList<Pitanje> pitanja=new ArrayList<>(),pitanjaLokalna = new ArrayList<>();
    private DataLoader pozivatelj;


    public void setSviKvizovi(ArrayList<Kviz> sviKvizovi) {
        this.sviKvizovi.clear();
        this.sviKvizovi.addAll(sviKvizovi);
    }


    public ArrayList<Kviz> getSviKvizovi() {
        return sviKvizovi;
    }

    @Override
    public void onDoneKviz(ArrayList<Kviz> kvizovi) {
        this.kvizovi=kvizovi;

         pozivatelj.onDataLoaded("kviz");
    }


    @Override
    public void onUploadDone(IParselableBaza object, String id) {

        if(object instanceof Kviz) {
            pozivatelj.onDataLoaded("kvizUpload");
        }
    }

    @Override
    public void onPitanjaLoaded(ArrayList<Pitanje> pitanja) {
        this.pitanja=pitanja;
        pozivatelj.onDataLoaded("pitanja");


    }
    public ArrayList<RangPodaci> getRangPodaciFire(InputStream stream) {
        new RangListaAsyncGet(stream,this).execute("Svi");
        return rangPodaciFire;
    }

    public ArrayList<RangPodaci> getRangPodaciLokalna() {
        return rangPodaciLokalno;
    }

    @Override
    public void onRangLoadFinished(ArrayList<RangPodaci> rangPodaci) {

        rangPodaciFire.clear();
        rangPodaciFire.addAll(rangPodaci);
        throwRang();
        sync();
        if(pozivatelj!=null) {
            pozivatelj.onDataLoaded("rang");
        }
    }

    private void sync() {

        if(rangPodaciFire.size()==0){
            rangPodaciFire.clear();
            rangPodaciFire.addAll(rangPodaciLokalno);
        }
        else {
            for (RangPodaci rp : rangPodaciFire) {
                if (!rangPodaciLokalno.contains(rp)) {
                    rangPodaciLokalno.add(rp);
                } else {
                    //izjednacavanje igraca postojecih
                    for (RangPodaci rpLok : rangPodaciLokalno) {
                        if (rp.getIdBaza().equals(rpLok.getIdBaza())) {
                            ArrayList<RangIgrac> igracs = new ArrayList<>(), fireIgr = new ArrayList<>();
                            igracs.addAll(rpLok.getIgraci());
                            fireIgr.addAll(rp.getIgraci());
                            for (RangIgrac ri : fireIgr) {
                                if (!igracs.contains(ri)) {
                            if(!(igracs.size()==fireIgr.size() && ri.getIme().equals("Guest"))) igracs.add(ri);
                                }
                            }
                            HashSet<RangIgrac> set=new HashSet<>();
                            set.addAll(igracs);
                            igracs.clear();
                            igracs.addAll(set);
                            rpLok.setIgraci(igracs);
                        }
                    }
                }
            }
            rangPodaciFire.clear();
            rangPodaciFire.addAll(rangPodaciLokalno);
        }
    }


    public interface DataLoader{
        void onDataLoaded(String type);
    }

    public void setPozivatelj(DataLoader pozivatelj) {
        this.pozivatelj = pozivatelj;
    }

    public static DataAccessLayer getInstance() {
        return ourInstance;
    }

    private DataAccessLayer() {

    }

    public ArrayList<Kviz> getKvizovi() {
        return  kvizovi;

    }
    public ArrayList<Kviz> getKvizoviBaza(InputStream is, Kategorija kategorija) {

        if(InternetStateReceiver.ismConnected()) new KvizAsyncGet(is,this).execute(kategorija);
        else {
            kvizovi.clear();
            kvizovi.addAll(promjenaKat(kategorija));
        }
        return kvizovi;
    }

    public void addPitanje(InputStream stream, Pitanje pitanje){
        pitanja.add(pitanje);
        pitanjaLokalna.add(pitanje);
        QueryExec.pisiUBazuPitanje(pitanje, KvizoviAkt.getHelper());
        new AsyncPostPatch(stream,"POST",this).execute(pitanje);
    }

    public void setKvizovi(ArrayList<Kviz> kvizovi) {
        this.kvizovi = kvizovi;
    }

    public ArrayList<Kategorija> getKategorije() {

        if(InternetStateReceiver.ismConnected() || kategorijeLokalne==null)return kategorije;
        return kategorijeLokalne;
    }

    public ArrayList<Kategorija> getKategorijeBaza(InputStream stream) {

       if(InternetStateReceiver.ismConnected()) new KategorijaGet(stream, this).execute("sve");
       else {
           kategorije.clear();
           kategorije.addAll(kategorijeLokalne);
       }

       return kategorije;
    }

    public ArrayList<Pitanje> getPitanjaBaza(InputStream stream) {

        if(InternetStateReceiver.ismConnected()) new PitanjaAsyncGet(stream, this,true).execute(new ArrayList<String>());
        else {
            pitanja.clear();
            pitanja.addAll(pitanjaLokalna);
        }

        return pitanja;
    }


    public void setKategorije(ArrayList<Kategorija> kategorije) {
        this.kategorije = kategorije;
    }

    public void addKviz(Kviz kviz){
       kvizovi.add(kviz);
    }

    public void addKviz(InputStream stream, Kviz kviz){

        kvizovi.add(kviz);
        sviKvizovi.add(kviz);
        new AsyncPostPatch(stream,"POST",this).execute(kviz);

    }


    public void addKategorija(Kategorija kategorija){

       if(!kategorije.contains(kategorija)) kategorije.add(kategorija);
    }

    public void addKategorijaBaza(Kategorija kategorija, InputStream stream){

        new AsyncPostPatch(stream,"POST",this).execute(kategorija);
        kategorijeLokalne.add(kategorija);
        QueryExec.pisiUBazuKategoriju(kategorija, KvizoviAkt.getHelper());
    }

    public void changeKviz(Kviz prvi, Kviz kviz, InputStream stream){

        int index=-1;
        for(int i=0;i<sviKvizovi.size();i++){
            if(sviKvizovi.get(i).equals(prvi)) index=i;
        }
        if(index>=0) {
            sviKvizovi.remove(index);
            sviKvizovi.add(index, kviz);
        }
        index=-1;
        for(int i=0;i<rangPodaciLokalno.size();i++){
            if(rangPodaciLokalno.get(i).getNaziv().equals(prvi.getNaziv())) index=i;
        }

        if(index>=0) {
            rangPodaciLokalno.get(index).setNaziv(kviz.getNaziv());
        }
        pozivatelj.onDataLoaded("Kviz change,"+kviz.getNaziv());
        new AsyncPostPatch(stream,"PATCH",this).execute(kviz);

    }

    public void removeKviz(Kviz kviz){
        kvizovi.remove(kviz);
    }
    public boolean nalaziSeKviz(String ime) {

        for (Kviz a : sviKvizovi) {
            if (a.getNaziv().equals(ime)) return true;
        }
        return false;
    }
    public boolean nalaziSeKategorija(String ime) {

        for (Kategorija a : kategorije) {
            if (a.getNaziv().equals(ime)) return true;
        }
        return false;
    }

    public Kategorija dajKategoriju(String id) {

        if(!InternetStateReceiver.ismConnected()){
            kategorije.clear();
            kategorije.addAll(kategorijeLokalne);
        }
        for (Kategorija a : kategorije) {
            if (a.getIdBaza().equals(id)) return a;
        }
        return null;
    }

    public ArrayList<Pitanje> getPitanja() {
        return pitanja;
    }

    public void setPitanja(ArrayList<Pitanje> pitanja) {
        this.pitanja = pitanja;
    }

    @Override
    public void onDone(ArrayList<Kategorija> kategorijas) {

        kategorije=kategorijas;
        pozivatelj.onDataLoaded("kategorije");

    }

    public Pitanje dajPitanjeizId(String id){

        if(!InternetStateReceiver.ismConnected()){
            pitanja.clear();
           pitanja.addAll(pitanjaLokalna);
        }

        for (Pitanje a : pitanja) {
            if (a.getIdBaza().equals(id)) return a;
        }
        return null;

    }
    public void ucitajUBazu(BazaHelper helper){


        QueryExec.pisiUBazuPitanja(helper);
        QueryExec.pisiUBazuOdgovore(helper);
        QueryExec.pisiUBazuKvizove(helper);
        QueryExec.pisiUBazuKategorije(helper);
        QueryExec.pisiUBazuRangListe(helper);
        azurirano();


    }

   public ArrayList<Kviz> promjenaKat(Kategorija k) {
       ArrayList<Kviz> filter = new ArrayList<>();
        if(k.equals(Kategorija.kategorijaSvi())){
            filter.addAll(sviKvizovi);
          filter.add(Kviz.dodajNovi());
            return filter;
        }
        removeKviz(Kviz.dodajNovi());
        for (Kviz a : sviKvizovi) {
            if (a.getKategorija().equals(k)) filter.add(a);
        }
        filter.add(Kviz.dodajNovi());
        return filter;
    }

    public void ucitajIzBaze(BazaHelper helper){
        kategorijeLokalne=QueryExec.getKategorija(helper);
        pitanjaLokalna=QueryExec.getPitanja(helper);
        kvizovaLokalni=QueryExec.getKvizovi(helper);
        if(!InternetStateReceiver.ismConnected()) predjiNaLokalno();
        rangPodaciLokalno=QueryExec.getRangPodaci(helper);
        if(kategorijeLokalne==null) kategorijeLokalne=new ArrayList<>();
        if(pitanjaLokalna==null) pitanjaLokalna=new ArrayList<>();
        if(kvizovaLokalni==null) kvizovaLokalni=new ArrayList<>();
        if(rangPodaciLokalno==null) rangPodaciLokalno=new ArrayList<>();

    }

    public ArrayList<Kviz> getKvizoviZaUpis(){
        ArrayList<Kviz> filter = new ArrayList<>();
        filter.addAll(sviKvizovi);
        if(kvizovaLokalni.size()>0) filter.removeAll(kvizovaLokalni);
        filter.remove(Kviz.dodajNovi());

        return filter;

    }

    public ArrayList<Kategorija> getKategorijaZaUpis(){
        ArrayList<Kategorija> filter = new ArrayList<>();
        filter.addAll(kategorije);
        if(kategorijeLokalne.size()>0) filter.removeAll(kategorijeLokalne);
        filter.remove(Kategorija.kategorijaDodaj());

        return filter;

    }

    public ArrayList<Pitanje> getPitanjaZaUpis(){
        ArrayList<Pitanje> filter = new ArrayList<>();
        filter.addAll(pitanja);
        if(pitanjaLokalna.size()>0) filter.removeAll(pitanjaLokalna);

        filter.remove(Pitanje.pitanjeDodaj());
        return filter;

    }
    public  void predjiNaLokalno(){

        pitanja.clear();
        pitanja.addAll(pitanjaLokalna);
        kategorije.clear();
        kategorije.addAll(kategorijeLokalne);
        kvizovi.clear();
        kvizovi.addAll(kvizovaLokalni);
        sviKvizovi.clear();
        sviKvizovi.addAll(kvizovaLokalni);


    }

    public void azurirano(){
        if(pitanja.size()>0 && sviKvizovi.size()>0 && kategorije.size()>0) {
            pitanjaLokalna.clear();
            matchQuizes();
            pitanjaLokalna.addAll(pitanja);
            kategorijeLokalne.clear();
            kategorijeLokalne.addAll(kategorije);
            kvizovaLokalni.clear();
            kvizovaLokalni.addAll(sviKvizovi);
        }
    }

    private void matchQuizes() {

        for(Kviz kviz: sviKvizovi){
            ArrayList<Pitanje> pitanja=new ArrayList<>();
            for(Pitanje pitanje: kviz.getPitanja()){
                pitanja.add(dajPitanjeizId(pitanje.getIdBaza()));
            }
            kviz.setPitanja(pitanja);
        }

    }

    public String dajIdIzNazivaKviza(String naziv) {

        for (Kviz kviz : sviKvizovi) {
            if (kviz.getNaziv().equals(naziv)) return kviz.getIdBaza();
        }
        return "nema";
    }

    public String dajNazivIzIdKviza(String id) {

        for (Kviz kviz : sviKvizovi) {
            if (kviz.getIdBaza().equals(id)) return kviz.getNaziv();
        }
        return "nema";
    }

    public RangPodaci dajRangListu(String naziv) {
        for (RangPodaci rp: rangPodaciLokalno) {
            if (rp.getNaziv().equals(naziv)) return rp;
        }
        return null;
    }

    public void dodajRangLokalno(RangPodaci rp){
        RangPodaci rl=dajRangListu(rp.getNaziv());
        if(rl==null) rangPodaciLokalno.add(rp);
        else {
            rangPodaciLokalno.remove(rl);
            rangPodaciLokalno.add(rp);
        }
    }

    public boolean throwRang() {

        for (int i = 0; i < rangPodaciFire.size();i++){
            if(!checkIfCorrect(rangPodaciFire.get(i))) rangPodaciFire.remove(rangPodaciFire.get(i));
        }
        return false;
    }

    public boolean checkIfCorrect(RangPodaci rp) {
        if (rp == null || rp.getIgraci() == null)  return false;

            for (int i = 0; i < rp.getIgraci().size();i++){
                if(!rp.getIgraci().get(i).getIme().equals("Guest") ||  rp.getIgraci().get(i).getProcenatTacnih()!=0.0) return true;
            }
         return false;
    }
}
