package ba.unsa.etf.rma.taskovi;

import android.os.AsyncTask;

import com.google.api.client.googleapis.auth.oauth2.GoogleCredential;
import com.google.common.collect.Lists;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;

import ba.unsa.etf.rma.klase.RangPodaci;
import ba.unsa.etf.rma.utility.InputStreamReader;

public class RangListaAsyncGet extends AsyncTask<String, Integer, ArrayList<RangPodaci>> {


    InputStream stream;
    private GoogleCredential credentials;
    OnRangLoaded pozivatelj;

    public RangListaAsyncGet(InputStream con, OnRangLoaded pozivatelj) {

        this.stream = con;
        this.pozivatelj = pozivatelj;
    }

    public interface OnRangLoaded {
        void onRangLoadFinished(ArrayList<RangPodaci> rangPodaci);
    }


    @Override
    protected ArrayList<RangPodaci> doInBackground(String... strings) {
        ArrayList<RangPodaci> rangPodaci = new ArrayList<>();
        try {
            credentials = GoogleCredential.fromStream(stream).createScoped(Lists.<String>newArrayList("https://www.googleapis.com/auth/datastore"));
            credentials.refreshToken();
            String TOKEN = credentials.getAccessToken();
            String url = "https://firestore.googleapis.com/v1/projects/spirala-a85a9/databases/(default)/documents/Rangliste?access_token=";
            URL urlObj = new URL(url + URLEncoder.encode(TOKEN, "UTF-8"));
            HttpURLConnection conn2 = (HttpURLConnection) urlObj.openConnection();
            conn2.setRequestMethod("GET");
            conn2.setRequestProperty("Content-Type", "application/json");
            conn2.setRequestProperty("Accept", "application/json");
            InputStream ins = new BufferedInputStream(conn2.getInputStream());
            String rezultat = InputStreamReader.convertStreamToString(ins);
            rangPodaci = parseRangListe(rezultat);
        } catch (IOException | JSONException e) {
            e.printStackTrace();

        }

        return rangPodaci;
    }

    private ArrayList<RangPodaci> parseRangListe(String rezultat) throws JSONException {

        String projectName = "projects/spirala-a85a9/databases/(default)/documents/Rangliste/";
        JSONObject jsonObject = new JSONObject(rezultat);
        JSONArray dokumenti = jsonObject.getJSONArray("documents");
        ArrayList<RangPodaci> rangPodaci = new ArrayList<>();
        for (int i = 0; i < dokumenti.length(); i++) {
            RangPodaci rp = new RangPodaci();
            JSONObject rangBaza = dokumenti.getJSONObject(i);
            rp = TaskExec.parseRangItem(rangBaza);
            rangPodaci.add(rp);


        }

        return rangPodaci;
    }

    @Override
    protected void onPostExecute(ArrayList<RangPodaci> rangPodaci) {
        super.onPostExecute(rangPodaci);
        pozivatelj.onRangLoadFinished(rangPodaci);
    }
}
