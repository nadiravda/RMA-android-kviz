package ba.unsa.etf.rma.klase;

import android.content.Context;
import android.os.AsyncTask;

import com.google.api.client.googleapis.auth.oauth2.GoogleCredential;
import com.google.common.collect.Lists;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.io.StringWriter;
import java.io.Writer;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;

import ba.unsa.etf.rma.R;

public class DohvatiPitanja extends AsyncTask<Void,Integer,Void> {

    private Context context;
    private ArrayList<Pitanje> pitanjaKviza;
    private ArrayList<String> idPitanjaKviza;
    private OnDohvatiPitanja pozivatelj;

    public interface OnDohvatiPitanja {
        void onDoneDohvatiPitanja(ArrayList<Pitanje> pitanja);
    }

    public DohvatiPitanja(Context context, ArrayList<Pitanje> pitanjaKviza, ArrayList<String> idPitanjaKviza, OnDohvatiPitanja pozivatelj) {
        this.context = context;
        this.idPitanjaKviza = idPitanjaKviza;
        this.pozivatelj = pozivatelj;
        this.pitanjaKviza = pitanjaKviza;
    }

    @Override
    protected Void doInBackground(Void... voids) {

        String TOKEN = "";
        try {
            InputStream is = context.getResources().openRawResource(R.raw.secret);
            GoogleCredential credentials = GoogleCredential.fromStream(is).
                    createScoped(Lists.newArrayList("https://www.googleapis.com/auth/datastore"));
            credentials.refreshToken();
            TOKEN = credentials.getAccessToken();
        } catch (IOException e) {
            e.printStackTrace();
        }

        for (String id :
                idPitanjaKviza) {
            parsePitanje(id, TOKEN);
        }

        return null;
    }

    void parsePitanje(String pitanjeID,String TOKEN) {
        try {

            String url1 = "https://firestore.googleapis.com/v1/projects/rma19spirala3/databases/(default)/documents/Pitanja?fields=documents(fields%2Cname)&access_token=" + TOKEN;
            URL url = new URL(url1);
            HttpURLConnection urlConnection = (HttpURLConnection) url.openConnection();
            int code = urlConnection.getResponseCode();

            // ovdje radimo sa kvizovima kategorije
            InputStream odgovor = urlConnection.getInputStream();
            String rezultat = convertStreamToString(odgovor);
            JSONObject jo = new JSONObject(rezultat);
            JSONArray dokumenti = jo.getJSONArray("documents");
            for(int i = 0; i < dokumenti.length(); i++) {
                JSONObject dokument = dokumenti.getJSONObject(i);
                String idPitanja = dokument.getString("name");
                if(idPitanjaKviza.contains(takeIDFromName(idPitanja))) {
                    JSONObject fields = dokument.getJSONObject("fields");
                    JSONObject naziv = fields.getJSONObject("naziv");
                    String nazivKviza = naziv.getString("stringValue");
                    JSONObject indexTacnog = fields.getJSONObject("indexTacnog");
                    int indexTacnogKviza = indexTacnog.getInt("integerValue");
                    JSONObject odgovori = fields.getJSONObject("odgovori");
                    odgovori = odgovori.getJSONObject("arrayValue");
                    JSONArray values = odgovori.getJSONArray("values");
                    ArrayList<String> odgovoriKviza = new ArrayList<>();
                    for(int j = 0; j < values.length(); j++) {
                        JSONObject odg = values.getJSONObject(j);
                        String odgovorKviza = odg.getString("stringValue");
                        odgovoriKviza.add(odgovorKviza);
                    }
                    Pitanje pitanjeKviza = new Pitanje(nazivKviza, nazivKviza, odgovoriKviza, odgovoriKviza.get(indexTacnogKviza));
                    pitanjaKviza.add(pitanjeKviza);
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    private String takeIDFromName(String name) {
        return name.substring(name.lastIndexOf('/') + 1);
    }

    private String convertStreamToString(InputStream stream) throws IOException {
        // To convert the InputStream to String we use the
        // Reader.read(char[] buffer) method. We iterate until the
        // Reader return -1 which means there's no more data to
        // read. We use the StringWriter class to produce the string.
        if (stream != null) {
            Writer writer = new StringWriter();

            char[] buffer = new char[1024];
            try {
                Reader reader = new BufferedReader(new InputStreamReader(stream, "UTF-8"));
                int n;
                while ((n = reader.read(buffer)) != -1) {
                    writer.write(buffer, 0, n);
                }
            } finally {
                stream.close();
            }
            return writer.toString();
        }
        return "";
    }

    @Override
    protected void onPostExecute(Void aVoid) {
        super.onPostExecute(aVoid);
        pozivatelj.onDoneDohvatiPitanja(pitanjaKviza);
    }
}
