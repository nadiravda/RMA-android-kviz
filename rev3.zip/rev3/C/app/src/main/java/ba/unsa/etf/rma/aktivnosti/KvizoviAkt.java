package ba.unsa.etf.rma.aktivnosti;

import android.app.Activity;
import android.content.Intent;
import android.os.AsyncTask;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.Toast;

import java.util.ArrayList;

import ba.unsa.etf.rma.R;
import ba.unsa.etf.rma.klase.DohvatiKvizove;
import ba.unsa.etf.rma.klase.DohvatiPitanja;
import ba.unsa.etf.rma.klase.Kategorija;
import ba.unsa.etf.rma.klase.Kviz;
import ba.unsa.etf.rma.klase.ListViewAdapterKviz;
import ba.unsa.etf.rma.klase.Pitanje;
import ba.unsa.etf.rma.klase.PostaviKategorije;

public class KvizoviAkt extends AppCompatActivity implements PostaviKategorije.OnPostaviKategorijeDone, DohvatiKvizove.OnDohvatiKvizove, DohvatiPitanja.OnDohvatiPitanja {

    private Spinner izborKategorije;
    private ArrayAdapter<Kategorija> spinnerAdapter;
    private ArrayList<Kategorija> kategorije = new ArrayList<>();

    private ListView izborKvizova;
    private ListViewAdapterKviz listViewAdapterKviz;
    private ArrayList<Kviz> kvizovi = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        izborKvizova = findViewById(R.id.lvKvizovi);
        izborKategorije = findViewById(R.id.spPostojeceKategorije);

        new PostaviKategorije(KvizoviAkt.this, (PostaviKategorije.OnPostaviKategorijeDone)KvizoviAkt.this).execute();

        onSpinnerItemSelected();
        onListViewItemSelected();

    }

    private void onListViewItemSelected() {
        izborKvizova.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Intent intent = new Intent(KvizoviAkt.this, DodajKvizAkt.class);
                intent.putExtra("kviz", kvizovi.get(position));
                intent.putExtra("position", position);
                intent.putExtra("kategorije", kategorije);
                startActivityForResult(intent, 1);
            }
        });
    }

    private void addAddNewQuizButton() {
        kvizovi.add(new Kviz("Dodaj kviz", new ArrayList<Pitanje>(), kategorije.get(0)));
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(requestCode == 1) {
            if(resultCode == Activity.RESULT_OK) {
                Kviz kvizInfo = (Kviz)data.getSerializableExtra("kviz");
                if(kvizInfo.getKvizID() != "") {
                    //update
                } else {
                    //
                }
                new PostaviKategorije(KvizoviAkt.this, (PostaviKategorije.OnPostaviKategorijeDone)KvizoviAkt.this).execute();
            }

            /*if(resultCode == Activity.RESULT_OK) {
                boolean dodajNoviButton = false;
                if(data.getIntExtra("position", 0) == kvizovi.size() - 1) {
                    dodajNoviButton = true;
                }

                //rekreiranje kategorija dodali smo novododane kategorije
                //ArrayList<Kategorija> noveKategorije = (ArrayList<Kategorija>)data.getSerializableExtra("kategorije");
                //kategorije.addAll(noveKategorije);

                //rekreiranje kviza bitno
                Kviz noviKviz = (Kviz)data.getSerializableExtra("kviz");
                Kategorija kvizKategorija = noviKviz.getKategorija();
                for (Kategorija x :
                        kategorije) {
                    if (kvizKategorija.getNaziv().equals(x.getNaziv())) {
                        noviKviz.setKategorija(x);
                        break;
                    }
                }
                //dodavanje kviza
                kvizovi.set(data.getIntExtra("position", 0), noviKviz);
                if(dodajNoviButton)
                    addAddNewQuizButton();

                //postavljanje selekcije i filter kvizova
                izborKategorije.setSelection(kategorije.indexOf(kvizovi.get(data.getIntExtra("position", 0)).getKategorija()));
                filtrirajKvizove();
            }
            else if(resultCode == Activity.RESULT_CANCELED) {
                //izborKategorije.setSelection(0);
            }*/
        }
    }

    private void filtrirajKvizove() {
        new DohvatiKvizove(KvizoviAkt.this, (DohvatiKvizove.OnDohvatiKvizove)KvizoviAkt.this, kategorije, izborKategorije.getSelectedItemPosition()).execute();
    }

    private void onSpinnerItemSelected() {
        izborKategorije.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                filtrirajKvizove();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
            }
        });
    }

    private void connectListView(ArrayList<Kviz> kvizovi) {
        listViewAdapterKviz = new ListViewAdapterKviz(this, R.layout.list_view_item_display, kvizovi);
        izborKvizova.setAdapter(listViewAdapterKviz);
    }

    private void connectSpinner(ArrayList<Kategorija> kategorije) {
        spinnerAdapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, kategorije);
        izborKategorije.setAdapter(spinnerAdapter);
    }

    @Override
    public void onDone(ArrayList<Kategorija> kategorije) {
        this.kategorije = kategorije;
        kategorije.add(0, new Kategorija("Svi", "671"));
        connectSpinner(kategorije);
        connectListView(kvizovi);
        izborKategorije.setSelection(0);
    }

    @Override
    public void onDoneDohvatiKvizove(ArrayList<Kviz> kvizovi) {
        this.kvizovi = kvizovi;
        for (Kviz k :
                kvizovi) {
            new DohvatiPitanja(KvizoviAkt.this, k.getPitanja() ,k.getIdPitanja(), (DohvatiPitanja.OnDohvatiPitanja) KvizoviAkt.this).execute();
        }
        connectListView(kvizovi);
        addAddNewQuizButton();
    }

    @Override
    public void onDoneDohvatiPitanja(ArrayList<Pitanje> pitanja) {
    }
}
