package ba.unsa.etf.rma.klase;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.maltaisn.icondialog.IconHelper;

import java.util.List;

import ba.unsa.etf.rma.R;

public class ListViewAdapterKviz extends ArrayAdapter<Kviz> {

    private int resource;
    private Context context;

    public ListViewAdapterKviz(Context context, int resource, List<Kviz> objects) {
        super(context, resource, objects);
        this.resource = resource;
        this.context = context;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        LayoutInflater inflater = LayoutInflater.from(getContext());
        View view = inflater.inflate(resource, parent, false);

        final Kviz kviz = getItem(position);

        TextView imeKviza = view.findViewById(R.id.listItemName);
        final ImageView slikaKviza = view.findViewById(R.id.listItemIcon);

        imeKviza.setText(kviz.getNaziv());

        //iplementirati custom sliku.. trenutno sve iste
        final IconHelper iconHelper = IconHelper.getInstance(context);
        iconHelper.addLoadCallback(new IconHelper.LoadCallback() {
            @Override
            public void onDataLoaded() {
                slikaKviza.setImageDrawable(iconHelper.getIcon(Integer.parseInt(kviz.getKategorija().getId())).getDrawable(context));
            }
        });

        return view;
    }
}
