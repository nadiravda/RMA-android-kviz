package ba.unsa.etf.rma.klase;

import java.io.Serializable;
import java.util.ArrayList;

public class Kviz implements Serializable {
    private String naziv;
    private ArrayList<Pitanje> pitanja;
    private Kategorija kategorija;
    private ArrayList<String> idPitanja;
    private String kvizID = "";

    public Kviz(String naziv, ArrayList<Pitanje> pitanja, Kategorija kategorija) {
        this.naziv = naziv;
        this.pitanja = pitanja;
        this.kategorija = kategorija;
        this.idPitanja = new ArrayList<>();
    }

    public String getNaziv() {
        return naziv;
    }

    public void setNaziv(String naziv) {
        this.naziv = naziv;
    }

    public ArrayList<Pitanje> getPitanja() {
        return pitanja;
    }

    public void setPitanja(ArrayList<Pitanje> pitanja) {
        this.pitanja = pitanja;
    }

    public Kategorija getKategorija() {
        return kategorija;
    }

    public void setKategorija(Kategorija kategorija) {
        this.kategorija = kategorija;
    }

    public void dodajPitanje(Pitanje pitanje) {
        pitanja.add(pitanje);
    }

    public ArrayList<String> getIdPitanja() {
        return idPitanja;
    }

    public void setIdPitanja(ArrayList<String> idPitanja) {
        this.idPitanja = idPitanja;
    }

    public String getKvizID() {
        return kvizID;
    }

    public void setKvizID(String kvizID) {
        this.kvizID = kvizID;
    }
}
