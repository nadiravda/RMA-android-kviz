package ba.unsa.etf.rma.klase;

import android.content.Context;
import android.os.AsyncTask;
import android.util.Log;

import com.google.api.client.googleapis.auth.oauth2.GoogleCredential;
import com.google.common.collect.Lists;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;

import ba.unsa.etf.rma.R;

public class PosaljiPitanje extends AsyncTask<Void, Integer, Void> {

    private Context context;
    private Pitanje pitanje;

    public PosaljiPitanje(Context context, Pitanje pitanje) {
        this.context = context;
        this.pitanje = pitanje;
    }

    @Override
    protected Void doInBackground(Void... voids) {

        String TOKEN = "";

        try {
            InputStream is = context.getResources().openRawResource(R.raw.secret);
            GoogleCredential credentials = GoogleCredential.fromStream(is).
                    createScoped(Lists.newArrayList("https://www.googleapis.com/auth/datastore"));
            credentials.refreshToken();
            TOKEN = credentials.getAccessToken();
        } catch (IOException e) {
            e.printStackTrace();
        }

        try {
            String url1 = "https://firestore.googleapis.com/v1/projects/rma19spirala3/databases/(default)/documents/Pitanja?access_token=" + TOKEN;
            URL url = new URL(url1);
            HttpURLConnection urlConnection = (HttpURLConnection) url.openConnection();
            urlConnection.setDoOutput(true);
            urlConnection.setRequestMethod("POST");
            urlConnection.setRequestProperty("Content-Type","application/json; utf-8");
            urlConnection.setRequestProperty("Accept","application/json");

            Log.d("ODGOVOR", url1);

            String items = "";
            for (String s :
                    pitanje.getOdgovori()) {
                if(s.equals(pitanje.getOdgovori().get(pitanje.getOdgovori().size()-1)))
                    items += "               {\n" + "               \"stringValue\": \"" + s + "\"\n               }\n";
                else
                    items += "               {\n" + "               \"stringValue\": \"" + s + "\"\n               },\n";
            }

            String dokument = "{ \"fields\": {\n" +
                    "            \"indexTacnog\": {\n" +
                    "            \"integerValue\": \"" + dajIndexTacnog() +"\"\n" +
                    "                 },\n" +
                    "            \"naziv\": {\n" +
                    "            \"stringValue\": \"" + pitanje.getNaziv() + "\"\n" +
                    "                 },\n" +
                    "            \"odgovori\": {\n" +
                    "               \"arrayValue\": {\n" +
                    "                  \"values\": [\n" +
                                       items +
                    "                  ]\n" +
                    "                }\n" +
                    "             }\n" +
                    "          }\n" +
                    "         }";

            Log.d("Odgovor", dokument);

            try(OutputStream os = urlConnection.getOutputStream()) {
                byte[] input = dokument.getBytes("utf-8");
                os.write(input, 0, input.length);
            }

            int code = urlConnection.getResponseCode();
            Log.d("ODGOVOR", String.valueOf(code));

            InputStream odgovor = urlConnection.getInputStream();
            try(BufferedReader br = new BufferedReader(new InputStreamReader(odgovor, "utf-8"))) {
                StringBuilder response = new StringBuilder();
                String responseLine = null;
                while((responseLine = br.readLine()) != null) {
                    response.append(responseLine.trim());
                }
                Log.d("ODGOVOR", response.toString());
            }

        } catch(IOException e) {
            e.printStackTrace();
        }

        return null;
    }

    public int dajIndexTacnog() {
        for(int i = 0; i < pitanje.getOdgovori().size(); i++) {
            if(pitanje.getTacan().equals(pitanje.getOdgovori().get(i)))
                return i;
        }
        return 0;
    }

    @Override
    protected void onPostExecute(Void aVoid) {
        super.onPostExecute(aVoid);
    }
}
