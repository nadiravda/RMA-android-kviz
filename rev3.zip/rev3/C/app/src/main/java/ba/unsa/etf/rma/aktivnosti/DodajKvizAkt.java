package ba.unsa.etf.rma.aktivnosti;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;

import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.Toast;

import java.util.ArrayList;

import ba.unsa.etf.rma.R;
import ba.unsa.etf.rma.klase.DodajKategorijuUDB;
import ba.unsa.etf.rma.klase.DohvatiPitanja;
import ba.unsa.etf.rma.klase.PitanjaDB;
import ba.unsa.etf.rma.klase.Kategorija;
import ba.unsa.etf.rma.klase.Kviz;
import ba.unsa.etf.rma.klase.Pitanje;
import ba.unsa.etf.rma.klase.PosaljiPitanje;

public class DodajKvizAkt extends AppCompatActivity  implements DodajKategorijuUDB.OnDohvatiKategorijuDone, PitanjaDB.OnDohvatiPitanjaDone {

    private Spinner izborKategorije;
    private ArrayAdapter<Kategorija> spinnerAdapter;
    private ArrayList<Kategorija> kategorije = new ArrayList<>();

    private ArrayList<Kategorija> noveKategorije = new ArrayList<>();

    private EditText nameField;

    private ListView listaPitanja;
    private ArrayAdapter<Pitanje> listViewAdapterPitanja;
    private ArrayList<Pitanje> pitanja = new ArrayList<>();

    private ListView listaMogucihPitanja;
    private ArrayAdapter<Pitanje> listViewAdapterMogucaPitanja;
    private ArrayList<Pitanje> mogucaPitanja = new ArrayList<>();

    private Button dodajKviz;

    private int position;
    private Kviz kviz;

    private int previosState = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dodaj_kviz_akt);

        Intent intent = getIntent();
        kviz = (Kviz)intent.getSerializableExtra("kviz");
        kategorije = (ArrayList<Kategorija>)intent.getSerializableExtra("kategorije");
        position = intent.getIntExtra("position", 0);

        pitanja = kviz.getPitanja();
        addAddNewQuestion();

        izborKategorije = findViewById(R.id.spKategorije);
        spinnerAdapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, kategorije);
        izborKategorije.setAdapter(spinnerAdapter);

        addAddNewCategoryButton();
        spinnerAdapter.notifyDataSetChanged();

        //postavljanje kategorije
        for (Kategorija x :
                kategorije) {
            if (x.getNaziv().equals(kviz.getKategorija().getNaziv())) {
                izborKategorije.setSelection(kategorije.indexOf(x));
                break;
            }
        }

        nameField = findViewById(R.id.etNaziv);
        nameField.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                nameField.setBackgroundColor(Color.WHITE);
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });
        setNameField();


        listaPitanja = findViewById(R.id.lvDodanaPitanja);
        listViewAdapterPitanja = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, pitanja);
        listaPitanja.setAdapter(listViewAdapterPitanja);

        listaMogucihPitanja = findViewById(R.id.lvMogucaPitanja);
        new PitanjaDB(DodajKvizAkt.this, pitanja, (PitanjaDB.OnDohvatiPitanjaDone)DodajKvizAkt.this).execute();
        //listViewAdapterMogucaPitanja = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, mogucaPitanja);
        //listaMogucihPitanja.setAdapter(listViewAdapterMogucaPitanja);

        dodajKviz = findViewById(R.id.btnDodajKviz);

        dodajKviz.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(nameField.getText().toString().equals("")) {
                    nameField.setBackgroundColor(getResources().getColor(R.color.redError));
                    Toast.makeText(DodajKvizAkt.this, "Enter Name", Toast.LENGTH_LONG).show();
                }
                else {
                    Intent resultIntent = new Intent();
                    kviz.setNaziv(nameField.getText().toString());
                    pitanja.remove(pitanja.get(pitanja.size() - 1));
                    kviz.setPitanja(pitanja);
                    kviz.setKategorija((Kategorija)izborKategorije.getSelectedItem());
                    resultIntent.putExtra("kviz", kviz);
                    resultIntent.putExtra("position", position);
                    resultIntent.putExtra("kategorije", noveKategorije);

                    setResult(Activity.RESULT_OK, resultIntent);
                    finish();
                }
            }
        });

        listaMogucihPitanja.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                pitanja.add(pitanja.size() - 1,mogucaPitanja.remove(position));
                listViewAdapterPitanja.notifyDataSetChanged();
                listViewAdapterMogucaPitanja.notifyDataSetChanged();
            }
        });

        listaPitanja.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                if(position == pitanja.size() - 1) {
                    Intent mIntent = new Intent(DodajKvizAkt.this, DodajPitanjeAkt.class);
                    startActivityForResult(mIntent, 3);
                }
                else {
                    mogucaPitanja.add(pitanja.remove(position));
                    listViewAdapterPitanja.notifyDataSetChanged();
                    listViewAdapterMogucaPitanja.notifyDataSetChanged();
                }
            }
        });

        izborKategorije.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                if(position != kategorije.size() - 1)
                    previosState = izborKategorije.getSelectedItemPosition();
                if(position == kategorije.size() - 1) {
                    Intent categoryIntent = new Intent(DodajKvizAkt.this, DodajKategorijuAkt.class);
                    startActivityForResult(categoryIntent, 2);
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        //rad sa podatkom iz DodajPitanjeAkt
        if(requestCode == 3) {
            if(resultCode == Activity.RESULT_OK) {
                Pitanje novoPitanje = (Pitanje)data.getSerializableExtra("novo pitanje");
                boolean postoji = false;
                for (Pitanje x :
                        mogucaPitanja) {
                    if (x.getNaziv().equals(novoPitanje.getNaziv())) {
                        postoji = true;
                        break;
                    }
                }
                if(!postoji) {
                    pitanja.add(pitanja.size() - 1, novoPitanje);
                    new PosaljiPitanje(DodajKvizAkt.this, novoPitanje).execute();
                    listViewAdapterPitanja.notifyDataSetChanged();
                }
                else
                    Toast.makeText(DodajKvizAkt.this, "Pitanje vec postoji", Toast.LENGTH_SHORT).show();
            }
        }
        if(requestCode == 2) {
            if (resultCode == Activity.RESULT_OK) {
                String categoryName = data.getStringExtra("ime kategorije");
                String categoryID = data.getStringExtra("id kategorije");
                new DodajKategorijuUDB(DodajKvizAkt.this, categoryName, Integer.parseInt(categoryID), (DodajKategorijuUDB.OnDohvatiKategorijuDone)DodajKvizAkt.this).execute();
            }
            else if(resultCode == Activity.RESULT_CANCELED) {
                // postavi kategoriju koja je bila
                izborKategorije.setSelection(previosState);
            }
        }
    }

    private void addAddNewQuestion() {
        pitanja.add(new Pitanje("Dodaj pitanje", "Dodaj pitanje", new ArrayList<String>(), ""));
    }

    private void setNameField() {
        if(!kviz.getNaziv().equals("Dodaj kviz"))
            nameField.setText(kviz.getNaziv());
    }

    private void addAddNewCategoryButton() {
        kategorije.add(new Kategorija("Dodaj kategoriju", ""));
        spinnerAdapter.notifyDataSetChanged();
    }

    @Override
    public void onBackPressed() {
        Intent resultIntent = new Intent();
        setResult(Activity.RESULT_CANCELED, resultIntent);
        finish();
    }

    @Override
    public void onDone(Kategorija rez) {
        if(rez != null) {
            kategorije.set(kategorije.size() - 1, rez);
            addAddNewCategoryButton();
            spinnerAdapter.notifyDataSetChanged();
        }
        else {
            izborKategorije.setSelection(previosState);
            Toast.makeText(this, "Unesena kategorija već postoji", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    public void onDone(ArrayList<Pitanje> moguca) {
        mogucaPitanja = moguca;
        listViewAdapterMogucaPitanja = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, mogucaPitanja);
        listaMogucihPitanja.setAdapter(listViewAdapterMogucaPitanja);
    }
}
