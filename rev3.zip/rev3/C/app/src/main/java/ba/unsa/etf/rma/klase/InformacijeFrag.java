package ba.unsa.etf.rma.klase;

import android.app.Fragment;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import ba.unsa.etf.rma.R;
import ba.unsa.etf.rma.aktivnosti.IgrajKvizAkt;
import ba.unsa.etf.rma.aktivnosti.KvizoviAkt;

public class InformacijeFrag extends Fragment {

    /*private TextView kvizName;
    private TextView brojTacnihPitanja;
    private TextView brojPreostalihPitanja;
    private TextView procenatTacnihOdgovora;
    private Button zatvoriKviz;
    private int preostalaPitanja;
    private int tacnaPitanja;
    private int procenatTacnih;
    private int ukupanBrojPitanja;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.top_section_fragment, container, false);

        kvizName = view.findViewById(R.id.infNazivKviza);
        brojTacnihPitanja = view.findViewById(R.id.infBrojTacnihPitanja);
        brojPreostalihPitanja = view.findViewById(R.id.infBrojPreostalihPitanja);
        procenatTacnihOdgovora = view.findViewById(R.id.infProcenatTacni);

        zatvoriKviz = view.findViewById(R.id.btnKraj);
        zatvoriKviz.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getActivity(), KvizoviAkt.class);
                startActivity(intent);
            }
        });

        return view;
    }

    public void setUpKviz(String nazivKviza, int brojPitanja) {
        kvizName.setText(nazivKviza);
        brojPreostalihPitanja.setText(String.valueOf(brojPitanja));
        ukupanBrojPitanja = preostalaPitanja = brojPitanja;
        tacnaPitanja = procenatTacnih = 0;
    }


    public void setInfromation(boolean jeLiTacan) {
        brojPreostalihPitanja.setText(String.valueOf(--preostalaPitanja));
        if(jeLiTacan) {
            tacnaPitanja++;
            brojTacnihPitanja.setText(String.valueOf(tacnaPitanja));
        }
        procenatTacnih = (tacnaPitanja / ukupanBrojPitanja) * 100;
    }*/

}
