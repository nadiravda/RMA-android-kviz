package ba.unsa.etf.rma.aktivnosti;

import android.app.Activity;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.maltaisn.icondialog.Icon;
import com.maltaisn.icondialog.IconDialog;

import ba.unsa.etf.rma.R;

public class DodajKategorijuAkt extends AppCompatActivity implements IconDialog.Callback{

    private Button dodajIkonu;
    private Button spremiKategoriju;

    private EditText nameField;
    private EditText iconNameField;

    private Icon[] selectedIcons;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dodaj_kategoriju_akt);

        dodajIkonu = findViewById(R.id.btnDodajIkonu);
        spremiKategoriju = findViewById(R.id.btnDodajKategoriju);

        nameField = findViewById(R.id.etNaziv);
        iconNameField = findViewById(R.id.etIkona);
        iconNameField.setEnabled(false);

        spremiKategoriju.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(nameField.getText().toString().equals("")) {
                    nameField.setBackgroundColor(getResources().getColor(R.color.redError));
                    Toast.makeText(DodajKategorijuAkt.this, "Enter Category Title", Toast.LENGTH_LONG).show();
                }
                else if(iconNameField.getText().toString().equals("")) {
                    iconNameField.setBackgroundColor(getResources().getColor(R.color.redError));
                    Toast.makeText(DodajKategorijuAkt.this, "Select Icon", Toast.LENGTH_LONG).show();
                }
                else {
                    String imeKategorije = nameField.getText().toString();
                    String idKategorije = iconNameField.getText().toString();

                    Intent resultIntent = new Intent();
                    resultIntent.putExtra("ime kategorije", imeKategorije);
                    resultIntent.putExtra("id kategorije", idKategorije);

                    setResult(Activity.RESULT_OK, resultIntent);
                    finish();
                }
            }
        });

        final IconDialog iconDialog = new IconDialog();
        dodajIkonu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                iconDialog.setSelectedIcons(selectedIcons);
                iconDialog.show(getSupportFragmentManager(), "icon_dialog");
            }
        });
    }

    @Override
    public void onIconDialogIconsSelected(Icon[] icons) {
        selectedIcons = icons;
        if(selectedIcons != null) {
            iconNameField.setText(String.valueOf(selectedIcons[0].getId()));
        }
    }

    @Override
    public void onBackPressed() {
        Intent resultIntent = new Intent();
        setResult(Activity.RESULT_CANCELED, resultIntent);
        finish();
    }
}
