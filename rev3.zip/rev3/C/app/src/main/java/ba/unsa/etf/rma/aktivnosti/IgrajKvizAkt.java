package ba.unsa.etf.rma.aktivnosti;

import android.app.Activity;
import android.app.FragmentManager;
import android.app.FragmentTransaction;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.widget.FrameLayout;

import ba.unsa.etf.rma.R;
import ba.unsa.etf.rma.klase.InformacijeFrag;
import ba.unsa.etf.rma.klase.Kviz;
import ba.unsa.etf.rma.klase.PitanjeFrag;

public class IgrajKvizAkt extends AppCompatActivity{


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_igraj_kviz_akt);

        /*Intent intent = getIntent();
        Kviz igrajuciKviz = intent.getParcelableExtra("kviz");

        FragmentManager fragmentManager = getFragmentManager();
        FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();

        PitanjeFrag pitanjeFrag = new PitanjeFrag();

        Bundle argumenti = new Bundle();
        argumenti.putParcelable("kviz", igrajuciKviz);

        pitanjeFrag.setArguments(argumenti);
        fragmentManager.beginTransaction().replace(R.id.pitanjePlace, pitanjeFrag).commit();*/
    }
}
