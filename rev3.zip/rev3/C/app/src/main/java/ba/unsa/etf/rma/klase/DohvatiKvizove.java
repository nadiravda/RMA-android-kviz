package ba.unsa.etf.rma.klase;

import android.content.Context;
import android.os.AsyncTask;
import android.util.Log;

import com.google.api.client.googleapis.auth.oauth2.GoogleCredential;
import com.google.common.collect.Lists;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.Reader;
import java.io.StringWriter;
import java.io.Writer;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;

import ba.unsa.etf.rma.R;

public class DohvatiKvizove extends AsyncTask<Void, Integer, Void> implements DohvatiPitanja.OnDohvatiPitanja {

    private Context context;
    private OnDohvatiKvizove pozivatelj;
    private ArrayList<Kviz> kvizoviKategorije = new ArrayList<>();
    private ArrayList<Kategorija> kategorije;
    private int izabranaKategorijaIndex;
    private ArrayList<Pitanje> pitanjaKvizaIzDB = new ArrayList<>();

    private Kviz trenutniKviz;

    @Override
    public void onDoneDohvatiPitanja(ArrayList<Pitanje> pitanja) {
        trenutniKviz.setPitanja(pitanja);
    }

    public interface OnDohvatiKvizove {
        void onDoneDohvatiKvizove(ArrayList<Kviz> kvizovi);
    }

    public DohvatiKvizove(Context context, OnDohvatiKvizove pozivatelj, ArrayList<Kategorija> kategorije, int izabranaKategorijaIndex) {
        this.context = context;
        this.pozivatelj = pozivatelj;
        this.kategorije = kategorije;
        this.izabranaKategorijaIndex = izabranaKategorijaIndex;
    }

    @Override
    protected Void doInBackground(Void... voids) {
        //konekcija
        String TOKEN = "";
        try {
            InputStream is = context.getResources().openRawResource(R.raw.secret);
            GoogleCredential credentials = GoogleCredential.fromStream(is).
                    createScoped(Lists.newArrayList("https://www.googleapis.com/auth/datastore"));
            credentials.refreshToken();
            TOKEN = credentials.getAccessToken();
        } catch (IOException e) {
            e.printStackTrace();
        }

        if(kategorije.get(izabranaKategorijaIndex).getNaziv().equals("Svi")) {
            for (Kategorija k :
                    kategorije) {
                if(!k.getIdUBazi().equals(""))
                    parseJSONObject(k, TOKEN);
            }
        }
        else {
            parseJSONObject(kategorije.get(izabranaKategorijaIndex), TOKEN);
        }

        return null;
    }

    private void parseJSONObject(Kategorija kategorija, String TOKEN) {
        try {
            String query = "{\n" +
                        "    \"structuredQuery\": {\n" +
                        "        \"where\" : {\n" +
                        "            \"fieldFilter\" : { \n" +
                        "                \"field\": {\"fieldPath\": \"idKategorije\"}, \n" +
                        "                \"op\":\"EQUAL\", \n" +
                        "                \"value\": {\"stringValue\": \"" + kategorija.getIdUBazi() + "\"}\n" +
                        "            }\n" +
                        "        },\n" +
                        "        \"select\": { \"fields\": [ {\"fieldPath\": \"idKategorije\"}, {\"fieldPath\": \"naziv\"}, {\"fieldPath\": \"pitanja\"}] },\n" +
                        "        \"from\": [{\"collectionId\": \"Kvizovi\"}],\n" +
                        "        \"limit\": 1000 \n" +
                        "      }\n" +
                        "}";

                String url1 = "https://firestore.googleapis.com/v1/projects/rma19spirala3/databases/(default)/documents:runQuery?access_token=" + TOKEN;
                URL url = new URL(url1);
                HttpURLConnection urlConnection = (HttpURLConnection) url.openConnection();
                urlConnection.setDoOutput(true);
                urlConnection.setRequestMethod("POST");
                urlConnection.setRequestProperty("Content-Type", "application/json; utf-8");
                urlConnection.setRequestProperty("Accept", "application/json");

                try (OutputStream os = urlConnection.getOutputStream()) {
                    byte[] input = query.getBytes("utf-8");
                    os.write(input, 0, input.length);
                }

                int code = urlConnection.getResponseCode();


                // ovdje radimo sa kvizovima kategorije
                InputStream odgovor = urlConnection.getInputStream();
                try (BufferedReader br = new BufferedReader(new InputStreamReader(odgovor, "utf-8"))) {
                    StringBuilder response = new StringBuilder();
                    String responseLine = null;
                    while ((responseLine = br.readLine()) != null) {
                        response.append(responseLine.trim());
                    }
                    String rezultat = response.toString();
                    rezultat = "{ \"documents\": " + rezultat + "}";
                    Log.d("ODGOVOR", rezultat);
                    JSONObject jo = new JSONObject(rezultat);
                    JSONArray dokumenti = jo.getJSONArray("documents");
                    for (int i = 0; i < dokumenti.length(); i++) {

                        JSONObject dokument = dokumenti.getJSONObject(i);
                        dokument = dokument.getJSONObject("document");
                        String name = dokument.getString("name");
                        JSONObject fields = dokument.getJSONObject("fields");
                        JSONObject naziv = fields.getJSONObject("naziv");
                        JSONObject idKategorije = fields.getJSONObject("idKategorije");
                        JSONObject pitanja = fields.getJSONObject("pitanja");
                        pitanja = pitanja.getJSONObject("arrayValue");

                        String nazivKviza = naziv.getString("stringValue");
                        String idKategorijeKviza = idKategorije.getString("stringValue");

                        JSONArray pitanjaNiz = pitanja.getJSONArray("values");
                        ArrayList<String> pitanjaKviza = new ArrayList<>();
                        for (int j = 0; j < pitanjaNiz.length(); j++) {
                            JSONObject pitanje = pitanjaNiz.getJSONObject(j);
                            String pitanjeKviza = pitanje.getString("stringValue");
                            pitanjaKviza.add(pitanjeKviza);
                        }


                        Kviz kviz = new Kviz(nazivKviza, new ArrayList<Pitanje>(), kategorija);
                        kviz.setIdPitanja(pitanjaKviza);
                        kviz.setKvizID(takeIDFromName(name));
                        kvizoviKategorije.add(kviz);
                    }
                }
        } catch (IOException e) {
            e.printStackTrace();
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    private String takeIDFromName(String name) {
        return name.substring(name.lastIndexOf('/') + 1);
    }

    @Override
    protected void onPostExecute(Void aVoid) {
        super.onPostExecute(aVoid);
        pozivatelj.onDoneDohvatiKvizove(kvizoviKategorije);
    }

    private String convertStreamToString(InputStream stream) throws IOException {
        // To convert the InputStream to String we use the
        // Reader.read(char[] buffer) method. We iterate until the
        // Reader return -1 which means there's no more data to
        // read. We use the StringWriter class to produce the string.
        if (stream != null) {
            Writer writer = new StringWriter();

            char[] buffer = new char[1024];
            try {
                Reader reader = new BufferedReader(new InputStreamReader(stream, "UTF-8"));
                int n;
                while ((n = reader.read(buffer)) != -1) {
                    writer.write(buffer, 0, n);
                }
            } finally {
                stream.close();
            }
            return writer.toString();
        }
        return "";
    }
}
