package ba.unsa.etf.rma.klase;

import android.content.Context;
import android.os.AsyncTask;
import android.util.Log;

import com.google.api.client.googleapis.auth.oauth2.GoogleCredential;
import com.google.common.collect.Lists;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.io.StringWriter;
import java.io.Writer;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;

import ba.unsa.etf.rma.R;

public class PostaviKategorije extends AsyncTask<Void, Integer, Void> {

    private Context context;
    private ArrayList<Kategorija> kategorije = new ArrayList<>();

    public interface OnPostaviKategorijeDone {
        void onDone(ArrayList<Kategorija> kategorije);
    }

    private OnPostaviKategorijeDone pozivatelj;

    public PostaviKategorije(Context context, OnPostaviKategorijeDone pozivatelj) {
        this.context = context;
        this.pozivatelj = pozivatelj;
    }

    @Override
    protected Void doInBackground(Void... voids) {

        String TOKEN = "";
        try {
            InputStream is = context.getResources().openRawResource(R.raw.secret);
            GoogleCredential credentials = GoogleCredential.fromStream(is).
                    createScoped(Lists.newArrayList("https://www.googleapis.com/auth/datastore"));
            credentials.refreshToken();
            TOKEN = credentials.getAccessToken();
        } catch (IOException e) {
            e.printStackTrace();
        }
        try {
            String url1 = "https://firestore.googleapis.com/v1/projects/rma19spirala3/databases/(default)/documents/Kategorije?access_token=" + TOKEN;
            URL url = new URL(url1);
            Log.d("ODGOVOR", url1);
            HttpURLConnection urlConnection = (HttpURLConnection) url.openConnection();
            urlConnection.setRequestMethod("GET");
            InputStream is = urlConnection.getInputStream();
            String rezultat = convertStreamToString(is);

            JSONObject jo = new JSONObject(rezultat);
            JSONArray documents = jo.getJSONArray("documents");
            for(int i = 0; i < documents.length(); i++) {
                JSONObject document = documents.getJSONObject(i);
                String name = document.getString("name");
                JSONObject fields = document.getJSONObject("fields");
                JSONObject naziv = fields.getJSONObject("naziv");
                JSONObject idIkonice = fields.getJSONObject("idIkonice");
                String nazivKategorije = naziv.getString("stringValue");
                int idIkoniceKategorije = idIkonice.getInt("integerValue");

                Kategorija kategorija = new Kategorija(nazivKategorije, String.valueOf(idIkoniceKategorije));
                String s = takeIDFromName(name);
                kategorija.setIdUBazi(s);
                kategorije.add(kategorija);
            }


        } catch (IOException e) {
            e.printStackTrace();
        } catch (JSONException e) {
            e.printStackTrace();
        }

        return null;
    }

    private String takeIDFromName(String name) {
        return name.substring(name.lastIndexOf('/') + 1);
    }

    @Override
    protected void onPostExecute(Void aVoid) {
        super.onPostExecute(aVoid);
        pozivatelj.onDone(kategorije);
    }

    private String convertStreamToString(InputStream stream) throws IOException {
        // To convert the InputStream to String we use the
        // Reader.read(char[] buffer) method. We iterate until the
        // Reader return -1 which means there's no more data to
        // read. We use the StringWriter class to produce the string.
        if (stream != null) {
            Writer writer = new StringWriter();

            char[] buffer = new char[1024];
            try {
                Reader reader = new BufferedReader(new InputStreamReader(stream, "UTF-8"));
                int n;
                while ((n = reader.read(buffer)) != -1) {
                    writer.write(buffer, 0, n);
                }
            } finally {
                stream.close();
            }
            return writer.toString();
        }
        return "";
    }
}
