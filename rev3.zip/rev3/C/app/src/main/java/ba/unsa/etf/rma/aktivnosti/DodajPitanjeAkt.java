package ba.unsa.etf.rma.aktivnosti;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;

import ba.unsa.etf.rma.R;
import ba.unsa.etf.rma.klase.Pitanje;

public class DodajPitanjeAkt extends AppCompatActivity {

    private EditText questionTitle;
    private EditText answerField;

    private ListView listaOdgovora;
    private ArrayAdapter<String> listaOdgovoraAdapter;
    private ArrayList<String> odgovori = new ArrayList<>();

    private String tacan;

    private Button dodajOdgovor;
    private Button dodajTacanOdgovor;
    private Button spremiPitanje;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.actvitiy_dodaj_pitanje_akt);

        questionTitle = findViewById(R.id.etNaziv);
        answerField = findViewById(R.id.etOdgovor);
        dodajOdgovor = findViewById(R.id.btnDodajOdgovor);
        dodajTacanOdgovor = findViewById(R.id.btnDodajTacan);
        spremiPitanje = findViewById(R.id.btnDodajPitanje);
        listaOdgovora = findViewById(R.id.lvOdgovori);

        connectListView();

        dodajOdgovor.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(answerField.getText().toString().equals("")) {
                    answerField.setBackgroundColor(getResources().getColor(R.color.redError));
                    Toast.makeText(DodajPitanjeAkt.this, "Enter Answer", Toast.LENGTH_LONG).show();
                }
                else{
                    odgovori.add(answerField.getText().toString());
                    answerField.setText("");
                    listaOdgovoraAdapter.notifyDataSetChanged();
                }
            }
        });

        dodajTacanOdgovor.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                odgovori.add(answerField.getText().toString());
                tacan = answerField.getText().toString();
                answerField.setText("");
                listaOdgovoraAdapter.notifyDataSetChanged();
            }
        });

        spremiPitanje.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(questionTitle.getText().toString().equals("")) {
                    questionTitle.setBackgroundColor(getResources().getColor(R.color.redError));
                    Toast.makeText(DodajPitanjeAkt.this, "Enter Question Title", Toast.LENGTH_LONG).show();
                }
                else if(tacan == null) {
                    Toast.makeText(DodajPitanjeAkt.this, "Enter correct answer", Toast.LENGTH_LONG).show();
                }
                else {
                    Intent resultIntent = new Intent();
                    String pitanje = questionTitle.getText().toString();
                    Pitanje novoPitanje = new Pitanje(pitanje, pitanje, odgovori, tacan);
                    resultIntent.putExtra("novo pitanje", novoPitanje);

                    setResult(RESULT_OK, resultIntent);
                    finish();
                }
            }
        });
    }

    private void connectListView() {
        listaOdgovoraAdapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, odgovori);
        listaOdgovora.setAdapter(listaOdgovoraAdapter);
    }

}
