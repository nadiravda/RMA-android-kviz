package ba.unsa.etf.rma.klase;

import android.content.Context;
import android.os.AsyncTask;
import android.util.Log;

import com.google.api.client.googleapis.auth.oauth2.GoogleCredential;
import com.google.common.collect.Lists;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.io.StringWriter;
import java.io.Writer;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;

import ba.unsa.etf.rma.R;


public class PitanjaDB extends AsyncTask<Void, Integer, Void> {

    private Context context;
    private ArrayList<Pitanje> trenutnaPitanja;

    public interface OnDohvatiPitanjaDone {
        void onDone(ArrayList<Pitanje> moguca);
    }

    ArrayList<Pitanje> mogucaPitanja;
    private OnDohvatiPitanjaDone pozivatelj;

    public PitanjaDB(Context context, ArrayList<Pitanje> trenutnaPitanja, OnDohvatiPitanjaDone pozivatelj) {
        this.context = context;
        this.trenutnaPitanja = trenutnaPitanja;
        this.pozivatelj = pozivatelj;
    }

    @Override
    protected Void doInBackground(Void... voids) {
        //konekcija
        String TOKEN = "";
        mogucaPitanja = new ArrayList<>();

        try {
            InputStream is = context.getResources().openRawResource(R.raw.secret);
            GoogleCredential credentials = GoogleCredential.fromStream(is).
                    createScoped(Lists.newArrayList("https://www.googleapis.com/auth/datastore"));
            credentials.refreshToken();
            TOKEN = credentials.getAccessToken();
        } catch (IOException e) {
            e.printStackTrace();
        }

        //uspostavljanje protokola
        try {
            String url1 = "https://firestore.googleapis.com/v1/projects/rma19spirala3/databases/(default)/documents/Pitanja?access_token=" + TOKEN;
            URL url = new URL(url1);
            HttpURLConnection urlConnection = (HttpURLConnection) url.openConnection();
            InputStream odgovor = urlConnection.getInputStream();
            String rezultat = convertStreamToString(odgovor);

            JSONObject jo = new JSONObject(rezultat);

            Log.d("ODGOVOR", url1);

            JSONArray dokumenti = jo.getJSONArray("documents");
            for(int i = 0; i < dokumenti.length(); i++) {
                JSONObject dokument = dokumenti.getJSONObject(i);
                JSONObject fields = dokument.getJSONObject("fields");
                JSONObject naziv = fields.getJSONObject("naziv");
                JSONObject index = fields.getJSONObject("indexTacnog");
                JSONObject odgovori = fields.getJSONObject("odgovori");
                odgovori = odgovori.getJSONObject("arrayValue");
                JSONArray odgovoriNaPitanje = odgovori.getJSONArray("values");
                String nazivPitanja = naziv.getString("stringValue");
                boolean postojiPitanje = false;
                for (Pitanje x :
                        trenutnaPitanja) {
                    if (x.getNaziv().equals(nazivPitanja)) {
                        postojiPitanje = true;
                        break;
                    }
                }
                if(postojiPitanje)
                    continue;
                int indexTacnog = index.getInt("integerValue");
                ArrayList<String> odgovoriPitanja = new ArrayList<>();
                for(int j = 0; j < odgovoriNaPitanje.length(); j++) {
                    JSONObject odg = odgovoriNaPitanje.getJSONObject(j);
                    String odgovorPitanja = odg.getString("stringValue");
                    odgovoriPitanja.add(odgovorPitanja);
                }
                mogucaPitanja.add(new Pitanje(nazivPitanja, nazivPitanja, odgovoriPitanja, odgovoriPitanja.get(indexTacnog)));
            }

            int code = urlConnection.getResponseCode();

            Log.d("ODGOVOR", String.valueOf(code));

        } catch (IOException e) {
            e.printStackTrace();
        } catch (JSONException e) {
            e.printStackTrace();
        }
        return null;
    }

    @Override
    protected void onPostExecute(Void aVoid) {
        super.onPostExecute(aVoid);
        pozivatelj.onDone(mogucaPitanja);
    }

    private String convertStreamToString(InputStream stream) throws IOException {
        // To convert the InputStream to String we use the
        // Reader.read(char[] buffer) method. We iterate until the
        // Reader return -1 which means there's no more data to
        // read. We use the StringWriter class to produce the string.
        if (stream != null) {
            Writer writer = new StringWriter();

            char[] buffer = new char[1024];
            try {
                Reader reader = new BufferedReader(new InputStreamReader(stream, "UTF-8"));
                int n;
                while ((n = reader.read(buffer)) != -1) {
                    writer.write(buffer, 0, n);
                }
            } finally {
                stream.close();
            }
            return writer.toString();
        }
        return "";
    }

}
