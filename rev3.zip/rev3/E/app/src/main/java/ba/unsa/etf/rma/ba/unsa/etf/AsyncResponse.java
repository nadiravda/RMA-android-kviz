package ba.unsa.etf.rma.ba.unsa.etf;

public interface AsyncResponse {
    void processFinish(String output);
}
